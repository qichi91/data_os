#!/usr/bin/env node
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

const WEB_ROOT = __dirname;
const PROJECT_ROOT = path.resolve(__dirname, '..', '..', '..');
const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '127.0.0.1';

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.htm': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.ico': 'image/x-icon'
};

function toPosixPath(filePath) {
  return filePath.split(path.sep).join('/');
}

function relativeToProject(absPath) {
  return toPosixPath(path.relative(PROJECT_ROOT, absPath));
}

function ensureInsideProject(relPath) {
  const normalized = String(relPath || '').replace(/^[/\\]+/, '');
  const abs = path.resolve(PROJECT_ROOT, normalized);
  const root = path.resolve(PROJECT_ROOT);
  if (!(abs === root || abs.startsWith(root + path.sep))) {
    return null;
  }
  return abs;
}

function send(res, status, body, headers) {
  const h = Object.assign({
    'Content-Type': 'text/plain; charset=utf-8',
    'Cache-Control': 'no-store'
  }, headers || {});
  res.writeHead(status, h);
  res.end(body);
}

function sendJson(res, status, value) {
  send(res, status, JSON.stringify(value, null, 2), {
    'Content-Type': 'application/json; charset=utf-8'
  });
}

function serveFile(res, absPath) {
  fs.stat(absPath, (err, stat) => {
    if (err || !stat.isFile()) {
      send(res, 404, 'Not Found: ' + relativeToProject(absPath));
      return;
    }
    const ext = path.extname(absPath).toLowerCase();
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Cache-Control': 'no-store',
      'Content-Length': stat.size
    });
    fs.createReadStream(absPath).pipe(res);
  });
}

function readJson(filePath, warnings) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch (err) {
    if (warnings) {
      warnings.push({
        filePath: relativeToProject(filePath),
        message: err && err.message || String(err)
      });
    }
    return null;
  }
}

function listJsonFiles(dirPath) {
  if (!fs.existsSync(dirPath)) return [];
  const results = [];
  for (const entry of fs.readdirSync(dirPath, { withFileTypes: true })) {
    const abs = path.join(dirPath, entry.name);
    if (entry.isDirectory()) {
      results.push(...listJsonFiles(abs));
    } else if (entry.isFile() && entry.name.toLowerCase().endsWith('.json')) {
      results.push(abs);
    }
  }
  return results.sort((a, b) => relativeToProject(a).localeCompare(relativeToProject(b), 'ja'));
}

function makeId(kind, parts) {
  return kind + ':' + parts.map(part => encodeURIComponent(String(part || ''))).join('/');
}

function key() {
  return Array.from(arguments).map(v => String(v || '')).join('\x1f');
}

function pushUnique(list, value) {
  if (value && !list.includes(value)) list.push(value);
}

function addIndex(map, mapKey, value) {
  if (!map.has(mapKey)) map.set(mapKey, []);
  pushUnique(map.get(mapKey), value);
}

function getName(value, fallback) {
  const text = String(value || '').trim();
  return text || fallback;
}

function createState() {
  return {
    data: {
      warnings: [],
      uiBucs: [],
      screens: [],
      actions: [],
      appBucs: [],
      ucs: [],
      appServices: [],
      contexts: [],
      domainServices: [],
      entities: []
    },
    indexes: {
      domainServiceByContextAndName: new Map(),
      entityByContextAndName: new Map(),
      appServiceByUcAndName: new Map(),
      appServiceByCompoundKey: new Map(),
      appServicesByName: new Map()
    }
  };
}

function buildDomainLayer(state) {
  const domainDir = path.join(PROJECT_ROOT, '3_RDRASdd', 'domain');
  for (const filePath of listJsonFiles(domainDir)) {
    const json = readJson(filePath, state.data.warnings);
    if (!json) continue;
    const contextName = getName(json && json.コンテキスト && json.コンテキスト.名前, path.basename(filePath, '.json'));
    const contextId = makeId('context', [contextName]);
    const context = {
      id: contextId,
      label: contextName,
      filePath: relativeToProject(filePath),
      domainServices: [],
      entities: []
    };
    state.data.contexts.push(context);

    for (const entityJson of json.エンティティ一覧 || []) {
      const entityName = getName(entityJson.名前, '');
      if (!entityName) continue;
      const entityId = makeId('entity', [contextName, entityName]);
      const entity = {
        id: entityId,
        label: entityName,
        context: contextId,
        filePath: relativeToProject(filePath)
      };
      state.data.entities.push(entity);
      pushUnique(context.entities, entityId);
      state.indexes.entityByContextAndName.set(key(contextName, entityName), entityId);
    }

    for (const serviceJson of json.ドメインサービス一覧 || []) {
      const serviceName = getName(serviceJson.名前, '');
      if (!serviceName) continue;
      const serviceId = makeId('domainService', [contextName, serviceName]);
      const domainService = {
        id: serviceId,
        label: serviceName,
        context: contextId,
        filePath: relativeToProject(filePath),
        entities: []
      };
      for (const entityName of serviceJson.対象エンティティ一覧 || []) {
        const entityId = state.indexes.entityByContextAndName.get(key(contextName, entityName));
        if (entityId) pushUnique(domainService.entities, entityId);
      }
      state.data.domainServices.push(domainService);
      pushUnique(context.domainServices, serviceId);
      state.indexes.domainServiceByContextAndName.set(key(contextName, serviceName), serviceId);
    }
  }
}

function buildApplicationLayer(state) {
  const appDir = path.join(PROJECT_ROOT, '3_RDRASdd', 'application');
  for (const filePath of listJsonFiles(appDir)) {
    const json = readJson(filePath, state.data.warnings);
    if (!json) continue;
    const bucName = getName(json.BUC, path.basename(filePath, '.json'));
    const appBucId = makeId('appbuc', [bucName]);
    const appBuc = {
      id: appBucId,
      label: bucName,
      filePath: relativeToProject(filePath),
      ucs: []
    };
    state.data.appBucs.push(appBuc);

    for (const ucJson of json.UC一覧 || []) {
      const ucName = getName(ucJson.UC, '');
      if (!ucName) continue;
      const ucId = makeId('uc', [bucName, ucName]);
      const uc = {
        id: ucId,
        label: ucName,
        buc: appBucId,
        filePath: relativeToProject(filePath),
        appServices: []
      };
      state.data.ucs.push(uc);
      pushUnique(appBuc.ucs, ucId);

      for (const serviceJson of ucJson.アプリケーションサービス一覧 || []) {
        const serviceName = getName(serviceJson.アプリケーションサービス, '');
        if (!serviceName) continue;
        const appServiceId = makeId('appService', [bucName, ucName, serviceName]);
        const appService = {
          id: appServiceId,
          label: serviceName,
          uc: ucId,
          buc: appBucId,
          ucName,
          filePath: relativeToProject(filePath),
          domainServices: []
        };
        for (const domainRef of serviceJson.ドメインサービス一覧 || []) {
          const contextName = getName(domainRef.コンテキスト, '');
          const domainServiceName = getName(domainRef.ドメインサービス, '');
          const domainServiceId = state.indexes.domainServiceByContextAndName.get(key(contextName, domainServiceName));
          if (domainServiceId) pushUnique(appService.domainServices, domainServiceId);
        }
        state.data.appServices.push(appService);
        pushUnique(uc.appServices, appServiceId);
        state.indexes.appServiceByUcAndName.set(key(ucName, serviceName), appServiceId);
        state.indexes.appServiceByCompoundKey.set(key(ucName + '/' + serviceName), appServiceId);
        addIndex(state.indexes.appServicesByName, serviceName, appServiceId);
      }
    }
  }
}

function resolveAppService(state, callJson) {
  const ucName = getName(callJson.UC, '');
  const serviceName = getName(callJson.アプリケーションサービス, '');
  const compound = getName(callJson.UCアプリケーションサービス, '');

  if (compound && state.indexes.appServiceByCompoundKey.has(key(compound))) {
    return [state.indexes.appServiceByCompoundKey.get(key(compound))];
  }
  if (ucName && serviceName && state.indexes.appServiceByUcAndName.has(key(ucName, serviceName))) {
    return [state.indexes.appServiceByUcAndName.get(key(ucName, serviceName))];
  }
  if (serviceName && state.indexes.appServicesByName.has(serviceName)) {
    return state.indexes.appServicesByName.get(serviceName).slice();
  }
  return [];
}

function buildUiLayer(state) {
  const uiDir = path.join(PROJECT_ROOT, '3_RDRASdd', 'ui');
  if (!fs.existsSync(uiDir)) return;
  const bucEntries = fs.readdirSync(uiDir, { withFileTypes: true })
    .filter(entry => entry.isDirectory())
    .sort((a, b) => a.name.localeCompare(b.name, 'ja'));

  for (const bucEntry of bucEntries) {
    const bucName = bucEntry.name;
    const bucDir = path.join(uiDir, bucName);
    const uiBucId = makeId('uibuc', [bucName]);
    const uiBuc = {
      id: uiBucId,
      label: bucName,
      filePath: relativeToProject(bucDir),
      screens: []
    };
    state.data.uiBucs.push(uiBuc);

    const screenFiles = listJsonFiles(bucDir);
    for (const filePath of screenFiles) {
      const json = readJson(filePath, state.data.warnings);
      if (!json) continue;
      const screenName = getName(json.画面名 || (json.概要 && json.概要.画面名), path.basename(filePath, '.json'));
      const screenId = makeId('screen', [bucName, screenName]);
      const screen = {
        id: screenId,
        label: screenName,
        buc: uiBucId,
        filePath: relativeToProject(filePath),
        actions: []
      };
      state.data.screens.push(screen);
      pushUnique(uiBuc.screens, screenId);

      for (const actionJson of json.アクション定義 || []) {
        const actionName = getName(actionJson.アクション名, '');
        if (!actionName) continue;
        const actionId = makeId('action', [bucName, screenName, actionName]);
        const action = {
          id: actionId,
          label: actionName,
          screen: screenId,
          buc: uiBucId,
          filePath: relativeToProject(filePath),
          ucName: getName(actionJson.対応UC, ''),
          appServices: []
        };
        for (const callJson of actionJson.アプリケーションサービス呼び出し一覧 || []) {
          for (const appServiceId of resolveAppService(state, callJson)) {
            pushUnique(action.appServices, appServiceId);
          }
        }
        state.data.actions.push(action);
        pushUnique(screen.actions, actionId);
      }
    }
  }
}

function buildCallgraphData() {
  const state = createState();
  buildDomainLayer(state);
  buildApplicationLayer(state);
  buildUiLayer(state);
  return state.data;
}

function handleApiCallgraph(res) {
  try {
    sendJson(res, 200, buildCallgraphData());
  } catch (err) {
    sendJson(res, 500, { error: err && err.message || String(err) });
  }
}

function handleApiFile(reqUrl, res) {
  const relPath = reqUrl.searchParams.get('path');
  const abs = ensureInsideProject(relPath);
  if (!abs) {
    send(res, 403, 'Forbidden');
    return;
  }
  serveFile(res, abs);
}

function resolveStatic(reqPath) {
  if (reqPath === '/' || reqPath === '' || reqPath === '/callgraphView.html') {
    return path.join(WEB_ROOT, 'callgraphView.html');
  }
  const trimmed = reqPath.replace(/^[/\\]+/, '');
  const abs = path.resolve(WEB_ROOT, trimmed);
  const root = path.resolve(WEB_ROOT);
  if (!(abs === root || abs.startsWith(root + path.sep))) return null;
  return abs;
}

function createServer() {
  return http.createServer((req, res) => {
    const reqUrl = new URL(req.url || '/', `http://${req.headers.host || HOST}`);
    const reqPath = reqUrl.pathname;

    if (reqPath === '/__shutdown' || reqPath === '/__shutdown/') {
      send(res, 200, 'shutting down', { 'Access-Control-Allow-Origin': '*' });
      console.log('callgraphServer: shutdown requested via /__shutdown');
      setTimeout(() => process.exit(0), 50);
      return;
    }

    if (req.method !== 'GET' && req.method !== 'HEAD') {
      send(res, 405, 'Method Not Allowed', { Allow: 'GET, HEAD' });
      return;
    }

    if (reqPath === '/api/callgraph') {
      handleApiCallgraph(res);
      return;
    }
    if (reqPath === '/api/file') {
      handleApiFile(reqUrl, res);
      return;
    }

    const abs = resolveStatic(reqPath);
    if (!abs) {
      send(res, 403, 'Forbidden');
      return;
    }
    serveFile(res, abs);
  });
}

if (require.main === module) {
  const server = createServer();
  server.listen(PORT, HOST, () => {
    const url = `http://${HOST}:${PORT}/`;
    console.log('callgraphServer: listening on ' + url);
    console.log('[info] projectRoot: ' + PROJECT_ROOT);
    console.log('Open: ' + url + 'callgraphView.html');
  });
  server.on('error', (err) => {
    console.error('callgraphServer error: ' + err.message);
    process.exit(1);
  });
}

module.exports = {
  buildCallgraphData,
  createServer
};
