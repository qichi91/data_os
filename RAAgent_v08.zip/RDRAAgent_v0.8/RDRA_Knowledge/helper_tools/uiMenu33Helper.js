'use strict';

/**
 * メニュー33: BUC 単位の一時プロンプト生成と parallel-runner 用プロンプトマップ構築。
 */

const fs = require('fs');
const path = require('path');

const { listScreenInquiryBucUiEntries } = require('./uiBucFolderName');

const TEMPLATE_REL = 'RDRA_Knowledge/_3_RDRASdd/34_Create_UI.md';
const WORK_DIR_REL = '3_RDRASdd/.work';

function ensureWorkDir(projectRoot) {
    const workAbs = path.join(projectRoot, ...WORK_DIR_REL.split('/'));
    fs.mkdirSync(workAbs, { recursive: true });
    return workAbs;
}

/**
 * @param {string} projectRoot
 * @returns {{ ok: true, promptMap: { prompt: string }[], bucEntries: { bucJapaneseName: string, businessName: string, folderName: string }[] } | { ok: false, message: string }}
 */
function buildMenu33PromptMap(projectRoot) {
    const bucEntries = listScreenInquiryBucUiEntries(projectRoot);
    if (bucEntries.length === 0) {
        return {
            ok: false,
            message:
                'メニュー33: 画面照会 JSON から BUC を取得できません。2_RDRASpec/画面照会.json（または ui.json）を確認してください。',
        };
    }

    const templateAbs = path.join(projectRoot, ...TEMPLATE_REL.split('/'));
    if (!fs.existsSync(templateAbs)) {
        return { ok: false, message: `メニュー33: テンプレートが見つかりません: ${TEMPLATE_REL}` };
    }

    let templateBody;
    try {
        templateBody = fs.readFileSync(templateAbs, 'utf8');
    } catch (e) {
        return { ok: false, message: `メニュー33: テンプレートの読み込みに失敗しました: ${e.message || e}` };
    }

    const workAbs = ensureWorkDir(projectRoot);

    const uiRoot = path.join(projectRoot, '3_RDRASdd', 'ui');
    fs.mkdirSync(uiRoot, { recursive: true });

    /** @type {{ prompt: string }[]} */
    const promptMap = [];

    for (const e of bucEntries) {
        const bucDir = path.join(uiRoot, e.folderName);
        fs.mkdirSync(bucDir, { recursive: true });

        const scope = [
            '# メニュー33 実行スコープ（自動付与・厳守）',
            '',
            `- 対象 BUC（日本語名）: ${e.bucJapaneseName}`,
            `- 所属業務名: ${e.businessName || '（未記載）'}`,
            `- 出力先フォルダー（この BUC の画面のみ）: \`3_RDRASdd/ui/${e.folderName}/\``,
            '- 当該 BUC に属する画面の仕様書のみを上記フォルダーに作成・上書きする。他 BUC の画面用ファイルは作成しない。',
            '- **入力として `3_RDRASdd/application/` 配下のファイルを読まない。**',
            '- 画面集合は `2_RDRASpec/画面照会.json` の当該 BUC の `actors[].screen_names[]` に限定する（全体の和集合は他 BUC 実行で賄う）。',
            '- `#edge UC 画面` にのみ現れ画面照会に無い画面は、関連データと当該 BUC の関係が明らかな場合のみ当該フォルダーに含めてよい。',
            '',
            '---',
            '',
            '',
        ].join('\n');

        const fileName = `34_Create_UI__${e.folderName}.md`;
        const outAbs = path.join(workAbs, fileName);
        fs.writeFileSync(outAbs, scope + templateBody, 'utf8');

        const promptRel = path.posix.join(WORK_DIR_REL.replace(/\\/g, '/'), fileName);
        promptMap.push({ prompt: promptRel });
    }

    return { ok: true, promptMap, bucEntries };
}

module.exports = {
    buildMenu33PromptMap,
    WORK_DIR_REL,
};
