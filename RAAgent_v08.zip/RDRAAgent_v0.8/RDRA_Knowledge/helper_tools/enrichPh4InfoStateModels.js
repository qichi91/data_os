#!/usr/bin/env node
/* eslint-disable no-console */
'use strict';

const fs = require('fs');
const path = require('path');

const INITIAL = '初期要望.txt';

function findProjectRoot(startDir) {
  let dir = path.resolve(startDir);
  const { root } = path.parse(dir);
  while (true) {
    if (fs.existsSync(path.join(dir, INITIAL))) {
      return dir;
    }
    if (dir === root) {
      throw new Error(`${INITIAL} が見つからず、プロジェクトルートを特定できません`);
    }
    dir = path.dirname(dir);
  }
}

function readText(filePath) {
  if (!fs.existsSync(filePath)) {
    throw new Error(`Input file not found: ${filePath}`);
  }
  return fs.readFileSync(filePath, { encoding: 'utf8' });
}

function splitLines(text) {
  const lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
  if (lines.length > 0 && lines[lines.length - 1] === '') lines.pop();
  return lines;
}

function parseTsv(filePath) {
  const lines = splitLines(readText(filePath)).filter((line) => line !== '');
  if (lines.length === 0) {
    throw new Error(`TSV is empty: ${filePath}`);
  }

  const header = lines[0].split('\t');
  const rows = lines.slice(1).map((line) => {
    const cols = line.split('\t');
    while (cols.length < header.length) cols.push('');
    return cols;
  });

  return { header, rows };
}

function writeTsv(filePath, tsv) {
  const lines = [tsv.header.join('\t')];
  for (const row of tsv.rows) {
    const outRow = row.slice();
    while (outRow.length < tsv.header.length) outRow.push('');
    lines.push(outRow.slice(0, tsv.header.length).join('\t'));
  }
  fs.writeFileSync(filePath, `${lines.join('\n')}\n`, { encoding: 'utf8' });
}

function colIndex(header, name, label) {
  const idx = header.indexOf(name);
  if (idx === -1) {
    throw new Error(`Missing column "${name}" in ${label}. Header: ${header.join(', ')}`);
  }
  return idx;
}

function normalizeToken(value) {
  return String(value ?? '').trim();
}

function parseList(cell) {
  return normalizeToken(cell)
    .split(/[、,，]/g)
    .map((part) => part.trim())
    .filter(Boolean);
}

function uniqueList(values) {
  const seen = new Set();
  const result = [];
  for (const value of values) {
    if (!value || seen.has(value)) continue;
    seen.add(value);
    result.push(value);
  }
  return result;
}

function buildInfoToStateModels(bucTsv) {
  const infoIdx = colIndex(bucTsv.header, '情報', 'phase3/ph3BUC.tsv');
  const stateModelIdx = colIndex(bucTsv.header, '状態モデル', 'phase3/ph3BUC.tsv');
  const allowedStateModels = new Set();
  const infoToStateModels = new Map();

  for (const row of bucTsv.rows) {
    const stateModels = parseList(row[stateModelIdx]);
    for (const stateModel of stateModels) {
      allowedStateModels.add(stateModel);
    }
  }

  for (const row of bucTsv.rows) {
    const infoNames = parseList(row[infoIdx]);
    const stateModels = parseList(row[stateModelIdx]).filter((stateModel) => allowedStateModels.has(stateModel));
    if (infoNames.length === 0 || stateModels.length === 0) continue;

    for (const infoName of infoNames) {
      const current = infoToStateModels.get(infoName) || [];
      infoToStateModels.set(infoName, uniqueList([...current, ...stateModels]));
    }
  }

  return { allowedStateModels, infoToStateModels };
}

function buildStateModelSet(stateTsv) {
  const stateModelIdx = colIndex(stateTsv.header, '状態モデル', 'phase4/ph4状態.tsv');
  const stateModels = new Set();

  for (const row of stateTsv.rows) {
    for (const stateModel of parseList(row[stateModelIdx])) {
      stateModels.add(stateModel);
    }
  }

  return stateModels;
}

function pruneMissingStateModels(stateModels, existingStateModels) {
  if (!existingStateModels) {
    return { stateModels, removedCount: 0 };
  }

  const kept = [];
  let removedCount = 0;
  for (const stateModel of stateModels) {
    if (existingStateModels.has(stateModel)) {
      kept.push(stateModel);
    } else {
      removedCount++;
    }
  }

  return { stateModels: kept, removedCount };
}

function enrichInfoStateModels({ bucTsv, infoTsv, stateTsv = null }) {
  const { allowedStateModels, infoToStateModels } = buildInfoToStateModels(bucTsv);
  const existingStateModels = stateTsv ? buildStateModelSet(stateTsv) : null;
  const infoIdx = colIndex(infoTsv.header, '情報', 'phase4/ph4情報.tsv');
  const stateModelIdx = colIndex(infoTsv.header, '状態モデル', 'phase4/ph4情報.tsv');
  let changedCount = 0;
  let removedCount = 0;

  for (const row of infoTsv.rows) {
    const infoName = normalizeToken(row[infoIdx]);
    const computed = uniqueList([
      ...(infoToStateModels.get(infoName) || []),
      ...(allowedStateModels.has(infoName) ? [infoName] : []),
    ]);
    const pruned = pruneMissingStateModels(computed, existingStateModels);
    removedCount += pruned.removedCount;
    const nextValue = pruned.stateModels.join('、');
    if (normalizeToken(row[stateModelIdx]) !== nextValue) {
      row[stateModelIdx] = nextValue;
      changedCount++;
    }
  }

  return { changedCount, removedCount };
}

function main() {
  const root = findProjectRoot(process.cwd());
  const bucPath = path.join(root, '0_RDRAZeroOne', 'phase3', 'ph3BUC.tsv');
  const infoPath = path.join(root, '0_RDRAZeroOne', 'phase4', 'ph4情報.tsv');
  const statePath = path.join(root, '0_RDRAZeroOne', 'phase4', 'ph4状態.tsv');

  const bucTsv = parseTsv(bucPath);
  const infoTsv = parseTsv(infoPath);
  const stateTsv = parseTsv(statePath);
  const { changedCount, removedCount } = enrichInfoStateModels({ bucTsv, infoTsv, stateTsv });
  writeTsv(infoPath, infoTsv);

  console.log(`[ph4情報補正] 状態モデル列を再計算しました（更新行数: ${changedCount}）`);
  console.log(`[ph4情報補正] ph4状態.tsvに存在しない状態モデルを除外しました（除外数: ${removedCount}）`);
}

if (require.main === module) {
  try {
    main();
  } catch (error) {
    console.error(`[ph4情報補正] 例外: ${error.message || error}`);
    process.exit(1);
  }
}

module.exports = {
  buildInfoToStateModels,
  buildStateModelSet,
  pruneMissingStateModels,
  enrichInfoStateModels,
};
