const { exec, spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const { deleteFilesInFolder, deleteFolderRecursive, deleteAllArtifacts } = require('./deleteFiles');
const dagRunner = require('./parallelRun/dag-runner');
const sddPostCheck = require('./sddPostCheck');
const { buildMenu33PromptMap } = require('./uiMenu33Helper');

const {
    specPhase1PromptMap,
    specPhase2PromptMap,
    createBasePromptMap,
    createDomainPromptMap,
    createApplicationPromptMap,
    rdraFiles,
} = require('./settings/rdraConfig');

let grahUrl = 'https://vsa.co.jp/rdratool/graph/v0.96/index.html?clipboard';

/**
 * menu.js から「実行部分」を切り出したアクション実装。
 */
function createMenuAction({ rl, promptUser, waitForEnterThenNext }) {
    function getClipboardCommand(filePath) {
        const platform = process.platform;
        if (platform === 'win32') {
            const windowsPath = filePath.replace(/\//g, '\\');
            return `powershell -Command "Get-Content -Path ${windowsPath} -Encoding UTF8 | Set-Clipboard"`;
        } else if (platform === 'darwin') {
            return `cat "${filePath}" | pbcopy`;
        }
        return null;
    }

    function getBrowserCommand(url) {
        const platform = process.platform;
        if (platform === 'win32') {
            return `powershell -Command "Start-Process ${url}"`;
        } else if (platform === 'darwin') {
            return `open "${url}"`;
        }
        return null;
    }

    function checkAllFilesExistInFolder(fileNames, folderPath) {
        try {
            const normalize = (s) => s.normalize('NFC');
            const filesInDir = fs.readdirSync(folderPath);
            const filesInDirNormalized = filesInDir.map(normalize);
            return fileNames.every((file) => filesInDirNormalized.includes(file));
        } catch (err) {
            console.error(`ディレクトリの読み込みエラー: ${err}`);
            return false;
        }
    }

    function ensureOutputFolders() {
        const dirs = [
            '0_RDRAZeroOne/phase1',
            '0_RDRAZeroOne/phase2',
            '0_RDRAZeroOne/phase3',
            '0_RDRAZeroOne/phase4',
            '1_RDRA',
            '1_RDRA/if',
            '2_RDRASpec',
            '2_RDRASpec/phase1',
            '2_RDRASpec/phase2',
        ];
        dirs.forEach((dir) => {
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
                console.log(`フォルダーを作成しました: ${dir}`);
            }
        });
    }

    const waitForEnter =
        typeof waitForEnterThenNext === 'function'
            ? waitForEnterThenNext
            : () => {
                  rl.question('続行するにはEnterキーを押してください... (Enter)\n', () => {
                      promptUser();
                  });
              };

    function getProjectRoot() {
        return dagRunner.findProjectRootByInitialRequest(process.cwd());
    }

    /**
     * メニュー1: Phase1〜4 と 1_RDRA を削除し、DAG で一括生成
     */
    function executeFromScratch() {
        ensureOutputFolders();
        const root = getProjectRoot();
        console.log('Phase1〜Phase4、1_RDRA、2_RDRASpec、3_RDRASdd配下を削除します...');
        for (let i = 1; i <= 4; i++) {
            deleteFilesInFolder(`0_RDRAZeroOne/phase${i}`, root);
        }
        deleteFilesInFolder('1_RDRA', root);
        deleteFilesInFolder('2_RDRASpec', root);
        deleteFilesInFolder('3_RDRASdd', root);
        console.log('削除完了。一括生成します...');
        dagRunner
            .runMenu8(root)
            .then(() => {
                console.log('');
                console.log('処理が完了しました。');
                waitForEnter();
            })
            .catch((err) => {
                console.error(err.message || err);
                waitForEnter();
            });
    }

    /**
     * メニュー7: 未完了の最小フェーズを 1 回だけ実行（従来のフェーズ単位）
     */
    function executeEachPhase() {
        ensureOutputFolders();
        const root = getProjectRoot();
        dagRunner
            .runMenu7(root)
            .then(() => {
                console.log('');
                console.log('処理が完了しました。');
                waitForEnter();
            })
            .catch((err) => {
                console.error(err.message || err);
                waitForEnter();
            });
    }

    /**
     * メニュー8: 依存 DAG に基づき未生成ノードを波状並列実行
     */
    function executeAllPhase() {
        ensureOutputFolders();
        console.log('全フェーズのRDRA定義を行います（DAG 並列）...');
        const root = getProjectRoot();
        dagRunner
            .runMenu8(root)
            .then(() => {
                console.log('');
                console.log('処理が完了しました。');
                waitForEnter();
            })
            .catch((err) => {
                console.error(err.message || err);
                waitForEnter();
            });
    }

    function executeSpec() {
        console.log('仕様の作成を実行します（phase1 → phase2）...');
        const specTimeoutMs = 600000;

        const outputDir = '2_RDRASpec';
        if (!fs.existsSync(outputDir)) {
            fs.mkdirSync(outputDir, { recursive: true });
            console.log(`出力フォルダを作成しました: ${outputDir}`);
        }
        const phase1Dir = '2_RDRASpec/phase1';
        if (!fs.existsSync(phase1Dir)) {
            fs.mkdirSync(phase1Dir, { recursive: true });
            console.log(`出力フォルダを作成しました: ${phase1Dir}`);
        }

        const runParallel = async (promptMap) => {
            const args = promptMap.map((pair) => pair.prompt);
            console.log('実行するプロンプトファイル:');
            promptMap.forEach((pair) => {
                console.log(`  ${pair.prompt}`);
            });
            console.log('');

            try {
                const code = await new Promise((resolve, reject) => {
                    const child = spawn(
                        'node',
                        ['RDRA_Knowledge/helper_tools/parallelRun/parallel-runner.js', ...args, '--timeout', String(specTimeoutMs)],
                        {
                            stdio: 'inherit',
                            shell: true,
                        }
                    );
                    child.on('close', (exitCode) => resolve(exitCode ?? 1));
                    child.on('error', (error) => reject(error));
                });
                return code === 0 ? 0 : 1;
            } catch (error) {
                console.error(`エラー: ${error.message}`);
                return 1;
            }
        };

        (async () => {
            const code1 = await runParallel(specPhase1PromptMap);
            if (code1 !== 0) {
                console.error('仕様(phase1)がエラーで終了しました。');
                waitForEnterThenNext();
                return;
            }
            const code2 = await runParallel(specPhase2PromptMap);
            if (code2 === 0) {
                console.log('');
                console.log('仕様の作成が完了しました。');
            } else {
                console.error('仕様(phase2)がエラーで終了しました。');
            }
            waitForEnterThenNext();
        })();
    }

    function getMissingFiles(filePaths) {
        return filePaths.filter((filePath) => !fs.existsSync(filePath));
    }

    function getPendingSpecPrompts(promptMap) {
        return promptMap.filter((pair) => !pair.outputs || getMissingFiles(pair.outputs).length > 0);
    }

    function createSpecContinueSteps() {
        const [logicalData, businessRule, screenList, bucScreen, actorScreen] = specPhase1PromptMap;
        const [screenInquiry] = specPhase2PromptMap;

        return [
            {
                label: 'RDRASpec Step1: 論理データモデル/ビジネスルールの継続作成',
                promptMap: [logicalData, businessRule],
                requiredInputs: [],
            },
            {
                label: 'RDRASpec Step2: 画面一覧の継続作成',
                promptMap: [screenList],
                requiredInputs: ['2_RDRASpec/ビジネスルール.md'],
            },
            {
                label: 'RDRASpec Step3: BUC画面/アクター画面の継続作成',
                promptMap: [bucScreen, actorScreen],
                requiredInputs: ['2_RDRASpec/論理データモデル.md', '2_RDRASpec/phase1/画面一覧.json'],
            },
            {
                label: 'RDRASpec Step4: 画面照会の継続作成',
                promptMap: [screenInquiry],
                requiredInputs: [
                    '2_RDRASpec/論理データモデル.md',
                    '2_RDRASpec/phase1/BUC画面.json',
                    '2_RDRASpec/phase1/アクター画面.json',
                    '2_RDRASpec/phase1/画面一覧.json',
                ],
            },
        ];
    }

    async function runSpecContinueStep(step) {
        const missingInputs = getMissingFiles(step.requiredInputs);
        if (missingInputs.length > 0) {
            console.error(`${step.label}を実行できません。必要ファイルが不足しています:`);
            missingInputs.forEach((filePath) => console.error(`  ${filePath}`));
            return { ok: false, ran: false };
        }

        const pendingPromptMap = getPendingSpecPrompts(step.promptMap);
        if (pendingPromptMap.length === 0) {
            console.log(`${step.label}: 生成済みのためスキップします。`);
            return { ok: true, ran: false };
        }

        const code = await runPromptMap(pendingPromptMap, step.label);
        if (code !== 0) {
            console.error(`${step.label}がエラーで終了しました。`);
            return { ok: false, ran: true };
        }

        const missingOutputs = pendingPromptMap.flatMap((pair) => getMissingFiles(pair.outputs || []));
        if (missingOutputs.length > 0) {
            console.error(`${step.label}の実行後も出力ファイルが不足しています:`);
            missingOutputs.forEach((filePath) => console.error(`  ${filePath}`));
            return { ok: false, ran: true };
        }

        return { ok: true, ran: true };
    }

    function executeSpecContinue() {
        console.log('未作成の仕様の継続作成を実行します...');
        ensureOutputFolders();

        (async () => {
            let ranAny = false;
            for (const step of createSpecContinueSteps()) {
                const result = await runSpecContinueStep(step);
                ranAny = ranAny || result.ran;
                if (!result.ok) {
                    waitForEnterThenNext();
                    return;
                }
            }

            console.log('');
            console.log(ranAny ? '未作成の仕様の継続作成が完了しました。' : '未作成の仕様はありません。');
            waitForEnterThenNext();
        })();
    }

    function hasSpecBaseInputs() {
        return (
            fs.existsSync('2_RDRASpec/論理データモデル.md') &&
            fs.existsSync('2_RDRASpec/ビジネスルール.md') &&
            fs.existsSync('2_RDRASpec/画面照会.json')
        );
    }

    function runPromptMap(promptMap, label) {
        const specTimeoutMs = 600000;
        console.log(`${label}を実行します...`);

        return (async () => {
            const args = promptMap.map((pair) => pair.prompt);
            console.log('実行するプロンプトファイル:');
            promptMap.forEach((pair) => {
                console.log(`  ${pair.prompt}`);
            });
            console.log('');

            try {
                const code = await new Promise((resolve, reject) => {
                    const child = spawn(
                        'node',
                        ['RDRA_Knowledge/helper_tools/parallelRun/parallel-runner.js', ...args, '--timeout', String(specTimeoutMs)],
                        {
                            stdio: 'inherit',
                            shell: true,
                        }
                    );
                    child.on('close', (exitCode) => resolve(exitCode ?? 1));
                    child.on('error', (error) => reject(error));
                });
                return code === 0 ? 0 : 1;
            } catch (error) {
                console.error(`エラー: ${error.message}`);
                return 1;
            }
        })();
    }

    /**
     * domain / application / ui の部分 JSON を統合して 3_RDRASdd/_callgraph/callgraph_data.json を生成する。
     * @returns {Promise<number>} 成功時 0、失敗時 1
     */
    function runMergeCallgraphData() {
        return new Promise((resolve, reject) => {
            const root = getProjectRoot();
            const child = spawn(
                'node',
                ['RDRA_Knowledge/helper_tools/mergeCallgraphData.js'],
                {
                    stdio: 'inherit',
                    shell: true,
                    cwd: root,
                }
            );
            child.on('close', (exitCode) => resolve(exitCode === 0 ? 0 : 1));
            child.on('error', (error) => reject(error));
        });
    }

    /**
     * `3_RDRASdd/ui` 配下の .md ファイル数（再帰）。
     * @param {string} dir
     * @returns {number}
     */
    function countMarkdownFilesRecursive(dir) {
        if (!fs.existsSync(dir)) return 0;
        let n = 0;
        function walk(d) {
            let entries;
            try {
                entries = fs.readdirSync(d, { withFileTypes: true });
            } catch {
                return;
            }
            for (const e of entries) {
                const p = path.join(d, e.name);
                if (e.isDirectory()) walk(p);
                else if (e.isFile() && e.name.toLowerCase().endsWith('.md')) n += 1;
            }
        }
        walk(dir);
        return n;
    }

    /**
     * Callgraph 用の3つの部分 JSON が生成済みか検証する（mergeCallgraphData.js 実行前）。
     * @returns {{ ok: boolean, errors: string[] }}
     */
    function validateCallgraphPartialJsons() {
        const errors = [];
        const checks = [
            {
                rel: '3_RDRASdd/_callgraph/callgraph_domain_data.json',
                label: 'domain',
                validate: (obj) => {
                    if (!Array.isArray(obj.contexts) || !Array.isArray(obj.services) || !Array.isArray(obj.entities)) {
                        return 'contexts / services / entities は配列である必要があります。';
                    }
                    return null;
                },
            },
            {
                rel: '3_RDRASdd/_callgraph/callgraph_application_data.json',
                label: 'application',
                validate: (obj) => {
                    if (!Array.isArray(obj.appBucs) || !Array.isArray(obj.ucs)) {
                        return 'appBucs / ucs は配列である必要があります。';
                    }
                    return null;
                },
            },
            {
                rel: '3_RDRASdd/_callgraph/callgraph_ui_data.json',
                label: 'ui',
                validate: (obj) => {
                    if (!Array.isArray(obj.uiBucs) || !Array.isArray(obj.screens)) {
                        return 'uiBucs / screens は配列である必要があります。';
                    }
                    const uiMdCount = countMarkdownFilesRecursive('3_RDRASdd/ui');
                    if (uiMdCount > 0 && obj.screens.length === 0) {
                        return `3_RDRASdd/ui に .md が ${uiMdCount} 件あるのに screens が空です。`;
                    }
                    return null;
                },
            },
        ];

        for (const c of checks) {
            if (!fs.existsSync(c.rel)) {
                errors.push(
                    `部分的な JSON がありません: ${c.rel}（${c.label}）。対応する callgraph_${c.label}_data_maker.md がファイルを出力しなかった可能性があります。parallel-runner の該当ログを確認してください。`
                );
                continue;
            }
            let obj;
            try {
                obj = JSON.parse(fs.readFileSync(c.rel, 'utf8'));
            } catch (e) {
                errors.push(`${c.rel}: JSON として読めません (${e.message || e})`);
                continue;
            }
            const msg = c.validate(obj);
            if (msg) errors.push(`${c.rel}: ${msg}`);
        }

        return { ok: errors.length === 0, errors };
    }

    function executePromptMap(promptMap, label, postCheck) {
        (async () => {
            const code = await runPromptMap(promptMap, label);
            if (code === 0) {
                console.log('');
                console.log(`${label}が完了しました。`);
                if (typeof postCheck === 'function') {
                    try {
                        postCheck();
                    } catch (e) {
                        console.warn(`[SDD事後チェック] 例外: ${e.message || e}`);
                    }
                }
            } else {
                console.error(`${label}がエラーで終了しました。`);
            }
            waitForEnter();
        })();
    }

    function ensureRdraFuncFolders() {
        const dirs = ['3_RDRASdd/domain', '3_RDRASdd/application', '3_RDRASdd/ui'];
        dirs.forEach((dir) => {
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
                console.log(`フォルダーを作成しました: ${dir}`);
            }
        });
    }

    function deleteRdraFuncFoldersBefore(folders) {
        const root = getProjectRoot();
        folders.forEach((folder) => deleteFolderRecursive(folder, root));
    }

    function hasJsonFiles(dir) {
        if (!fs.existsSync(dir)) return false;
        try {
            return fs.readdirSync(dir).some((name) => name.toLowerCase().endsWith('.json'));
        } catch {
            return false;
        }
    }

    function validateUiAppJson(root) {
        const rel = '3_RDRASdd/.work/uiApp.json';
        const abs = path.join(root, ...rel.split('/'));
        let data;
        try {
            data = JSON.parse(fs.readFileSync(abs, 'utf8'));
        } catch (e) {
            return { ok: false, message: `SDD Step2: ${rel} が有効な JSON として読めません: ${e.message || e}` };
        }

        if (!data || typeof data !== 'object' || Array.isArray(data)) {
            return { ok: false, message: `SDD Step2: ${rel} のトップレベルは JSON オブジェクトである必要があります。` };
        }
        if (!Array.isArray(data.BUC一覧) || data.BUC一覧.length === 0) {
            return { ok: false, message: `SDD Step2: ${rel} に BUC一覧 配列がありません。` };
        }

        const errors = [];
        data.BUC一覧.forEach((buc, i) => {
            const label = `BUC一覧[${i}]`;
            if (!buc || typeof buc !== 'object' || Array.isArray(buc)) {
                errors.push(`${label} はオブジェクトである必要があります。`);
                return;
            }
            if (typeof buc.BUC名 !== 'string' || !buc.BUC名.trim()) {
                errors.push(`${label}.BUC名 が空です。`);
            }
            if (!Array.isArray(buc.画面一覧)) {
                errors.push(`${label}.画面一覧 は配列である必要があります。`);
            }
            if (!Array.isArray(buc.UC一覧)) {
                errors.push(`${label}.UC一覧 は配列である必要があります。`);
            }
        });

        if (errors.length > 0) {
            return { ok: false, message: `SDD Step2: ${rel} の構造が不正です。\n  - ${errors.join('\n  - ')}` };
        }
        return { ok: true, data };
    }

    function validateUiAppBucNames(uiAppData, bucEntries) {
        const expected = new Set(bucEntries.map((e) => e.bucJapaneseName));
        const actual = new Set(uiAppData.BUC一覧.map((buc) => buc.BUC名));
        const missing = [...expected].filter((name) => !actual.has(name));
        const extra = [...actual].filter((name) => !expected.has(name));
        if (missing.length === 0 && extra.length === 0) {
            return { ok: true };
        }
        const parts = [];
        if (missing.length > 0) parts.push(`不足 BUC: ${missing.join(', ')}`);
        if (extra.length > 0) parts.push(`画面照会.json に存在しない BUC: ${extra.join(', ')}`);
        return {
            ok: false,
            message: `SDD Step2: uiApp.json の BUC名 は 2_RDRASpec/画面照会.json の buc_name と完全一致する必要があります。${parts.join(' / ')}`,
        };
    }

    function reportUIBucChecks(root, bucEntries) {
        let bucCheckOk = true;
        for (const e of bucEntries) {
            const r = sddPostCheck.checkUIBuc(root, e.folderName);
            if (!r.ok) {
                bucCheckOk = false;
                console.warn(
                    `[SDD事後チェック] BUC「${e.bucJapaneseName}」フォルダー \`${e.folderName}\`: 期待 ${r.expected} / 実際 ${r.actual}、不足 ${r.missingCount}`
                );
                if (r.underscoreFiles.length > 0) {
                    console.warn(`  先頭 _ の .json: ${r.underscoreFiles.length} 件`);
                }
            }
        }
        if (!bucCheckOk) {
            console.error('[SDD事後チェック] BUC 単位の画面数が一致しません。');
        } else {
            console.log('');
            console.log('UI仕様書の作成が完了しました。');
        }
        return bucCheckOk;
    }

    function reportSddCheck(label, reporter, root) {
        try {
            return reporter(root);
        } catch (e) {
            console.warn(`[SDD事後チェック] ${label}: 例外: ${e.message || e}`);
            return null;
        }
    }



    function executeSddContinue() {
        if (!fs.existsSync('1_RDRA/if/関連データ.txt') || !hasSpecBaseInputs()) {
            console.log(
                '実行に必要なファイルが不足しています。必要ファイル: 1_RDRA/*, 1_RDRA/if/関連データ.txt, 2_RDRASpec/論理データモデル.md, 2_RDRASpec/ビジネスルール.md, 2_RDRASpec/画面照会.json'
            );
            waitForEnter();
            return;
        }

        (async () => {
            const root = getProjectRoot();
            let ranAny = false;
            ensureRdraFuncFolders();

            let domainCheck = reportSddCheck('domain', sddPostCheck.reportDomain, root);
            if (domainCheck && domainCheck.ok) {
                console.log('SDD Step1: ドメイン仕様は生成済みのためスキップします。');
            } else {
                const step1Code = await runPromptMap(createDomainPromptMap, 'SDD Step1: ドメイン仕様の継続作成');
                ranAny = true;
                if (step1Code !== 0) {
                    console.error('SDD Step1: ドメイン仕様の継続作成がエラーで終了しました。');
                    waitForEnter();
                    return;
                }
                if (!hasJsonFiles('3_RDRASdd/domain')) {
                    console.error('SDD Step1: 3_RDRASdd/domain に JSON が生成されていません。');
                    waitForEnter();
                    return;
                }
                domainCheck = reportSddCheck('domain', sddPostCheck.reportDomain, root);
                if (!domainCheck || !domainCheck.ok) {
                    console.error('SDD Step1: ドメイン仕様の件数が期待値と一致しないため停止します。');
                    waitForEnter();
                    return;
                }
            }

            // ① uiApp.json を先にチェック（buildMenu33PromptMap より前に実施）
            // メニュー32では .work を削除せず、buildMenu33PromptMap() は UI 用 md のみ上書きする。
            let uiAppCheck = fs.existsSync('3_RDRASdd/.work/uiApp.json')
                ? validateUiAppJson(root)
                : { ok: false, message: 'SDD Step2: 3_RDRASdd/.work/uiApp.json が生成されていません。' };
            if (uiAppCheck.ok) {
                console.log('SDD Step2: Base仕様は生成済みのためスキップします。');
            } else {
                console.warn(uiAppCheck.message);
                const step2Code = await runPromptMap(createBasePromptMap, 'SDD Step2: Base仕様の継続作成');
                ranAny = true;
                if (step2Code !== 0) {
                    console.error('SDD Step2: Base仕様の継続作成がエラーで終了しました。');
                    waitForEnter();
                    return;
                }
                if (!fs.existsSync('3_RDRASdd/.work/uiApp.json')) {
                    console.error('SDD Step2: 3_RDRASdd/.work/uiApp.json が生成されていません。');
                    waitForEnter();
                    return;
                }
                uiAppCheck = validateUiAppJson(root);
                if (!uiAppCheck.ok) {
                    console.error(uiAppCheck.message);
                    waitForEnter();
                    return;
                }
            }

            // ② buildMenu33PromptMap で UI 用 md を上書き生成（uiApp.json はディスク上に保持）
            let built33 = buildMenu33PromptMap(root);
            if (!built33.ok) {
                console.error(built33.message);
                waitForEnter();
                return;
            }

            // ③ BUC名照合はメモリのデータで実施（ファイル再読みしない）
            const uiAppBucCheck = validateUiAppBucNames(uiAppCheck.data, built33.bucEntries);
            if (!uiAppBucCheck.ok) {
                console.error(uiAppBucCheck.message);
                waitForEnter();
                return;
            }

            let applicationCheck = reportSddCheck('application', sddPostCheck.reportApplication, root);
            if (applicationCheck && applicationCheck.ok) {
                console.log('SDD Step3: Application仕様は生成済みのためスキップします。');
            } else {
                const applicationCode = await runPromptMap(createApplicationPromptMap, 'SDD Step3: Application仕様の継続作成');
                ranAny = true;
                if (applicationCode !== 0) {
                    console.error('SDD Step3: Application仕様の継続作成がエラーで終了しました。');
                    waitForEnter();
                    return;
                }
                applicationCheck = reportSddCheck('application', sddPostCheck.reportApplication, root);
                if (!applicationCheck || !applicationCheck.ok) {
                    console.error('SDD Step3: Application仕様の件数が期待値と一致しないため停止します。');
                    waitForEnter();
                    return;
                }
            }

            const pendingUiPromptMap = [];
            for (const e of built33.bucEntries) {
                const r = sddPostCheck.checkUIBuc(root, e.folderName);
                if (!r.ok) {
                    const prompt = built33.promptMap.find((pair) => pair.prompt.includes(`34_Create_UI__${e.folderName}.md`));
                    if (!prompt) {
                        console.error(`SDD Step3: BUC「${e.bucJapaneseName}」の UI プロンプトが見つかりません。`);
                        waitForEnter();
                        return;
                    }
                    pendingUiPromptMap.push(prompt);
                }
            }

            if (pendingUiPromptMap.length === 0) {
                console.log('SDD Step3: UI仕様は生成済みのためスキップします。');
            } else {
                const uiCode = await runPromptMap(pendingUiPromptMap, 'SDD Step3: UI仕様の継続作成');
                ranAny = true;
                if (uiCode !== 0) {
                    console.error('SDD Step3: UI仕様の継続作成がエラーで終了しました。');
                    waitForEnter();
                    return;
                }
            }

            applicationCheck = reportSddCheck('application', sddPostCheck.reportApplication, root);
            if (!applicationCheck || !applicationCheck.ok) {
                console.error('SDD Step3: Application仕様の件数が期待値と一致しないため停止します。');
                waitForEnter();
                return;
            }
            const uiBucCheckOk = reportUIBucChecks(root, built33.bucEntries);
            if (!uiBucCheckOk) {
                waitForEnter();
                return;
            }
            const uiCheck = reportSddCheck('ui', sddPostCheck.reportUI, root);
            if (!uiCheck || !uiCheck.ok) {
                console.error('SDD Step3: UI仕様の件数が期待値と一致しないため停止します。');
                waitForEnter();
                return;
            }
            console.log('');
            console.log(ranAny ? '未作成のSDD仕様書の継続作成が完了しました。' : '未作成のSDD仕様書はありません。');
            waitForEnter();
        })();
    }

    function executeSddAll() {
        if (!fs.existsSync('1_RDRA/if/関連データ.txt') || !hasSpecBaseInputs()) {
            console.log(
                '実行に必要なファイルが不足しています。必要ファイル: 1_RDRA/*, 1_RDRA/if/関連データ.txt, 2_RDRASpec/論理データモデル.md, 2_RDRASpec/ビジネスルール.md, 2_RDRASpec/画面照会.json'
            );
            waitForEnter();
            return;
        }

        (async () => {
            const root = getProjectRoot();
            deleteRdraFuncFoldersBefore([
                '3_RDRASdd/domain',
                '3_RDRASdd/application',
                '3_RDRASdd/ui',
                '3_RDRASdd/.work',
            ]);
            ensureRdraFuncFolders();

            const step1Code = await runPromptMap(createDomainPromptMap, 'SDD Step1: ドメイン仕様の作成');
            if (step1Code !== 0) {
                console.error('SDD Step1: ドメイン仕様の作成がエラーで終了しました。');
                waitForEnter();
                return;
            }
            if (!hasJsonFiles('3_RDRASdd/domain')) {
                console.error('SDD Step1: 3_RDRASdd/domain に JSON が生成されていません。');
                waitForEnter();
                return;
            }
            let domainCheck;
            try {
                domainCheck = sddPostCheck.reportDomain(root);
            } catch (e) {
                console.warn(`[SDD事後チェック] 例外: ${e.message || e}`);
            }
            if (!domainCheck || !domainCheck.ok) {
                console.error('SDD Step1: ドメイン仕様の件数が期待値と一致しないため停止します。');
                waitForEnter();
                return;
            }

            const step2Code = await runPromptMap(createBasePromptMap, 'SDD Step2: Base仕様の作成');
            if (step2Code !== 0) {
                console.error('SDD Step2: Base仕様の作成がエラーで終了しました。');
                waitForEnter();
                return;
            }
            if (!fs.existsSync('3_RDRASdd/.work/uiApp.json')) {
                console.error('SDD Step2: 3_RDRASdd/.work/uiApp.json が生成されていません。');
                waitForEnter();
                return;
            }
            const uiAppCheck = validateUiAppJson(root);
            if (!uiAppCheck.ok) {
                console.error(uiAppCheck.message);
                waitForEnter();
                return;
            }

            const built33 = buildMenu33PromptMap(root);
            if (!built33.ok) {
                console.error(built33.message);
                waitForEnter();
                return;
            }
            const uiAppBucCheck = validateUiAppBucNames(uiAppCheck.data, built33.bucEntries);
            if (!uiAppBucCheck.ok) {
                console.error(uiAppBucCheck.message);
                waitForEnter();
                return;
            }
            const step3PromptMap = [...createApplicationPromptMap, ...built33.promptMap];
            const step3Code = await runPromptMap(step3PromptMap, 'SDD Step3: Application/UI仕様の作成');
            if (step3Code !== 0) {
                console.error('SDD Step3: Application/UI仕様の作成がエラーで終了しました。');
                waitForEnter();
                return;
            }
            let applicationCheck;
            try {
                applicationCheck = sddPostCheck.reportApplication(root);
            } catch (e) {
                console.warn(`[SDD事後チェック] 例外: ${e.message || e}`);
            }
            if (!applicationCheck || !applicationCheck.ok) {
                console.error('SDD Step3: Application仕様の件数が期待値と一致しないため停止します。');
                waitForEnter();
                return;
            }
            const uiBucCheckOk = reportUIBucChecks(root, built33.bucEntries);
            if (!uiBucCheckOk) {
                waitForEnter();
                return;
            }
            let uiCheck;
            try {
                uiCheck = sddPostCheck.reportUI(root);
            } catch (e) {
                console.warn(`[SDD事後チェック] 例外: ${e.message || e}`);
            }
            if (!uiCheck || !uiCheck.ok) {
                console.error('SDD Step3: UI仕様の件数が期待値と一致しないため停止します。');
                waitForEnter();
                return;
            }
            console.log('');
            console.log('SDD仕様書の作成が完了しました。');
            waitForEnter();
        })();
    }

    function showRDRAGraph() {
        console.log('関連データを作成しています...');
        exec('node RDRA_Knowledge/helper_tools/makeGraphData.js', (error) => {
            if (error) {
                console.error(`エラー: ${error}`);
                promptUser();
                return;
            }
            console.log('関連データの作成が完了しました。');
            console.log('RDRAGraphを表示しています...');

            const clipboardCmd = getClipboardCommand('1_RDRA/if/関連データ.txt');
            const browserCmd = getBrowserCommand(grahUrl);

            if (!clipboardCmd || !browserCmd) {
                console.error('このOSではクリップボード操作またはブラウザ起動がサポートされていません。');
                promptUser();
                return;
            }

            exec(clipboardCmd, (clipError) => {
                if (clipError) {
                    console.error(`クリップボードエラー: ${clipError}`);
                } else {
                    console.log('データをクリップボードにコピーしました。');
                    exec(browserCmd, (browserError) => {
                        if (browserError) {
                            console.error(`ブラウザ起動エラー: ${browserError}`);
                        } else {
                            console.log('ブラウザでRDRAGraphを開きました。');
                        }
                        promptUser();
                    });
                }
            });
        });
    }

    function makeZeroOneData() {
        console.log('ZeroOneデータをクリップボードにコピーします...');
        exec('node RDRA_Knowledge/helper_tools/makeZeroOneData.js', (error, stdout, stderr) => {
            if (error) {
                console.error(`エラー: ${error}`);
                promptUser();
                return;
            }
            if (stdout) console.log(stdout);
            if (stderr) console.error(stderr);
            console.log('ZeroOneデータの処理が完了しました。');

            exec('node RDRA_Knowledge/helper_tools/copyToClipboard.js zeroone', (error2, stdout2, stderr2) => {
                if (error2) {
                    console.error(`エラー: ${error2}`);
                    promptUser();
                    return;
                }
                if (stdout2) console.log(stdout2);
                if (stderr2) console.error(stderr2);
                console.log('データはクリップボードにコピーされました。スプレッドシートに貼り付けてください。');

                const browserCmd = getBrowserCommand(
                    'https://docs.google.com/spreadsheets/d/1h7J70l6DyXcuG0FKYqIpXXfdvsaqjdVFwc6jQXSh9fM/edit?gid=1240873646#gid=1240873646'
                );
                if (browserCmd) {
                    exec(browserCmd, (browserError) => {
                        if (browserError) {
                            console.error(`ブラウザ起動エラー: ${browserError}`);
                        } else {
                            console.log('スプレッドシートをブラウザで開きました。');
                        }
                        promptUser();
                    });
                } else {
                    promptUser();
                }
            });
        });
    }

    function showActorUI() {
        console.log('画面照会（BUC/アクター）を表示する');
        if (!fs.existsSync('2_RDRASpec/画面照会.json') && !fs.existsSync('2_RDRASpec/ui.json')) {
            console.error('エラー: 2_RDRASpec/画面照会.json（または ui.json）が存在しません。');
            console.error('先にメニュー21で仕様ファイルを作成してください。');
            promptUser();
            return;
        }

        const existingServer = global.bucActorUIServer;
        const isServerRunning = existingServer && existingServer.exitCode === null && !existingServer.killed;

        if (isServerRunning) {
            console.log('サーバーは既に起動しています。ブラウザで画面を開きます...');
            const browserCmd = getBrowserCommand('http://localhost:3002/');
            if (browserCmd) {
                exec(browserCmd, (browserError) => {
                    if (browserError) console.error(`ブラウザ起動エラー: ${browserError}`);
                });
            }
            console.log('画面照会（BUC/アクター）を表示しました。');
            promptUser();
            return;
        }

        if (existingServer && !isServerRunning) {
            global.bucActorUIServer = null;
        }

        console.log('HTTPサーバーを起動してブラウザで画面を開きます...');
        const serverProcess = spawn('node', ['RDRA_Knowledge/helper_tools/web_tool/bucActorUI.js'], {
            stdio: ['pipe', 'pipe', 'pipe'],
            detached: false,
        });

        let serverStarted = false;
        serverProcess.stdout.on('data', (data) => {
            console.log(`${data}`);
            if (!serverStarted && data.toString().includes('簡易HTTPサーバーが起動しました')) {
                serverStarted = true;
                setTimeout(() => {
                    const browserCmd = getBrowserCommand('http://localhost:3002/');
                    if (browserCmd) {
                        exec(browserCmd, (browserError) => {
                            if (browserError) console.error(`ブラウザ起動エラー: ${browserError}`);
                        });
                    }
                }, 500);
            }
        });
        serverProcess.stderr.on('data', (data) => {
            console.error(`${data}`);
        });
        serverProcess.on('error', (error) => {
            console.error(`サーバー起動エラー: ${error}`);
        });
        serverProcess.on('close', () => {
            console.log('画面照会（BUC/アクター）サーバーが終了しました。');
            global.bucActorUIServer = null;
        });
        global.bucActorUIServer = serverProcess;
        console.log('画面照会（BUC/アクター）を表示しました。');
        console.log('画面の「閉じる」ボタン、またはタブ/ブラウザを閉じると自動でサーバーが停止します。');
        promptUser();
    }

    function showCallgraphUI() {
        console.log('Callgraphを表示する');
        const hasRdraFuncOutputs =
            fs.existsSync('3_RDRASdd/domain') &&
            fs.existsSync('3_RDRASdd/application') &&
            fs.existsSync('3_RDRASdd/ui');
        if (!hasRdraFuncOutputs) {
            console.error('エラー: 3_RDRASdd/domain, 3_RDRASdd/application, 3_RDRASdd/ui が不足しています。');
            console.error('先にメニュー31〜33で機能仕様を作成してください。');
            promptUser();
            return;
        }

        const existingServer = global.callgraphServer;
        const isServerRunning = existingServer && existingServer.exitCode === null && !existingServer.killed;
        const callgraphUrl = 'http://127.0.0.1:3000/callgraphView.html';
        if (isServerRunning) {
            console.log('Callgraphサーバーは既に起動しています。ブラウザで画面を開きます...');
            const browserCmd = getBrowserCommand(callgraphUrl);
            if (browserCmd) {
                exec(browserCmd, (browserError) => {
                    if (browserError) console.error(`ブラウザ起動エラー: ${browserError}`);
                });
            }
            promptUser();
            return;
        }
        if (existingServer && !isServerRunning) {
            global.callgraphServer = null;
        }

        const serverProcess = spawn('node', ['RDRA_Knowledge/helper_tools/callgraph/callgraphServer.js'], {
            stdio: ['pipe', 'pipe', 'pipe'],
            detached: false,
        });
        let serverStarted = false;
        serverProcess.stdout.on('data', (data) => {
            const text = data.toString();
            console.log(text);
            if (!serverStarted && text.includes('callgraphServer: listening on ')) {
                serverStarted = true;
                setTimeout(() => {
                    const browserCmd = getBrowserCommand(callgraphUrl);
                    if (browserCmd) {
                        exec(browserCmd, (browserError) => {
                            if (browserError) console.error(`ブラウザ起動エラー: ${browserError}`);
                        });
                    }
                }, 500);
            }
        });
        serverProcess.stderr.on('data', (data) => {
            console.error(`${data}`);
        });
        serverProcess.on('error', (error) => {
            console.error(`サーバー起動エラー: ${error}`);
        });
        serverProcess.on('close', () => {
            console.log('Callgraphサーバーが終了しました。');
            global.callgraphServer = null;
        });
        global.callgraphServer = serverProcess;
        console.log('Callgraphサーバーを起動しました。');
        console.log('画面の「閉じる」ボタンでサーバーを停止できます。');
        promptUser();
    }

    function deleteGeneratedFiles() {
        console.log('生成された成果物を削除しています...');
        try {
            deleteAllArtifacts(getProjectRoot());
            console.log('成果物の削除が完了しました。');
        } catch (e) {
            console.error(`エラー: ${e.message || e}`);
        }
        promptUser();
    }

    function exitProgram() {
        console.log('プログラムを終了します。');
        if (global.bucActorUIServer) {
            global.bucActorUIServer.kill('SIGTERM');
        }
        if (global.callgraphServer) {
            global.callgraphServer.kill('SIGTERM');
        }
        rl.close();
        process.exit(0);
    }

    function executeOption(option) {
        switch (option) {
            case '1':
                executeFromScratch();
                break;
            case '2':
                executeEachPhase();
                break;
            case '3':
                executeAllPhase();
                break;
            case '11':
                if (checkAllFilesExistInFolder(rdraFiles, '1_RDRA')) {
                    console.log('RDRAGraphを表示する。');
                    showRDRAGraph();
                } else {
                    console.log('1_RDRAフォルダーにRDRA定義が生成されていません。');
                    waitForEnter();
                }
                break;
            case '12':
                if (checkAllFilesExistInFolder(rdraFiles, '1_RDRA')) {
                    console.log('ZeroOneデータをクリップボードにコピーします...');
                    makeZeroOneData();
                } else {
                    console.log('1_RDRAフォルダーにRDRA定義が生成されていません。');
                    waitForEnter();
                }
                break;
            case '21':
                if (checkAllFilesExistInFolder(rdraFiles, '1_RDRA') && fs.existsSync('1_RDRA/if/関連データ.txt')) {
                    executeSpec();
                } else {
                    console.log(
                        '1_RDRA または 1_RDRA/if/関連データ.txt が不足しています。先にRDRA定義を生成し、メニュー11で関連データを作成してください。'
                    );
                    waitForEnter();
                }
                break;
            case '22':
                if (checkAllFilesExistInFolder(rdraFiles, '1_RDRA') && fs.existsSync('1_RDRA/if/関連データ.txt')) {
                    executeSpecContinue();
                } else {
                    console.log(
                        '1_RDRA または 1_RDRA/if/関連データ.txt が不足しています。先にRDRA定義を生成し、メニュー11で関連データを作成してください。'
                    );
                    waitForEnter();
                }
                break;
            case '23': {
                const hasSpecPhase1Outputs =
                    fs.existsSync('2_RDRASpec/論理データモデル.md') && fs.existsSync('2_RDRASpec/ビジネスルール.md');
                const hasScreenJson =
                    fs.existsSync('2_RDRASpec/画面照会.json') || fs.existsSync('2_RDRASpec/ui.json');
                if (hasSpecPhase1Outputs && hasScreenJson) {
                    console.log('画面照会（BUC/アクター）を表示する。');
                    showActorUI();
                } else {
                    console.log('2_RDRASpecフォルダーに仕様ファイルが生成されていません。');
                    console.log('必要ファイル: 論理データモデル.md / ビジネスルール.md / 画面照会.json');
                    waitForEnter();
                }
                break;
            }
            case '31':
                executeSddAll();
                break;
            case '32':
                executeSddContinue();
                break;
            case '33':
                showCallgraphUI();
                break;
            case '34':

                break;
            case '0':
                exitProgram();
                break;
            case '99':
                deleteGeneratedFiles();
                break;
            default:
                console.log('無効な選択肢です。選択肢の番号を入力してください。');
                promptUser();
                break;
        }
    }

    return executeOption;
}

module.exports = { createMenuAction };
