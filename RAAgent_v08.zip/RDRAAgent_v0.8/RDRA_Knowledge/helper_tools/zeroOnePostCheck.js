#!/usr/bin/env node
/* eslint-disable no-console */
'use strict';

const fs = require('fs');
const path = require('path');

const INITIAL = '初期要望.txt';

function findProjectRoot(startDir) {
  let dir = path.resolve(startDir);
  const { root } = path.parse(dir);
  while (true) {
    if (fs.existsSync(path.join(dir, INITIAL))) {
      return dir;
    }
    if (dir === root) {
      throw new Error(`${INITIAL} が見つからず、プロジェクトルートを特定できません`);
    }
    dir = path.dirname(dir);
  }
}

function readText(filePath) {
  if (!fs.existsSync(filePath)) {
    throw new Error(`Input file not found: ${filePath}`);
  }
  return fs.readFileSync(filePath, { encoding: 'utf8' });
}

function splitLines(text) {
  const lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
  if (lines.length > 0 && lines[lines.length - 1] === '') lines.pop();
  return lines;
}

function parseTsv(filePath) {
  const lines = splitLines(readText(filePath)).filter((line) => line !== '');
  if (lines.length === 0) {
    throw new Error(`TSV is empty: ${filePath}`);
  }

  const header = lines[0].split('\t');
  const rows = lines.slice(1).map((line) => {
    const cols = line.split('\t');
    while (cols.length < header.length) cols.push('');
    return cols;
  });

  return { header, rows };
}

function colIndex(header, name, label) {
  const idx = header.indexOf(name);
  if (idx === -1) {
    throw new Error(`Missing column "${name}" in ${label}. Header: ${header.join(', ')}`);
  }
  return idx;
}

function normalizeToken(value) {
  return String(value ?? '').trim();
}

function parseList(cell) {
  return normalizeToken(cell)
    .split(/[、,，]/g)
    .map((part) => part.trim())
    .filter(Boolean);
}

function addListToSet(set, cell) {
  for (const token of parseList(cell)) {
    set.add(token);
  }
}

function buildBucIndex(bucTsv) {
  const stateModelIdx = colIndex(bucTsv.header, '状態モデル', 'phase3/ph3BUC.tsv');
  const fromStateIdx = colIndex(bucTsv.header, 'From状態', 'phase3/ph3BUC.tsv');
  const toStateIdx = colIndex(bucTsv.header, 'To状態', 'phase3/ph3BUC.tsv');

  const allowedStateModels = new Set();
  const stateValues = new Set();

  for (const row of bucTsv.rows) {
    addListToSet(allowedStateModels, row[stateModelIdx]);
    addListToSet(stateValues, row[fromStateIdx]);
    addListToSet(stateValues, row[toStateIdx]);
  }

  return { allowedStateModels, stateValues };
}

function validateInfoStateModels({ infoTsv, allowedStateModels, stateValues }) {
  const infoIdx = colIndex(infoTsv.header, '情報', 'phase4/ph4情報.tsv');
  const stateModelIdx = colIndex(infoTsv.header, '状態モデル', 'phase4/ph4情報.tsv');
  const errors = [];
  const infoStateModels = new Set();

  infoTsv.rows.forEach((row, rowIndex) => {
    const infoName = normalizeToken(row[infoIdx]);
    const tokens = parseList(row[stateModelIdx]);

    for (const token of tokens) {
      infoStateModels.add(token);
      if (!allowedStateModels.has(token)) {
        const stateValueNote = stateValues.has(token) ? '（From状態/To状態の値が混入している可能性があります）' : '';
        errors.push(
          `ph4情報.tsv ${rowIndex + 2}行目「${infoName}」: 未定義の状態モデル「${token}」${stateValueNote}`
        );
      }
    }
  });

  return { errors, infoStateModels };
}

function main() {
  const root = findProjectRoot(process.cwd());
  const bucPath = path.join(root, '0_RDRAZeroOne', 'phase3', 'ph3BUC.tsv');
  const infoPath = path.join(root, '0_RDRAZeroOne', 'phase4', 'ph4情報.tsv');

  const bucTsv = parseTsv(bucPath);
  const infoTsv = parseTsv(infoPath);

  const { allowedStateModels, stateValues } = buildBucIndex(bucTsv);
  const infoResult = validateInfoStateModels({ infoTsv, allowedStateModels, stateValues });

  const errors = infoResult.errors;
  if (errors.length > 0) {
    console.error('[ZeroOne事後チェック] ph4情報.tsv の状態モデル整合性エラー');
    for (const error of errors) {
      console.error(`- ${error}`);
    }
    process.exit(1);
  }

  console.log('[ZeroOne事後チェック] ph4情報.tsv の状態モデル整合性 OK');
}

if (require.main === module) {
  try {
    main();
  } catch (error) {
    console.error(`[ZeroOne事後チェック] 例外: ${error.message || error}`);
    process.exit(1);
  }
}

module.exports = {
  parseList,
  buildBucIndex,
  validateInfoStateModels,
};
