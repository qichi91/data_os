'use strict';

/**
 * メニュー33・SDD 事後チェック共通: 画面照会.json の BUC 日本語名から
 * `3_RDRASdd/ui/<フォルダー名>/` に使う安全なフォルダー名を決定する。
 * `3_RDRASdd/application/` は参照しない。
 */

const fs = require('fs');
const path = require('path');

const SCREEN_JSON_CANDIDATES = ['2_RDRASpec/画面照会.json', '2_RDRASpec/ui.json'];

const MAX_BASE_LEN = 120;

/**
 * Windows / 一般的な FS で問題になりやすい文字を置換する。
 * @param {string} raw
 * @returns {string}
 */
function normalizeBucFolderName(raw) {
    let s = String(raw || '').trim();
    if (!s) return 'BUC_empty';
    s = s.replace(/[<>:"/\\|?*\x00-\x1f]/g, '_');
    s = s.replace(/[. ]+$/g, '');
    s = s.replace(/_+/g, '_').replace(/^_|_$/g, '');
    if (!s) s = 'BUC_empty';
    if (s.length > MAX_BASE_LEN) {
        s = s.slice(0, MAX_BASE_LEN).replace(/[. _]+$/g, '');
        if (!s) s = 'BUC_long';
    }
    return s;
}

/**
 * @param {string} projectRoot
 * @returns {string|null} 存在する画面照会 JSON の絶対パス
 */
function findScreenInquiryJsonPath(projectRoot) {
    for (const rel of SCREEN_JSON_CANDIDATES) {
        const p = path.join(projectRoot, ...rel.split('/'));
        if (fs.existsSync(p)) return p;
    }
    return null;
}

/**
 * 正規化後の衝突を `__2`, `__3`, ... で解消する。
 * @param {{ bucJapaneseName: string, businessName?: string }[]} entries
 * @returns {{ bucJapaneseName: string, businessName: string, folderName: string }[]}
 */
function assignUniqueFolderNames(entries) {
    const used = new Set();
    const out = [];
    for (const e of entries) {
        const jp = e.bucJapaneseName;
        const base = normalizeBucFolderName(jp);
        let f = base;
        let n = 2;
        while (used.has(f)) {
            const suffix = `__${n}`;
            const room = Math.max(1, MAX_BASE_LEN - suffix.length);
            f = base.slice(0, room) + suffix;
            n += 1;
        }
        used.add(f);
        out.push({
            bucJapaneseName: jp,
            businessName: typeof e.businessName === 'string' ? e.businessName : '',
            folderName: f,
        });
    }
    return out;
}

/**
 * `businesses[].BUCs[]` を走査し、`buc_name` ごとに先勝ちで 1 行ずつ返す。
 * @param {string} projectRoot
 * @returns {{ bucJapaneseName: string, businessName: string, folderName: string }[]}
 */
function listScreenInquiryBucUiEntries(projectRoot) {
    const jsonPath = findScreenInquiryJsonPath(projectRoot);
    if (!jsonPath) return [];
    let data;
    try {
        data = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
    } catch {
        return [];
    }
    const businesses = data.businesses;
    if (!Array.isArray(businesses)) return [];

    const seen = new Set();
    /** @type {{ bucJapaneseName: string, businessName: string }[]} */
    const raw = [];
    for (const b of businesses) {
        const biz = typeof b.business_name === 'string' ? b.business_name.trim() : '';
        const bucs = b.BUCs;
        if (!Array.isArray(bucs)) continue;
        for (const buc of bucs) {
            const name = typeof buc.buc_name === 'string' ? buc.buc_name.trim() : '';
            if (!name || seen.has(name)) continue;
            seen.add(name);
            raw.push({ bucJapaneseName: name, businessName: biz });
        }
    }
    return assignUniqueFolderNames(raw);
}

module.exports = {
    SCREEN_JSON_CANDIDATES,
    normalizeBucFolderName,
    findScreenInquiryJsonPath,
    listScreenInquiryBucUiEntries,
};
