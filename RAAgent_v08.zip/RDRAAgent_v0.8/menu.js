#!/usr/bin/env node

const readline = require('readline');
const { createMenuAction } = require('./RDRA_Knowledge/helper_tools/menuAction');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});
rl.setPrompt('> ');

/**
 * メニューを表示する
 */
function showMenu() {
    console.log('■ZeroOne');
    console.log('1.全削除してZeroOne～1_RDRAを生成する');
    console.log('2.フェーズ単位実行：未完了のPhaseを1回だけ実行する');
    console.log('3.未完了のPhaseから1_RDRAを生成する');
    console.log('■RDRA');
    console.log('11.RDRAGraphを表示：関連データを作成しRDRAGraphを表示');
    console.log('12.Spreadsheetに展開：RDRA定義をクリップボードにコピー');
    console.log('■RDRASpec：非アーキテクチャ仕様');
    console.log('21.仕様の作成：論理データ構造/画面照会/ビジネスルール');
    console.log('22.未作成の仕様の継続作成：論理データ構造/画面照会/ビジネスルール');
    console.log('23.BUC・アクター別画面を表示する');
    console.log('■RDRASdd：仕様駆動開発仕様');
    console.log('31.実装用の仕様書を作成する：Domain/Application/UI');
    console.log('32.未作成の実装用仕様書を継続作成する');
    console.log('33.機能仕様のCallgraphを表示する');
    console.log('■全般');
    console.log('0.メニュー終了');
    console.log('');
    console.log('99.生成した成果物の削除：0_RDRAZeroOne/1_RDRA/2_RDRASpec/3_RDRASdd');
    console.log('');
    console.log('実行したい番号を入力してください');
}

let executeOption;
// 入力の受け口を切り替える（Enter待ち / メニュー入力）
let inputHandler = null;

function handleMenuInput(line) {
    executeOption(line.trim());
}

function waitForEnterThenNext() {
    console.log('続行するにはEnterキーを押してください...');
    inputHandler = () => {
        promptUser();
    };
    rl.prompt();
}

function promptUser() {
    showMenu();
    inputHandler = handleMenuInput;
    rl.prompt();
}

rl.on('line', (line) => {
    if (inputHandler) inputHandler(line);
});

executeOption = createMenuAction({ rl, promptUser, waitForEnterThenNext });

console.log('コマンド実行メニュー');
promptUser();
