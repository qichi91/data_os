# RDRAAgent - 使い方ガイド

## 概要

RDRAAgentは、RDRA（Relationship Driven Requirement Analysis）手法を用いてLLMのCliを使って要件定義を段階的に行うシステムです。初期要望から4つのフェーズを通じて体系的に要件を定義し、仕様のたたき台まで生成します。
メニュー(node menu)を使ってRDRA定義、仕様化、ツール利用を行います。

## インストール方法

### RDRAサイト（）から直接ダウンロード
Zipでダウンロードし解凍して利用する

### 部分的にJavaScriptを使っているので、Node.jsのインストールが必要です

## **この方法の特徴：**
- 外部のライブラリなどへの依存を減らし、Nodeにのみ依存する
  - 外部依存関係がないため`npm install` は不要
- Nodeが既に存在するダウンロードかクローンするだけですぐに使用可能


**含まれるフォルダー構造：**
```
RDRAAgent_v0.8/
├── .claude/              # Claude Code設定
├── .cursor/              # Cursor設定
├── 0_RDRAZeroOne         # 4phaseのAI生成の中間成果物
├── 1_RDRA                # RDRAZeroOneで生成されたRDRA定義
├── 2_RDRASpec            # ビジネスルール、画面照会、論理データモデル
├── 3_RDRASdd             # 仕様駆動開発のための機能仕様
├── RDRA_Knowledge/       # ナレッジベース
├── Samples/              # サンプルプロジェクト
└── 初期要望.txt
```
## **RDRAAgent0.7からの変更点**
- 検証系の処理を無くしシンプルにする
- 「/」スラッシュコマンドを無くし、実行は「node menu」のみに簡略化
- 並列処理による実行時間の短縮化
  - nodeのchild processを使って並列処理を実行
- RDRASpecの画面編集を無くした（この段階での変更は混乱を招く）
  - 画面照会をBUC別とアクター別の照会に変更

### **モデルの切替**
- 各モデルのCLIが事前に動作する状態にしておく
- モデル設定.jsonを見直す
- 2つのモデルを予め設定済み（claude,cursor）
- モデル設定.jsonのproviderに設定
  - "provider": "claude"　⇐　"claude","cursor"

### モデル別の特徴
- claude：Claude Cliを利用　`.claude/CLAUDE.md` から `AGENTS.md` を参照
- cursor：Agent Cliを利用　モデル設定.jsonの設定内で利用するモデルを設定する
  - Cursorで使えるモデルを設定可能
- どのモデルを使う場合でも事前にCliが動く状態にしておく

## 実行時の問題
- 様々な理由で実行が止まるときがある
  - エラーが発生した場合（サーバー負荷、Rate limitなど）
  - エラーが無くても止まる場合がある
- 再実行することでうまくいくことが多い

## 「初期要望.txt」を入力する
### 初期要望.txt：RDRA定義のための初期の要望のリスト
- システム名
- 要求や課題
- 業務概要や業務の背景
- 関係するアクターや外部システム
- ビジネスポリシーなど分かる範囲で記述

### Samplesの活用
- 入力内容はSamples内のファイルを参照する
- 最初は思いつくものを記入し、実行しながら何度も壁打ちする

## プロジェクトの構築ポリシー
- 様々な環境、モデルに対応できるように他のライブラリーへの依存を無くす
- 外部ライブラリの依存を無くすために、テキストベースのファイル(md,js,text)で構成する
- モデル実行設定は `モデル設定.json` で管理します（default は `claude`）。

### 対応環境
- **OS**: Windows 11 / Mac（未確認）
- **Node.js**: バージョン18以上推奨
- **Model**: `モデル設定.json` の `default.provider` で設定

## メニュー起動 Terminal
```bash/command
node menu
```

### 主な特徴
- **段階的な要件定義**: LLMを活用し4つのフェーズで段階的にRDRA定義を作成
- **可視化機能**: RDRAGraphによる要件の関連性の可視化
- **RDRASheet連携**: 生成内容をRDRASheetに取り込む
- **画面プロトタイプ**: ブラウザで画面定義を確認
- **AIによる問合せ**: RDRA,RDRASddに対してAIのチャットで定義内容を問合せが可能
- **仕様駆動のための仕様作成**: 3レイヤー(ui,application,domain)
- **仕様のCallgraph表示**: UI-UC-Service-Entityの関係をGraph化

## メニュー構成

### ■ZeroOne

**1〜3 RDRA定義実行**
- １：全削除してPhase1〜Phase5を生成する
  - `0_RDRAZeroOne/phase1〜4`、`1_RDRA`、`2_RDRASpec`、`3_RDRASdd` 配下を削除してから、DAG実行（`runMenu8` 相当）で再生成
  - AI生成はPhase1〜4、続けて再構築スクリプト（phase5相当）で `1_RDRA/if/関連データ.txt` を生成
- ２：フェーズ単位の実行 
  - 未完了の最小フェーズを1回だけ実行（`runMenu7` 相当）
- ３：一括要件定義
  - 依存DAGに従って未生成ノードを波状並列実行（`runMenu8` 相当）

### ■RDRA（RDRA定義の可視化・管理）

**11. RDRAGraphを表示**
- 関連データを生成し、RDRAGraphで可視化
- 処理内容：
  1. `makeGraphData.js` で関連データ生成
  2. OS別コマンドで `1_RDRA/if/関連データ.txt` をクリップボードにコピー
  3. ブラウザで https://vsa.co.jp/rdratool/graph/v0.96/index.html?clipboard を開く
  4. 自動的にToolが開きクリップボードのデータを読込み、グラフ表示

**12. Spreadsheetに展開**
- RDRA定義をクリップボードにコピー
- 処理内容：
  1. `makeZeroOneData.js` で関連データ生成
  2. `copyToClipboard.js` データをクリップボードにコピー
  3. ブラウザでGoogle Spreadsheetを開く
  4. SpreadsheetのZeroOneシートに貼り付けて活用

### ■非システムアーキテクチャ依存の仕様（RDRASpec）
- **21. 仕様の作成**
  - 論理データ構造、画面定義、ビジネスルールを一括生成（phase1 → phase2）
  - 前提: `1_RDRA/` および `1_RDRA/if/関連データ.txt` が存在すること
  - 出力ファイル：
    - `2_RDRASpec/論理データモデル.md` - 論理データモデル（Markdown形式）
    - `2_RDRASpec/ビジネスルール.md` - ビジネスルール
    - `2_RDRASpec/phase1/` - 中間JSON（画面一覧、BUC画面、アクター画面）
    - `2_RDRASpec/画面照会.json` - 統合画面定義

- **22. 未作成の仕様の継続作成**
  - メニュー21と同じ成果物を、未生成のプロンプトだけ段階的に実行
  - Step1: 論理データモデル / ビジネスルール → Step2: 画面一覧 → Step3: BUC画面 / アクター画面 → Step4: 画面照会

- **23. BUC・アクター別画面を表示する**
  - 仕様の画面定義をブラウザで表示
  - 前提: `2_RDRASpec/論理データモデル.md`、`ビジネスルール.md`、`画面照会.json`（または `ui.json`）
  - `RDRA_Knowledge/helper_tools/web_tool/bucActorUI.js` でHTTPサーバーを起動（ポート **3002**）
  - ブラウザで http://localhost:3002/ を開く

### ■仕様駆動開発の機能仕様（RDRASdd・暫定版）
実装AI向けの機能仕様（JSON）を生成する。仕様化の課題を洗い出すための暫定版。出力されない場合は **32** で継続作成する。
- **31. 実装用の仕様書を作成する（Domain / Application / UI）**
  - 前提: `1_RDRA/if/関連データ.txt` および `2_RDRASpec/` の主要成果物
  - 実行内容（内部で3ステップ）:
    1. **Domain** … `3_RDRASdd/domain/`（コンテキスト単位の `.json`）
    2. **Base** … `3_RDRASdd/.work/uiApp.json`（BUC・画面・UCの対応表）
    3. **Application / UI** … `3_RDRASdd/application/`（BUC単位の `.json`）、`3_RDRASdd/ui/`（BUC別フォルダ内の画面 `.json`）
  - 一時フォルダ `3_RDRASdd/.work/` にUI生成用プロンプトを展開（完了後に削除）

- **32. 未作成の実装用仕様書を継続作成する**
  - メニュー31と同じ成果物を、未生成のステップ・BUCだけ実行

- **33. 機能仕様のCallgraphを表示する**
  - 前提: `3_RDRASdd/domain`、`application`、`ui` にJSONが存在すること
  - `RDRA_Knowledge/helper_tools/callgraph/callgraphServer.js` を起動（ポート **3000**）
  - ブラウザで http://127.0.0.1:3000/callgraphView.html を開く
  - 画面(UI) - UC(application) - service(domain) - entity(domain) の関係を対話的に表示
  - ※各仕様が不完全な場合、つながらない要素がある

### ■全般

**0. メニュー終了**
- プログラムを終了
- 起動中のサーバー（画面照会・Callgraph）も自動停止

**99. 生成した成果物の削除**
- 以下のフォルダーの成果物を削除：
  - `0_RDRAZeroOne/`
  - `1_RDRA/`
  - `2_RDRASpec/`
  - `3_RDRASdd/`

## ワークフロー

### 基本的な作業の流れ

1. **初期準備**
   - `初期要望.txt` にシステム要求を記述
   - `Samples/` フォルダーのサンプルを参考にする

2. **要件定義（ZeroOne）**
   - 一気にRDRA定義を進める場合に「1」を使用
   - フェーズ単位に定義内容を確認する場合に「2」を実行
   - 途中のフェーズから一括実行する場合は「3」を実行
   - フェーズ1だけ実行し内容を確認、以降は一気に実行する場合に「2」「3」を実行

3. **RDRA可視化**
   - メニュー「11」でRDRAGraphを表示
   - 要件の関連性を図で確認

4. **仕様作成**
   - メニュー「21」で仕様を生成
   - データモデル、画面、ビジネスルールを作成

5. **画面の確認**
   - メニュー「23」でBUC/アクター別画面を確認

6. **実装用仕様（任意）**
   - メニュー「31」で Domain / Application / UI のJSON仕様を一括生成
   - 途中で止まった場合は「32」で継続
   - メニュー「33」でCallgraphを表示して関係を確認
## バージョン情報

**現在のバージョン**: RDRAAgent v0.8

### 変更履歴
- v0.8: 現行バージョン
  - skillを実装し定義されたRDRA（要件定義）についての問合せに答える
  - 機能仕様の生成（3_RDRASdd）
    - domain,application,ui

## 使用例

### 例1: 図書館システムの要件定義

```bash
# 1. サンプルの初期要望をコピー
copy Samples\図書館システム\初期要望.txt

# 2. メニューシステムを起動
node menu

# 3. メニューで「1」（全削除後一括）or「3」を選択（一括要件定義・DAG）
     → 4つのPhaseが順次実行される
# 4. メニューで「11」を選択（RDRAGraph表示）
     → ブラウザでRDRAGraphが表示される
     → 「クリップボードから読み込み」をクリック（クリップボードのデータを取込）
# 5. メニューで「12」を選択（Spreadsheet表示）
     → RDRASheet(Google spreadsheet)が表示される
     → 「File/コピー保存」で編集可能なファイルにする
     → ZeroOneシートにペースト、「Import」クリックで各シートに展開
# 6. メニューで「21」を選択（仕様作成）
     → 論理データモデル、画面定義、ビジネスルールが生成される
# 7. メニューで「23」を選択（BUC/アクター画面確認）
     → ブラウザで画面照会が表示される（http://localhost:3002/）
# 8. メニューで「31」を選択（実装用仕様の一括作成）
     → Domain / Application / UI の JSON 仕様が生成される
# 9. （任意）メニューで「32」を選択
     → 31 で未完了の仕様だけ継続作成
# 10. メニューで「33」を選択（Callgraph表示）
     → http://127.0.0.1:3000/callgraphView.html で仕様の関係を確認
# 11. 実装を行う
     → 新しいProjectを作成し仕様をコピーする
```

### 例2: 段階的な要件定義

```bash
# 1. 初期要望を記述
初期要望.txt

# 2. メニューシステムを起動
node menu

# 3. フェーズ毎の実行：
　　　 → メニューで「2」を選択（フェーズ単位の要件定義）
　　　 → Phase1が実行される
# 4. Phase1の結果を確認
　　　 → 0_RDRAZeroOne/phase1/ フォルダー内のTSVファイルを確認
# 5. 再度メニューで「2」を選択
　　　 → Phase2が実行される
# （Phase3、Phase4も同様に実行）
# 6.（任意）必要に応じてメニュー「11」で関連データを再作成
```

## ファイル構成

### 入力ファイル
- `初期要望.txt` - システムの初期要求

### サンプルフォルダー
- `Samples/` - 参考となるサンプルプロジェクト
  - `介護事業者向けシステム/` - 介護事業者向けシステムのサンプル
  - `図書館システム/` - 図書館システムのサンプル
  - `貸し会議室SaaS/` - 貸し会議室SaaSのサンプル
  - 各サンプルには `初期要望.txt` が含まれています

### 出力フォルダー
- `0_RDRAZeroOne/phase1~4/` - フェーズ別のTSVファイル
- `1_RDRA/` - RDRA定義ファイル（統合版、TSV/JSON形式）
- `2_RDRASpec/` - 仕様ファイル（JSON/Markdown形式）
- `2_RDRASpec/phase1/` - 仕様生成の中間JSON（`画面一覧.json`、`BUC画面.json`、`アクター画面.json`）
- `3_RDRASdd/` - 機能仕様ファイル（**JSON形式**）
  - `domain/` - ドメイン仕様（コンテキスト単位）
  - `application/` - アプリケーション仕様（BUC単位）
  - `ui/` - UI仕様（BUC別フォルダ内の画面単位）
  - `.work/uiApp.json` - BUC・画面・UCの対応（メニュー31 Step2）
- `3_RDRASdd/.work/` - UI生成時の一時プロンプト（メニュー31実行中のみ）

### ヘルパーツール
- `RDRA_Knowledge/helper_tools/` - 各種支援スクリプト
  - `makeGraphData.js` - グラフデータ生成
  - `makeZeroOneData.js` - RDRASheet貼り付け用データ生成
  - `copyToClipboard.js` - データをクリップボードにコピー
  - `deleteFiles.js` - 成果物削除
  - `web_tool/bucActorUI.js` - 画面照会（BUC/アクター）表示サーバー（ポート3002）
  - `callgraph/callgraphServer.js` - 機能仕様Callgraph表示サーバー（ポート3000、メニュー33）
  - `callgraph/callgraphView.html` - CallgraphのブラウザUI
  - `parallelRun/parallel-runner.js` - プロンプト並列（または条件により直列）実行
  - `parallelRun/dag-runner.js` - ZeroOneの依存DAG実行
  - `attachContext.js` - phase4成果物にコンテキストを付与して1_RDRA用TSVを整備
  - `sddPostCheck.js` - 機能仕様の作成後チェック（件数・整合性）を行う
- 上記のツールはmenu.jsから使われる

### ナレッジベース
- `RDRA_Knowledge/_0_RDRAZeroOne/` - ZeroOneフェーズの説明
  - Phase:1-4 - フェーズ毎の成果物生成Prompt

- `RDRA_Knowledge/.rdracore/` - RDRA定義の説明
  - `RDRA.md` - RDRAの基本概念
  - `RDRAGraph.md` - RDRAGraphの説明（関連データ.txtの構造説明）
  - `RDRASheet.md` - RDRASheetの説明
- `RDRA_Knowledge/_2_RDRASpec/` - 仕様作成の説明
  - `phase1/21_論理データ生成.md` - 論理データモデル作成方法
  - `phase1/22_ビジネスルール生成.md` - ビジネスルール作成方法
  - `phase1/23_画面一覧生成.md` - 画面一覧作成方法
  - `phase1/24_BUC画面生成.md` - BUC画面作成方法
  - `phase1/25_アクター画面生成.md` - アクター画面作成方法
  - `phase2/26_画面照会生成.md` - 画面照会作成方法
- `RDRA_Knowledge/_3_RDRASdd/` - 機能仕様作成の説明
  - `31_Create_Domain.md` - domainレイヤーの機能仕様書を作成する方法
  - `32_Create_Base.md` - uiとapplicationのベースを作成する方法
  - `33_Create_Application.md` - applicationレイヤーの機能仕様書を作成する方法
  - `34_Create_UI.md` - UIレイヤーの機能仕様書を作成する方法

### 設定ファイル
- `.claude/settings.local.json` - Claude Codeのアクセス権限設定
- `.cursor/.cursorignore` - Cursorの除外設定

## ファイルフォーマット

### TSVファイル規則
- UTF-8エンコーディング

### 主要なTSVファイル

#### Phase1で生成されるファイル
- `システム概要.json` - システム概要
- `ph1要求.tsv` - 要求の一覧
- `ph1ビジネスポリシー.tsv` - ビジネスポリシー
- `ph1ビジネスパラメータ.tsv` - ビジネスパラメータ
- `ph1業務.tsv` - 業務フロー

#### Phase2で生成されるファイル
- `ph2状態.tsv` - 状態遷移モデル
- `ph2アクティビティ.tsv` - アクティビティ定義
- `ph2条件.tsv` - 条件定義

#### Phase3で生成されるファイル
- `ph3BUC.tsv` - BUC候補
- `ph3バリエーション.tsv` - バリエーション定義

#### Phase4で生成されるファイル
- `ph4UCタイマー.tsv` - UCとタイマーの関連
- `ph4UCアクター.tsv` - UCとアクターの関連
- `ph4UC外部システム.tsv` - UCと外部システムの関連
- `ph4アクター.tsv` - アクター定義
- `ph4外部システム.tsv` - 外部システム定義
- `ph4条件.tsv` - 条件の最終形式
- `ph4情報.tsv` - 情報の関連付け
- `ph4状態.tsv` - 状態の最終形式

#### 1_RDRAフォルダーで生成されるファイル
Phase4完了後、`makeBUC` → `attachContext` → `rdraFileCopy` により ZeroOne 成果物から統合される。
- `システム概要.json` - システム全体の概要（Phase1 `システム概要.json` から）
- `アクター.tsv` - アクター（Phase4 `ph4アクター.tsv` から）
- `外部システム.tsv` - 外部システム（Phase4 `ph4外部システム.tsv` から）
- `情報.tsv` - 情報（Phase4 `ph4情報.tsv` から）
- `状態.tsv` - 状態（Phase4 `ph4状態.tsv` から）
- `条件.tsv` - 条件（Phase4 `ph4条件.tsv` から）
- `バリエーション.tsv` - バリエーション（Phase3 `ph3バリエーション.tsv` から）
- `BUC.tsv` - ビジネスユースケース（Phase3 `ph3BUC.tsv` 等を元に `makeBUC` で生成）
- `if/関連データ.txt` - RDRAGraph用の関連データ（makeGraphData.jsで生成）
- `if/ZeroOne.txt` - RDRASheet用のZeroOne（メニュー12で makeZeroOneData.js 実行時に生成）

## LLM連携（Windows / Mac）

メニューの一部機能（**1, 2, 3, 21, 22, 31, 32**）はLLM（大規模言語モデル）を使用します：
- 実行プロバイダーは `モデル設定.json` から読み込みます
- プロンプトは `RDRA_Knowledge/_0_RDRAZeroOne/phase*/`、`RDRA_Knowledge/_2_RDRASpec/phase*/`、`RDRA_Knowledge/_3_RDRASdd/*` 配下を使用します
- 実行は `RDRA_Knowledge/helper_tools/parallelRun/parallel-runner.js` 経由で行います
- メニュー **23**（画面照会）と **33**（Callgraph）はローカルHTTPサーバーのみ（LLM不使用）

## トラブルシューティング

### ファイルが生成されない
- **原因**: LLMの実行が完了していない、またはエラーが発生
- **対処**: 各フェーズの実行確認機能が自動でチェック
  - 不足ファイルは自動再生成される
  - ターミナルウィンドウのエラーメッセージを確認

### サーバーが起動しない
- **原因**: ポート競合（画面照会 **3002**、Callgraph **3000**）
- **対処**: 
  - メニュー「0」で一度終了し、再起動（`bucActorUIServer` と `callgraphServer` を停止）
  - タスクマネージャーでNode.jsプロセスを確認

### データが表示されない
- **原因**: 必要なファイルが未生成
- **対処**:
  - 画面照会（23）: メニュー「21」または「22」で `2_RDRASpec/画面照会.json` を生成
  - Callgraph（33）: メニュー「31」または「32」で `3_RDRASdd/domain`・`application`・`ui` を生成
  - メニュー「99」で一度クリアして再実行

## 参考情報

### RDRA構造の基本概念
- **アクター** - システムを利用する人の役割
- **外部システム** - 連携する外部システム
- **業務** - 会社の機能単位
- **BUC** - ビジネスユースケース（業務の価値実現単位）
- **情報** - システムが扱うビジネス情報
- **状態** - 情報の変化を管理する状態モデル
- **UC** - ユースケース（システムとの接点）
- **条件** - ビジネスルールや制約
- **バリエーション** - 業務のバリエーションパラメータ

詳細は `RDRA_Knowledge/.rdracore/RDRA.md` を参照してください。

### Phase別の作業内容

#### Phase1: 要素の洗い出し
- システムの基本要素を特定
- システム概要、要求、ビジネスポリシー、ビジネスパラメータ、業務を定義

#### Phase2: 状態・アクティビティ・条件の定義
- 状態の定義
- アクティビティの定義
- 条件の定義

#### Phase3: BUCとバリエーションの定義
- BUC候補の抽出
- バリエーションの定義

#### Phase4: UC関連・情報・状態の最終定義
- UCタイマー、UCアクター、UC外部システムの定義
- アクター、外部システム、条件、情報、状態の最終形式化
- その後 `makeBUC`、`attachContext`、`rdraFileCopy`、`makeGraphData` により 1_RDRA と関連データを生成

### よくある質問

**Q: Phase1で生成されるファイルとPhase4で生成されるファイルで同じ名前のものがありますが、違いは何ですか？**
A: 各Phaseで同じ名前のファイルが生成されることがありますが、内容は段階的に詳細化・構造化されていきます。最終的にPhase4までの内容が1_RDRAフォルダーに統合されます。

**Q: RDRAGraphが表示されない場合は？**
A: 1_RDRA/if/関連データ.txtが生成されていることを確認し、ブラウザのポップアップブロックが有効になっていないか確認してください。

**Q: 途中でエラーが出た場合は？**
A: メニュー「99」で成果物を削除し、最初からやり直すことをお勧めします。または、エラーが出たPhaseのみを再実行することもできます。

**Q: サンプルプロジェクトを試すには？**
A: Samplesフォルダー内のサンプルの初期要望.txtを、プロジェクトルートの初期要望.txtにコピーして使用してください。

### 関連リンク
- **RDRAツール公式サイト**: https://vsa.co.jp/rdratool/
- **RDRAGraph**: https://vsa.co.jp/rdratool/graph/
- **RDRA手法について**: `RDRA_Knowledge/.rdracore/RDRA.md` を参照
---

## ライセンス
MIT License
