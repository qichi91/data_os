
# specs-repo: 概要設計・ICONIX分析 運用マニュアル (SOP)

本リポジトリは、旧仕様書から新アーキテクチャ（C++モジュラーモノリス）へ移行するための概要設計成果物、および要件トレーサビリティを管理します。

本番で旧Wordを準備してからローカルLLMでドラフトを作成し、検証・レビュー・PRへ進む手順は [本番運用手順](./05_operations/production_workflow.md) を参照してください。Issue起点のkick/監視は未実装ですが、生成後に呼び出す独立したブランチ作成・push・PR発行CLIを用意しています。

---

## 1. 運用原則 (Core Policies)

1. **Single Source of Truth (SSoT)**:
* 正本データはすべて `.schemas/` に準拠した **YAML** および **JSON Lines** です。
* MarkdownおよびPlantUMLは `scripts/render_docs.py` により機械生成される閲覧用成果物であり、直接編集は禁止です。


2. **完全トレーサビリティ保証**:
* 旧仕様書の全記述は `00_traceability/atoms/*.jsonl` にアトム単位で登録されます。
* すべてのアトムは、「ユースケースの根拠として採用される」か「`00_traceability/deprecated_features.yaml` に廃止理由を明記する」かのいずれかでなければならず、カバレッジ100%をCIで検証します。


3. **ICONIX粒度ポリシー**:
* **システムユースケース**: 1アクターが1回の対話セッションで達成する目的。基本コース2〜5ステップ、代替コース2〜5個程度を目安とする。
* **能動態記述**: 「アクターは〜を入力する」「システムは〜を検証する」という主客を明確にした記述を徹底する。
* **UI非依存**: ボタンの色や配置は記述せず、論理的なデータ送受信と業務ルールに集中する。



---

## 2. 作業状態と自動化範囲

Gitea Issue/PRによる状態遷移は将来の運用案であり、現在は実装していません。エージェントはローカルCLIで起動し、YAML・JSONLを本リポジトリに生成します。

| 状態 | 担当 | アクション |
| --- | --- | --- |
| 入力準備 | 人間 | TSVの機能ID、旧Word、既存アトム・判断台帳を用意。 |
| 抽出・起草 | エージェント | ローカルLLMで根拠付き事実を抽出し、ユースケースYAML候補を生成・検証。 |
| レビュー | 人間 | YAMLと生成Markdownを確認し、判断・用語・設計を承認または修正。 |
| 統合 | 人間/呼出し元 | `agent-system-repo publish` にIssue番号と公開ファイルを渡し、ブランチpush・Gitea PRを作成。Issue kick/監視は別途実装。 |

---

## 3. 人間とエージェントの作業手順

### ステップ1: 旧仕様書と新機能のインプット登録

1. `inputs/features.tsv` に大中小の機能一覧を配置する。
2. `inputs/raw_docs/` に解析対象の旧仕様書Wordファイルを配置する。
3. `agent-system-repo` の `.env` で閉域網内のローカルLLM APIとGitea PR APIを設定し、Git remoteにはpush用SSH認証を設定する。Issue起点のkick/監視は別途用意する。

### ステップ2: ローカルLLMによる抽出とドラフト生成

1. `agent-system-repo` から `ingest` を実行してWordをアトム化し、`00_traceability/atoms/*.jsonl` に保存。
2. `extract --feature-id <機能ID>` で根拠ID付き事実を抽出し、矛盾・曖昧さ・不足を分析して `02_extracted_context/*_context.yaml` に保存。人の `decision_items` は保持され、LLMは確定判断しない。
3. `generate --feature-id <機能ID> --module <モジュールディレクトリ>` で `03_usecases/<module>/UC_<機能ID>.yaml` を起草。
4. スキーマ・フロー構造・根拠状態を検証し、通過した場合にMarkdownを生成。

例（`agent-system-repo` ディレクトリで実行）:

```powershell
python main.py ingest --input-dir ..\specs-repo\inputs\raw_docs
python main.py extract --feature-id F_ORD_001
python main.py generate --feature-id F_ORD_001 --module MOD01_Order
```

### ステップ3: 人間によるレビューと修正

1. 生成Markdownと対応するYAML、根拠アトムを確認。LLMの出力はドラフトであり、意味的な正しさは人が判断する。
2. 修正が必要な場合は、対象の `UC_*.yaml` または `domain_vocabulary.yaml` を編集してコミット。
3. 不要となった旧仕様記述は `00_traceability/deprecated_features.yaml` に理由を記載して追加。
4. `python scripts/check_coverage.py` を実行し、カバレッジが100%であることを確認してマージ。

---

## 4. ディレクトリ構成

* `inputs/`: 新機能TSVおよび旧Word仕様書
* `.schemas/`: 各種YAML/JSONLが準拠すべきJSON Schema
* `templates/`: Jinja2変換テンプレート
* `00_traceability/`: 要件アトム、廃止台帳、カバレッジレポート
* `01_architecture/`: モジュール境界定義、ゲートウェイ共通電文、共通用語集
* `02_domains/`: Geode Regionおよびドメインモデル定義
* `03_usecases/`: ユースケース別YAML定義および自動生成Markdown
* `assets/inspections/`: 未抽出オートシェイプや要目視確認用データの退避先
* `scripts/`: 検証・生成・CI用スクリプト
