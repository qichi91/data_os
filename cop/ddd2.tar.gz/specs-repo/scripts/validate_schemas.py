#!/usr/bin/env python3
"""Validate canonical YAML, use cases, domains, and source atom records."""

import json
import sys
from pathlib import Path

import jsonschema
import yaml


ROOT = Path(__file__).resolve().parent.parent


def load_yaml(path: Path):
    with path.open(encoding="utf-8") as stream:
        return yaml.safe_load(stream)


def validate_yaml_files(paths, schema, errors):
    for path in sorted(paths):
        try:
            jsonschema.validate(instance=load_yaml(path), schema=schema)
            print(f"[PASS] {path.relative_to(ROOT)}")
        except (OSError, yaml.YAMLError, jsonschema.ValidationError) as exc:
            print(f"[FAIL] {path.relative_to(ROOT)}: {exc}")
            errors.append(path)


def validate():
    schemas_dir = ROOT / ".schemas"
    try:
        uc_schema = load_yaml(schemas_dir / "usecase.schema.yaml")
        domain_schema = load_yaml(schemas_dir / "domain.schema.yaml")
        vocabulary_schema = load_yaml(schemas_dir / "vocabulary.schema.yaml")
    except (OSError, yaml.YAMLError) as exc:
        print(f"[FAIL] Unable to load validation schemas: {exc}")
        return 1

    errors = []
    validate_yaml_files(
        (ROOT / "03_usecases").rglob("*.yaml"), uc_schema, errors,
    )
    validate_yaml_files(
        (ROOT / "02_domains").rglob("*.yaml"), domain_schema, errors,
    )

    vocabulary_path = ROOT / "01_architecture" / "domain_vocabulary.yaml"
    if vocabulary_path.exists():
        validate_yaml_files([vocabulary_path], vocabulary_schema, errors)

    deprecated_path = ROOT / "00_traceability" / "deprecated_features.yaml"
    if deprecated_path.exists():
        try:
            deprecated = load_yaml(deprecated_path)
            entries = deprecated.get("deprecated_features", []) if isinstance(deprecated, dict) else None
            if not isinstance(entries, list) or any(
                not isinstance(item, dict)
                or not isinstance(item.get("atom_id"), str)
                or not isinstance(item.get("reason"), str)
                or not item["reason"].strip()
                for item in entries
            ):
                raise ValueError("deprecated_features must be a list with atom_id and reason")
            print(f"[PASS] {deprecated_path.relative_to(ROOT)}")
        except (OSError, yaml.YAMLError, ValueError) as exc:
            print(f"[FAIL] {deprecated_path.relative_to(ROOT)}: {exc}")
            errors.append(deprecated_path)

    for path in sorted((ROOT / "02_extracted_context").glob("*_context.yaml")):
        try:
            context = load_yaml(path)
            if not isinstance(context, dict) or not isinstance(context.get("feature_id"), str):
                raise ValueError("context must be a mapping with feature_id")
            decisions = context.get("decision_items", [])
            if not isinstance(decisions, list):
                raise ValueError("decision_items must be a list")
            facts = context.get("extracted_facts", {})
            if not isinstance(facts, dict) or any(
                not isinstance(items, list) for items in facts.values()
            ):
                raise ValueError("extracted_facts must map categories to lists")
            analysis = context.get("analysis")
            if analysis is not None:
                if not isinstance(analysis, dict) or not isinstance(analysis.get("summary"), str):
                    raise ValueError("analysis must be a mapping with a summary")
                if any(not isinstance(analysis.get(key), list) for key in ("conflicts", "ambiguities", "gaps")):
                    raise ValueError("analysis conflicts, ambiguities, and gaps must be lists")
            print(f"[PASS] {path.relative_to(ROOT)}")
        except (OSError, yaml.YAMLError, ValueError) as exc:
            print(f"[FAIL] {path.relative_to(ROOT)}: {exc}")
            errors.append(path)

    seen_atom_ids = set()
    atoms_dir = ROOT / "00_traceability" / "atoms"
    for path in sorted(atoms_dir.glob("*.jsonl")):
        try:
            with path.open(encoding="utf-8") as stream:
                for line_number, line in enumerate(stream, 1):
                    if not line.strip():
                        continue
                    atom = json.loads(line)
                    if not isinstance(atom, dict) or not isinstance(atom.get("atom_id"), str):
                        raise ValueError(f"line {line_number}: atom_id must be a string")
                    if not isinstance(atom.get("text_content"), str):
                        raise ValueError(f"line {line_number}: text_content must be a string")
                    if atom["atom_id"] in seen_atom_ids:
                        raise ValueError(f"line {line_number}: duplicate atom ID {atom['atom_id']}")
                    if "active" in atom and not isinstance(atom["active"], bool):
                        raise ValueError(f"line {line_number}: active must be boolean")
                    seen_atom_ids.add(atom["atom_id"])
            print(f"[PASS] {path.relative_to(ROOT)}")
        except (OSError, json.JSONDecodeError, ValueError) as exc:
            print(f"[FAIL] {path.relative_to(ROOT)}: {exc}")
            errors.append(path)

    if errors:
        print(f"\nValidation failed with {len(errors)} error(s).")
        return 1
    print("\nAll canonical YAML and JSONL files passed validation.")
    return 0


if __name__ == "__main__":
    sys.exit(validate())
