#!/usr/bin/env python3
"""Render Markdown views from canonical YAML specifications."""

import sys
from pathlib import Path

import yaml
from jinja2 import Environment, FileSystemLoader


ROOT = Path(__file__).resolve().parent.parent


def render_all():
    templates_dir = ROOT / "templates"
    env = Environment(
        loader=FileSystemLoader(str(templates_dir)),
        trim_blocks=True,
        lstrip_blocks=True,
    )
    templates = {
        "usecase.md.j2": (ROOT / "03_usecases", "**/*.yaml"),
        "domain.md.j2": (ROOT / "02_domains", "**/*.yaml"),
    }
    rendered = 0
    for template_name, (source_dir, pattern) in templates.items():
        template = env.get_template(template_name)
        for yaml_path in sorted(source_dir.glob(pattern)):
            with yaml_path.open(encoding="utf-8") as stream:
                data = yaml.safe_load(stream)
            if not isinstance(data, dict):
                raise ValueError(f"{yaml_path}: expected a YAML mapping")
            if source_dir.name == "03_usecases":
                data = include_lifecycle_issues(data)
            output_path = yaml_path.with_suffix(".md")
            output_path.write_text(template.render(**data).rstrip() + "\n", encoding="utf-8")
            print(f"[RENDERED] {output_path.relative_to(ROOT)}")
            rendered += 1

    vocabulary_path = ROOT / "01_architecture" / "domain_vocabulary.yaml"
    if vocabulary_path.exists():
        with vocabulary_path.open(encoding="utf-8") as stream:
            data = yaml.safe_load(stream)
        output_path = vocabulary_path.with_suffix(".md")
        template = env.get_template("vocabulary.md.j2")
        output_path.write_text(template.render(**data).rstrip() + "\n", encoding="utf-8")
        print(f"[RENDERED] {output_path.relative_to(ROOT)}")
        rendered += 1
    print(f"Rendered {rendered} document(s).")


def include_lifecycle_issues(data: dict) -> dict:
    report_path = ROOT / "00_traceability" / "lifecycle_report.yaml"
    if not report_path.is_file():
        return data
    with report_path.open(encoding="utf-8") as stream:
        report = yaml.safe_load(stream) or {}
    if not isinstance(report, dict) or not isinstance(report.get("unconfirmed_items", []), list):
        raise ValueError(f"{report_path}: unconfirmed_items must be a list")
    current_issues = data.get("unconfirmed_issues", [])
    if not isinstance(current_issues, list) or any(not isinstance(issue, dict) for issue in current_issues):
        raise ValueError("unconfirmed_issues must be a list of mappings")
    issues = list(current_issues)
    issue_ids = {issue["issue_id"] for issue in issues if isinstance(issue, dict) and "issue_id" in issue}
    references = {
        step.get("source_atom_ref")
        for key in ("basic_flow", "alternative_flows")
        for step in data.get(key, [])
        if isinstance(step, dict)
    }
    for item in report.get("unconfirmed_items", []):
        if item.get("feature_id") != data.get("feature_id") and item.get("id") not in references:
            continue
        if item.get("id") in issue_ids:
            continue
        issues.append({
            "issue_id": item["id"],
            "title": item["status"],
            "description": item.get("description") or item.get("reason", ""),
            "impact": item.get("reason", ""),
        })
        issue_ids.add(item["id"])
    data["unconfirmed_issues"] = issues
    return data


if __name__ == "__main__":
    try:
        render_all()
    except (OSError, ValueError, yaml.YAMLError) as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        sys.exit(1)
