#!/usr/bin/env python3
"""Report coverage of active source atoms by use cases or approved deprecation."""

import json
import sys
from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parent.parent


def read_atoms(atoms_dir: Path) -> dict[str, dict]:
    atoms = {}
    for path in sorted(atoms_dir.glob("*.jsonl")):
        with path.open(encoding="utf-8") as stream:
            for line_number, line in enumerate(stream, 1):
                if not line.strip():
                    continue
                atom = json.loads(line)
                atom_id = atom.get("atom_id") if isinstance(atom, dict) else None
                if not isinstance(atom_id, str) or not atom_id:
                    raise ValueError(f"{path}:{line_number}: missing atom_id")
                if atom_id in atoms:
                    raise ValueError(f"{path}:{line_number}: duplicate atom ID {atom_id}")
                atoms[atom_id] = atom
    return atoms


def check_coverage() -> int:
    try:
        all_atoms = read_atoms(ROOT / "00_traceability" / "atoms")
        active_atoms = {
            atom_id: atom for atom_id, atom in all_atoms.items()
            if atom.get("active", True)
        }
        deprecated_path = ROOT / "00_traceability" / "deprecated_features.yaml"
        deprecated_data = (
            yaml.safe_load(deprecated_path.read_text(encoding="utf-8")) or {}
            if deprecated_path.exists() else {}
        )
        if not isinstance(deprecated_data, dict):
            raise ValueError(f"{deprecated_path}: expected a YAML mapping")
        deprecated_entries = deprecated_data.get("deprecated_features", [])
        if not isinstance(deprecated_entries, list):
            raise ValueError(f"{deprecated_path}: deprecated_features must be a list")
        if any(not isinstance(item, dict) or not isinstance(item.get("atom_id"), str)
               for item in deprecated_entries):
            raise ValueError(f"{deprecated_path}: every deprecated feature must contain atom_id")
        deprecated_ids = {
            item["atom_id"] for item in deprecated_entries
        }
        covered_ids = set()
        for path in sorted((ROOT / "03_usecases").rglob("*.yaml")):
            data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
            if not isinstance(data, dict):
                raise ValueError(f"{path}: expected a YAML mapping")
            refs = data.get("source_atoms", [])
            if not isinstance(refs, list):
                raise ValueError(f"{path}: source_atoms must be a list")
            covered_ids.update(ref for ref in refs if isinstance(ref, str))
            for key in ("basic_flow", "alternative_flows"):
                flows = data.get(key, [])
                if not isinstance(flows, list):
                    raise ValueError(f"{path}: {key} must be a list")
                covered_ids.update(
                    step["source_atom_ref"] for step in flows
                    if isinstance(step, dict) and isinstance(step.get("source_atom_ref"), str)
                )
    except (OSError, ValueError, KeyError, json.JSONDecodeError, yaml.YAMLError) as exc:
        print(f"[ERROR] Unable to calculate traceability coverage: {exc}", file=sys.stderr)
        return 1

    unknown = (covered_ids | deprecated_ids) - set(all_atoms)
    inactive_refs = covered_ids & (set(all_atoms) - set(active_atoms))
    if unknown:
        print(f"[ERROR] References to unknown atom IDs: {', '.join(sorted(unknown))}")
    if inactive_refs:
        print(f"[ERROR] References to inactive atom IDs: {', '.join(sorted(inactive_refs))}")
    overlap = covered_ids & deprecated_ids
    if overlap:
        print(f"[ERROR] Atoms are both mapped and deprecated: {', '.join(sorted(overlap))}")

    accounted = (covered_ids | deprecated_ids) & set(active_atoms)
    unaccounted = set(active_atoms) - accounted
    total = len(active_atoms)
    percent = lambda count: (count / total * 100) if total else 100.0
    lines = [
        "# 要件アトム トレーサビリティ・カバレッジレポート",
        "",
        "## カバレッジ統計",
        "",
        f"* **有効な要件アトム数**: {total} 件",
        f"* **ユースケースで参照**: {len(covered_ids & set(active_atoms))} 件 ({percent(len(covered_ids & set(active_atoms))):.1f}%)",
        f"* **廃止**: {len(deprecated_ids & set(active_atoms))} 件 ({percent(len(deprecated_ids & set(active_atoms))):.1f}%)",
        f"* **未処理**: {len(unaccounted)} 件 ({percent(len(unaccounted)):.1f}%)",
        "",
    ]
    if unaccounted:
        lines.extend([
            "## 未処理アトム一覧",
            "",
            "| アトムID | 出典仕様書 | セクション | 内容 |",
            "| --- | --- | --- | --- |",
        ])
        for atom_id in sorted(unaccounted):
            atom = active_atoms[atom_id]
            section = " > ".join(atom.get("section_path", atom.get("heading_hierarchy", [])))
            text = atom.get("text_content", "").replace("|", "\\|").replace("\n", " ")
            lines.append(f"| `{atom_id}` | {atom.get('source_doc', '')} | {section} | {text} |")
        lines.append("")

    uninspected = [
        (atom_id, atom) for atom_id, atom in active_atoms.items()
        if atom.get("kind") == "unextracted" or atom.get("has_unextracted_shapes", False)
    ]
    if uninspected:
        lines.extend([
            "## 未抽出図形・要確認アトム",
            "",
            "| アトムID | 出典仕様書 | 内容 |",
            "| --- | --- | --- |",
        ])
        for atom_id, atom in uninspected:
            text = atom.get("text_content", "").replace("|", "\\|").replace("\n", " ")
            lines.append(
                f"| `{atom_id}` | {atom.get('source_doc', '')} | {text} |"
            )
        lines.append("")

    report_path = ROOT / "00_traceability" / "coverage_report.md"
    report_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"[COVERAGE REPORT] Generated at {report_path.relative_to(ROOT)}")
    print(f"  Active: {total}, accounted: {len(accounted)}, unaccounted: {len(unaccounted)}")
    if unaccounted or unknown or inactive_refs or overlap:
        print("[ERROR] Traceability coverage failed.")
        return 1
    print("[SUCCESS] All active atoms are mapped or deprecated.")
    return 0


if __name__ == "__main__":
    sys.exit(check_coverage())
