#!/usr/bin/env bash
set -euo pipefail

# GiteaのIssueを監視し、status:ready-for-agent ラベルが付与されたものを処理するスクリプト

# 必要ツール: tea (Gitea CLI)

if ! command -v tea >/dev/null 2>&1; then
echo "ERROR: Gitea official CLI 'tea' is required."
exit 1
fi

ISSUE_INDEX="${1:-}"

if [ -z "${ISSUE_INDEX}" ]; then
echo "Usage: $0 "
echo "Example: $0 42"
exit 1
fi

echo "=== Processing Gitea Issue #${ISSUE_INDEX} ==="

# 1. 状態を processing に更新

tea issue edit "${ISSUE_INDEX}" --remove-labels "status:ready-for-agent" --add-labels "status:processing"

BRANCH_NAME="agent/issue-${ISSUE_INDEX}"
git checkout -b "${BRANCH_NAME}"

# 2. ドキュメントレンダリングとスキーマ検証の実行

python3 scripts/validate_schemas.py
python3 scripts/render_docs.py
python3 scripts/check_coverage.py

# 3. 差分をコミット＆プッシュ

git add .
if git diff --staged --quiet; then
echo "No changes to commit."
else
git commit -m "feat(spec): automated draft from issue #${ISSUE_INDEX} [skip ci]"
git push -u origin "${BRANCH_NAME}"

```
# 4. Pull Requestの起票
PR_URL=$(tea pr create \
    --title "Auto Draft: Issue #${ISSUE_INDEX} に基づくユースケース・ICONIX分析ドラフト" \
    --description "Issue #${ISSUE_INDEX} に基づき自動生成されました。YAMLをレビューしてください。\n\nRefs #${ISSUE_INDEX}" \
    --source-branch "${BRANCH_NAME}" \
    --target-branch "main")

tea issue comment "${ISSUE_INDEX}" "エージェントの処理が完了し、ドラフトPRを起票しました: ${PR_URL}"

```

fi

# 5. ステータスを review-required へ遷移

tea issue edit "${ISSUE_INDEX}" --remove-labels "status:processing" --add-labels "status:review-required"

echo "=== Issue #${ISSUE_INDEX} processing completed successfully. ==="
