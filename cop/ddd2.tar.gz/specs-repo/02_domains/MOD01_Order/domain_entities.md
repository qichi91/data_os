<!-- AUTO-GENERATED FROM domain_entities.yaml. DO NOT EDIT DIRECTLY. -->
# ドメインモデル: OrderManagement

## /Orders (PARTITION)

**Key:** `order_id` / `std::string` / `ORD-{YYYYMMDD}-{SEQ8}`

### OrderEntity

| Field | Type | Nullable | Description |
|---|---|---:|---|
| `order_id` | `std::string` | False | 受注一意識別子（主キー） |
| `customer_id` | `std::string` | False | 発注元顧客ID |
| `total_amount` | `int64_t` | False | 注文合計金額（税込） |
| `order_status` | `std::string` | False | ステータス（Confirmed、PendingApproval、DeliveryFailed、Cancelled） |
| `created_at` | `int64_t` | False | 作成日時（UNIXエポックミリ秒） |
