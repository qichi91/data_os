# 本番運用手順: 旧仕様書からユースケースPRまで

## 1. 現在の準備状況

**結論: 仕様ドラフトを作るためのコード基盤はありますが、本番運用に必要なものはまだすべて揃っていません。**

| 項目 | 状況 | 本番開始前に必要なこと |
|---|---|---|
| 旧Word取込 | `agent-system-repo` のCLIで実行可能 | 本番のWord一式を用意し、見出し・表・図形の抽出結果を確認する |
| LLMによる抽出・分析・起草 | OpenAI互換APIを呼ぶ処理と検証を実装済み | 本番の閉域網LLMサーバー、モデル、GPU設定で接続と品質を確認する |
| `specs-repo` の成果物検証 | スキーマ、カバレッジ、Markdown生成のスクリプトあり | 本番環境で依存パッケージとコマンドを実行できるようにする |
| Gitea Issueからの自動処理 | 未実装 | Issue検出、入力値の取得、排他、状態ラベル、失敗時の復旧を別途実装する |
| ブランチ・コミット・push・PR | publish CLIあり | `.env` のGitea API設定、Git remote、push用SSH鍵、最小権限を本番設定し、実Giteaで受入試験する |
| Issueへの結果コメント/ラベル遷移 | 未実装 | Issue kick側でPR URLを受けてコメント・状態遷移する処理を別途実装する |
| Gitea Actionsによる検証 | workflow定義あり | 閉域網内のrunner、依存パッケージ、Actionsのローカル利用可否を確認する |

したがって、**人または別のkick処理がCLIでドラフトを作り、publish CLIを呼び出してブランチpush・PR作成する仕組みはあります**。ただし実サーバーでの認証・ネットワーク確認は必要です。Issueの監視・kick、Issueコメント、ラベル遷移は含まれません。`scripts/tea_issue_worker.sh` は完成したIssue Workerではなく、現行の抽出・起草・publish CLIを一連で呼ぶ処理も含まれていません。

## 2. 全体の目標フロー

```text
人が旧Word・機能一覧を準備
  -> Gitea Issueを作成し、機能ID・モジュールを指定
  -> status:ready-for-agent を付与
  -> [別途検討するIssue kick] Issue情報を取得しpublish対象を決定
  -> Wordをアトム化し、根拠IDを維持
  -> ローカルLLMで事実抽出・矛盾/曖昧さ/不足の分析
  -> ローカルLLMでUC YAMLを起草
  -> スキーマ・根拠・カバレッジを検証しMarkdownを生成
  -> publish CLIがspecs-repoのブランチへコミット・push
  -> publish CLIがPRを作成
  -> Gitea Actionsで再検証
  -> [別途実装するIssue kick] IssueにPRを通知
  -> 人が根拠と業務妥当性をレビュー、修正、承認
  -> PRをマージ
```

角括弧内のIssue kick/通知は**目標フローであり、未実装**です。Word取込から検証・Markdown生成までのCLI、およびブランチpush・PR作成用の `publish` CLIは利用可能ですが、本番Giteaでの接続確認は必要です。

## 3. 本番環境に必要なもの

### 3.1 リポジトリと入力

- `agent-system-repo` と `specs-repo` を、本番の作業環境に配置する。
- `specs-repo/inputs/features.tsv` に機能一覧を用意する。ヘッダーは `大区分`, `中区分`, `小区分`, `機能ID`, `機能名`, `概要` とし、各Issueの機能IDはこの表の `機能ID` と一致させる。
- 旧Word仕様書を `specs-repo/inputs/raw_docs/` に配置する。
- 初回以外の取込では既存の `00_traceability/atoms/*.jsonl` を維持する。入力ディレクトリに置いたWord全体が取込対象スナップショットになるため、対象外にする既存文書を誤って取り除かない。
- Issueごとに対象の機能ID、モジュールディレクトリ（例: `MOD01_Order`）、対象文書、期待する成果を記録する。現状のCLIはIssue内容を読まず、モジュールは手動で引数指定する。

### 3.2 ローカルLLMとエージェント実行環境

- エージェントから到達できるOpenAI互換 `/v1/chat/completions` APIと、使用モデル・十分なコンテキスト長・GPU/メモリを用意する。
- `.env.example` を `.env` にコピーし、`LLM_API_BASE_URL`、`LLM_MODEL_NAME`、必要な場合だけ `LLM_API_KEY` を設定する。秘密値はGitに登録しない。
- LLMサーバーに対して `/v1/models` の疎通を確認し、`LLM_API_BASE_URL` と `LLM_MODEL_NAME` の組合せでチャット補完とJSON応答が返ることを確認する。ヘルスチェック成功だけでは、抽出・分析・起草の品質確認にはならない。
- 閉域網へモデル、推論サーバーイメージ、Python依存関係を移送する。閉域網でイメージをビルドする場合はベースイメージとpip依存パッケージもオフラインで利用できるようにする。
- コンテナ実行では、エージェントが `specs-repo` とキャッシュ領域に書き込めるようにする。Composeの既定LLM URLはコンテナ向けの `host.docker.internal` であり、実際のネットワーク構成に合わせて変更する。
- PRをpublish CLIで作る場合、`.env` に `GITEA_API_URL`、`GITEA_API_TOKEN`、`GITEA_REPO_OWNER`、`GITEA_REPO_NAME` を設定する。Git remote名とbase branchは `GIT_REMOTE_NAME` / `GIT_BASE_BRANCH` で設定する。
- Git push用SSH鍵とknown_hostsを、CLI実行環境に安全に設定する。コンテナから実行する場合はイメージ/実行環境にGitとOpenSSH clientがあり、秘密鍵をイメージやリポジトリへ含めずに安全に渡せるようにする。

### 3.3 Issue kickを自動化するために別途必要なもの

- Gitea上のIssue/PR機能、対象リポジトリ、`status:ready-for-agent`、`status:processing`、`status:review-required`、`status:agent-error` 等のラベル。
- Issueを安全に一度だけ取得し、処理中状態を管理するWorker。失敗時に処理状態を戻す/エラーラベルへ遷移する仕組み。
- Gitea API用の最小権限PATをSecretとして保存し、PR作成可能な権限だけを付与する。Git pushは事前設定したSSH認証を使う。
- Gitea上のGit remoteと、Workerからpublish CLIを実行するための認証設定。
- Gitea Actions runnerとworkflowの実行確認。workflowが参照するActions、Python依存パッケージは閉域網から使えるミラーまたはローカル配置が必要。
- KickがIssueの機能ID・モジュール・入力文書を検証し、`ingest`、`extract`、`generate`、仕様検証の後に `publish` を呼び出す実装。
- Issue状態遷移、再実行/同時実行の排他、失敗ログ、Issue通知の設計。ブランチ名、選択的コミット、PR重複防止はpublish CLI側で扱う。

これらが整うまでは、Issueからpublish CLIを起動する自動処理を稼働させないでください。publish CLI単独の実サーバー試験は、テスト用Issue/リポジトリと専用アカウントで先に実施してください。

## 4. 現在のCLIでドラフトを作る手順

以下はIssue kickがなくても実行できる処理です。`agent-system-repo` のディレクトリをカレントディレクトリにします。PowerShellでの例です。

### 4.1 初回準備

```powershell
Copy-Item .env.example .env
# .env を編集し、閉域網LLMの URL / モデル名を設定する
python -m pip install -r requirements.txt
```

Docker Composeを使う場合は、事前に検証済みのエージェントイメージをビルド/ロードし、`.env` と `docker-compose.yml` のマウント先・LLM URLを確認します。

### 4.2 入力と原文を取込む

初回、または旧Wordの版を更新した場合に実行します。

```powershell
python main.py ingest --input-dir ..\specs-repo\inputs\raw_docs
```

`specs-repo/00_traceability/atoms/` にJSONLが作成されたことを確認します。Heading 1～9、段落、表は取込対象ですが、独自見出し、入れ子表、ヘッダー/フッターなどは完全対応を保証しません。図形等は未抽出記録になる場合があるため、件数だけでなく原文と照合してください。解析に失敗した場合、入力や既存JSONLを修正せずに繰り返し実行しないでください。

### 4.3 機能単位で抽出・分析する

```powershell
python main.py extract --feature-id F_ORD_001
```

`specs-repo/02_extracted_context/F_ORD_001_context.yaml` を確認します。抽出事実と各 `source_atoms` のIDが、該当する原文アトムを指していることを確認してください。`analysis` の矛盾、曖昧さ、不足は自動確定事項ではなく、担当者の確認項目です。既存の `decision_items` は人の台帳として保持し、LLMに新しい確定判断を作らせないでください。

### 4.4 UCを起草・検証する

```powershell
python main.py generate --feature-id F_ORD_001 --module MOD01_Order
```

標準出力のパスに `UC_F_ORD_001.yaml` が作成され、スキーマ、フロー、根拠検証を通過すると隣にMarkdownが生成されます。既存YAMLがあるときは上書きを拒否します。上書きが必要な場合は差分を確認・保存したうえで `--force` を使います。

生成後、少なくとも以下を人がレビューします。

- 各基本/代替フローの根拠IDと、元のWordの記述が一致する。
- 条件、否定、数値、例外、処理順序が変わっていない。
- LLMが推測を仕様の確定事項として記述していない。
- 抽出分析にある未解決事項と、Markdownの未確認事項が反映されている。
- 判断が `PENDING` / `NEEDS_RECONFIRM` の場合、業務担当者が確認するまで `CONFIRMED` に戻さない。
- 図形・未抽出箇所や100%未満のカバレッジに人の確認が必要かを確認する。

## 5. PR前の検証と手動復旧

`specs-repo` をカレントディレクトリにして実行します。

```powershell
python scripts\validate_schemas.py
python scripts\check_coverage.py
python scripts\render_docs.py
```

検証やカバレッジが失敗した場合、原因のYAML/根拠を修正し、各コマンドを再実行します。MarkdownはYAMLからの生成物として扱い、直接編集しません。未処理アトムはユースケースに根拠付けるか、承認済みの理由で廃止台帳に登録します。未抽出図形はテキスト抽出済みと見なさず、別途確認します。

publishコマンドはPR API接続とGit push認証が設定された環境で、指定されたパスのみを `agent/issue-<番号>` ブランチにコミットし、pushしてGitea PRを作成します。Issue kick/監視は呼び出し側の責任です。PRには対象Issue、機能ID、生成したUC、検証結果、未解決事項を記載してください。publish前にGitea API設定とGit remote/SSH鍵を確認してください。

```powershell
python main.py publish --issue-index 42 --path 00_traceability/atoms/legacy.jsonl --path 03_usecases/MOD01_Order/UC_F_ORD_001.yaml --path 03_usecases/MOD01_Order/UC_F_ORD_001.md
```

`.env` は `agent-system-repo` ルートで読み込まれます。publishはIssueを検索・更新せず、指定ファイルだけをコミットします。既にステージ済みの変更があると停止します。別の未コミット変更はそのまま残ります。PR作成に失敗してもブランチとコミットは保持され、同じIssueブランチから再実行すれば既存PRを再利用します。対象パスに変更がなく既存のIssueブランチにもコミットがない場合は停止し、空ブランチ/PRは作成しません。

## 6. Issue kickからpublish CLIを呼ぶ目標運用

次の手順は目標運用です。publish CLIの呼出し部分は用意されていますが、Issue kick、結果コメント、状態ラベル遷移は別途の設計・実装が必要です。

1. 人がGitea Issueを作り、機能ID、モジュールディレクトリ、対象Word、期待する成果と既知の注意点を記載する。
2. `status:ready-for-agent` を付与する。
3. Issue kickがIssueを排他取得し、処理開始を記録する。重複実行を防ぎ、失敗時はログと `status:agent-error` を残す。
4. Kickが入力と機能IDを検証し、必要なWord一式を `specs-repo/inputs/raw_docs/` から取込む。入力全体がスナップショットになることに注意する。
5. Kickが対象featureの抽出・分析とUC起草を行い、スキーマ、根拠、カバレッジ、Markdown生成を検証する。失敗した候補を正本としてPRに載せない。
6. Kickが公開対象のファイルを明示して `python main.py publish --issue-index <番号> --path <repo相対パス> ...` を呼ぶ。publish CLIは `agent/issue-<番号>` ブランチへ指定ファイルのみをコミットし、Git remoteへpushする。秘密ファイル、モデル、キャッシュ、入力機密情報を対象に指定しない。
7. publish CLIがGitea APIで既存PRを確認し、なければ対象ブランチからPRを作成する。
8. Gitea ActionsがPR上でスキーマ検証、カバレッジ、Markdown同期確認を実行する。CIが利用不能または失敗ならPRレビューへ進めず、原因を記録する。Issueへのリンクコメントと `status:review-required` への遷移はIssue kick側の責任とする。
9. 人がPR上で原文との対応、業務妥当性、未確認事項をレビューする。修正が必要ならYAML/正本を直し、再検証する。
10. 承認とCI成功後に人がマージする。Issueを完了にする状態遷移は、Giteaの実際の運用ルールを定めてから有効化する。

Issue kickを受け入れる前に、少なくとも正常Issue、入力不足、LLM停止/不正JSON、無効な根拠ID、検証失敗、同一Issue二重取得、push失敗、PR既存/作成失敗、Gitea Actions停止の各ケースを試験してください。

## 7. 運用上の安全条件

- 原文、YAML、判断台帳の変更作業と取込・生成・検証を同時に実行しない。複数プロセスの同時更新や、複数ファイル更新の強制終了時の完全な原子性は保証されない。
- 更新取込では既存のJSONLを保ち、入力対象のWord一式を揃える。原文変更でIDが維持されない場合、旧判断の再確認を優先する。
- LLM出力は誤りうる。自動検証成功は内容の業務的正しさを保証しない。
- PR自動化用トークンは専用の最小権限アカウントで発行・保管し、ログやPR本文に出力しない。
- Issue kickが実装されるまでは、手順4.1～5のCLIと、担当者または別プロセスからの明示的なpublish CLI呼出しを運用対象とする。実Gitea連携は本番と同じ認証方式を使う専用環境で確認する。
