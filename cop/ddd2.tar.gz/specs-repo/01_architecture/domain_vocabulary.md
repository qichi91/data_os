<!-- AUTO-GENERATED FROM domain_vocabulary.yaml. DO NOT EDIT DIRECTLY. -->
# ドメイン共通用語集 (Bounded Contexts)

本ドキュメントはモジュラーモノリス内の境界づけられたコンテキストごとに定義されたドメイン用語集です。

| モジュール (Context) | 用語名 (日本語) | システムコード (英名) | 定義・役割 | 補足 / 同名異義語 |
| :--- | :--- | :--- | :--- | :--- |
| `OrderManagement` | **注文** | `Order` | 顧客からの購入申し込み。商品明細、合計金額、与信確認状態を持つ集約。 | 出荷側の荷物単位の注文と混同しないこと。金額情報を管理する唯一のコンテキスト。 |
| `OrderManagement` | **与信枠** | `CreditLimit` | 顧客が一度に未決済で注文可能な上限金額。Geodeの顧客キャッシュから照会する。 | - |
| `LogisticsGateway` | **注文** | `DeliveryOrder` | 外部配送システムへ電文連携するための荷物単位のデータ。 | 受注側の注文から金額情報を除き、配送先住所と個口数を付与したもの。 |
| `LogisticsGateway` | **配送ステータス** | `DeliveryStatus` | 外部GWから電文で非同期通知される配送状況（未発送、輸送中、配達完了など）。 | - |
