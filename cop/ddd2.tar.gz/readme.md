# 閉域網でのローカルLLM仕様起草

この手順は、`agent-system-repo` で旧Word仕様を取り込み、閉域網内のOpenAI互換ローカルLLMで事実抽出・分析・ユースケース起草を行い、`specs-repo` を成果物の正本として管理する方法を説明します。

現在の対象は **Word取込 → 根拠付き事実抽出 → 矛盾・曖昧さ・不足の分析 → UC YAML起草 → 検証 → Markdown生成** です。Gitea Issue/PR自動化とPlantUML/SVG生成は未実装で、この手順には含めません。LLMの出力はレビュー用ドラフトであり、人の判断を確定・代替しません。

## 1. 構成と責務

- `agent-system-repo`: CLI、Word取込、ローカルLLM連携、抽出・分析・起草、検証。
- `specs-repo`: Word入力、機能一覧、原文アトム、判断台帳、UC YAMLなどの正本。
- ローカル推論サーバー: vLLM等のOpenAI互換 `/v1/chat/completions` API。エージェントから閉域網内で到達できること。
- 推論サーバー以外の外部APIやモデル配布サイトへ、実行中のエージェントが接続する必要はありません。

リポジトリは隣接配置を想定します。

```text
workspace/
  agent-system-repo/
  specs-repo/
```

## 2. ステージング環境でのアセット準備

インターネット接続可能な作業環境で、閉域網側と同じCPU/GPU構成に適した推論サーバーイメージを選び、モデルウェイトとコンテナイメージを準備します。モデルの配布条件・ライセンスを確認してください。

```bash
# agent-system-repo でエージェントイメージを作成
docker compose build agent-runner

# 採用する推論サーバーとモデルを取得してイメージ化
VLLM_IMAGE="vllm/vllm-openai:PINNED_TAG"  # 検証済みタグに置き換える
docker pull "$VLLM_IMAGE"
docker save -o agent-images.tar spec-agent-runner:local "$VLLM_IMAGE"

# モデルウェイトと両リポジトリも移送パッケージに含める
```

モデル名、量子化方式、GPUオプションはモデルとサーバーに合わせてください。`latest` ではなく、検証済みのバージョンを固定してください。閉域網でイメージを再ビルドする場合は、ベースイメージとPython依存パッケージのwheelも別途オフラインで用意する必要があります。

## 3. 閉域網側の設定

1. イメージとモデルを検査後にロードし、モデルを推論サーバーが読める場所へ配置します。
2. 2つのリポジトリを隣接して配置し、`specs-repo/inputs/features.tsv` と `specs-repo/inputs/raw_docs/` に入力を用意します。
3. `agent-system-repo/.env.example` を `.env` にコピーし、LLM API URL・モデル名を設定します。Docker Composeから実行する場合、URLはコンテナから到達可能なアドレスにしてください。ホスト上のLLMサーバーなら例は `http://host.docker.internal:30000/v1`、別サーバーなら閉域網内の内部DNS名/IPを使用します。
4. `specs-repo` と `.cache` の書込み権限を実行ユーザーに付与します。コンテナはUID 1000のユーザーで実行します。

設定例:

```ini
SPECS_REPO_PATH=../specs-repo
LLM_API_BASE_URL=http://host.docker.internal:30000/v1
LLM_MODEL_NAME=<推論サーバーに登録したモデル名>
LLM_API_KEY=
LLM_TEMPERATURE=0.1
LLM_MAX_TOKENS=4096
LLM_TIMEOUT_SECONDS=120
LLM_ATOMS_PER_REQUEST=20
```

トークンやモデル提供者の設定に認証が必要な場合のみ、`LLM_API_KEY` を設定してください。機密値を `.env.example` やGit管理対象へ記載しないでください。

## 4. 実行手順

`agent-system-repo` ディレクトリで実行します。ホストPythonを使う場合は先に `python -m pip install -r requirements.txt` を実行してください。

```powershell
python main.py ingest --input-dir ..\specs-repo\inputs\raw_docs
python main.py extract --feature-id F_ORD_001
python main.py generate --feature-id F_ORD_001 --module MOD01_Order
```

Compose実行では、上記コマンドをそれぞれ次の形で実行できます。

```bash
docker compose run --rm agent-runner ingest --input-dir /workspace/specs-repo/inputs/raw_docs
docker compose run --rm agent-runner extract --feature-id F_ORD_001
docker compose run --rm agent-runner generate --feature-id F_ORD_001 --module MOD01_Order
```

`ingest` は入力ディレクトリのWord全体をスナップショットとして扱います。更新時には既存の `00_traceability/atoms/*.jsonl` を残して入力Word一式を配置してください。文書やアトムの削除は非アクティブ履歴として保持し、関連する確定判断の再確認を要求します。

`extract` はアクティブな原文をバッチでLLMへ渡し、根拠ID付き事実を抽出します。続けて抽出内容を分析し、矛盾・曖昧さ・不足を記録します。`generate` は抽出結果、分析、根拠、用語集、共通ルール、モジュール境界、スキーマからUC YAMLを起草します。既存YAMLの上書きには `--force` が必要です。

LLMが不正JSONを返す、根拠を捏造する、スキーマや意味検証に失敗する場合は処理を失敗させ、生成物を正本として公開しません。出力を人がレビューし、曖昧な事項と `PENDING` / `NEEDS_RECONFIRM` の判断を解消してください。

## 5. 検証

```powershell
# agent-system-repo
python -m unittest discover -s tests -v

# specs-repo
python scripts\validate_schemas.py
python scripts\check_coverage.py
python scripts\render_docs.py
```

検証・カバレッジが成功したことと、業務的な正しさは別です。未抽出図形や文書形式の制約も確認してください。MarkdownはYAMLからの生成物として扱い、直接編集しないでください。

## 6. 現在の制約

- Word見出しは標準Heading 1～9を対象とし、入れ子表、ヘッダー・フッター、独自見出しなどは完全対応を保証しません。
- 図形内テキストを含む一部オブジェクトは未抽出として記録し、人の確認が必要です。
- LLMは推測や誤りを含む場合があるため、出典確認と業務レビューが必須です。
- 複数プロセスによる同時更新、および複数ファイルをまたぐ強制終了時の完全な原子性は保証しません。正本の取込・生成・検証は直列に実行してください。
- Gitea Issue監視、ブランチ/PR作成、自動修復、PlantUML描画は実装されていません。
