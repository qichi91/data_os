import json
import argparse
import io
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from zipfile import BadZipFile

import yaml
from docx import Document
from docx.oxml import OxmlElement

from src.config import config
from src.parsers.atomizer import ingest_directory
from src.parsers.canonical import decision_hash
from src.parsers.db import get_db_connection
from src.parsers.extractor import sync_yaml_to_db
from src.validators.semantic_validator import validate_all_layers


class SourceLifecycleTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.specs = self.root / "specs"
        self.docs = self.specs / "inputs" / "raw_docs"
        self.atoms = self.specs / "00_traceability" / "atoms"
        self.context = self.specs / "02_extracted_context" / "F1_context.yaml"
        self.rules = self.specs / "01_architecture" / "business_rules.yaml"
        self.docs.mkdir(parents=True)
        self.schema = Path(__file__).resolve().parents[2] / "specs-repo" / ".schemas" / "usecase.schema.yaml"
        (self.specs / ".schemas").mkdir()
        (self.specs / ".schemas" / "usecase.schema.yaml").write_bytes(self.schema.read_bytes())
        (self.specs / "templates").mkdir()
        template = self.schema.parent.parent / "templates" / "usecase.md.j2"
        (self.specs / "templates" / template.name).write_bytes(template.read_bytes())
        features = self.specs / "inputs" / "features.tsv"
        features.parent.mkdir(parents=True, exist_ok=True)
        features.write_text(
            "大区分\t中区分\t小区分\t機能ID\t機能名\t概要\n"
            "受注管理\t注文受付\t新規登録\tF1\t新規受注登録\t注文を検証して登録する\n",
            encoding="utf-8",
        )
        self.settings = patch.multiple(
            config,
            SPECS_REPO_PATH=self.specs,
            CACHE_DB_PATH=self.root / "cache" / "store.sqlite",
        )
        self.settings.start()
        self.addCleanup(self.settings.stop)

    def write_yaml(self, path, value):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(yaml.safe_dump(value, allow_unicode=True), encoding="utf-8")

    def read_yaml(self, path):
        return yaml.safe_load(path.read_text(encoding="utf-8"))

    def document(self, sections):
        doc = Document()
        for heading, paragraphs in sections:
            doc.add_heading(heading, level=1)
            for text in paragraphs:
                doc.add_paragraph(text)
        doc.save(self.docs / "legacy.docx")

    def ingest(self):
        ingest_directory(self.docs, self.atoms)

    def records(self):
        return [
            json.loads(line)
            for line in (self.atoms / "legacy.jsonl").read_text(encoding="utf-8").splitlines()
        ]

    def active(self, text):
        return [
            record for record in self.records()
            if record.get("active", True) and record["text_content"] == text
        ]

    def approve(self, atom):
        self.write_yaml(self.context, {
            "feature_id": "F1",
            "extracted_facts": {},
            "decision_items": [{
                "decision_id": "DEC_1",
                "source_atom_id": atom["atom_id"],
                "source_hashes": {atom["atom_id"]: atom["content_hash"]},
                "status": "CONFIRMED",
                "human_decision_text": "Preserve the approved behavior",
            }],
        })

    def draft(self, ref):
        return {
            "id": "UC_F1", "title": "Register", "module": "Order", "actor": "Operator",
            "feature_id": "F1",
            "basic_flow": [{
                "step": 1, "actor_action": "Request", "system_response": "Register",
                "source_atom_ref": ref,
            }],
            "robustness_model": {"boundaries": [], "controls": [], "entities": [], "relations": []},
        }

    def sync(self):
        conn = get_db_connection()
        try:
            sync_yaml_to_db(conn, "F1", self.context, self.rules)
        finally:
            conn.close()

    def test_rule_deletion_is_independent_of_cache_history(self):
        self.document([("Order", ["Credit check"])])
        self.ingest()
        atom = self.active("Credit check")[0]
        self.write_yaml(self.rules, {"rules": [{
            "rule_id": "RULE_1", "source_atom_id": atom["atom_id"],
            "source_hashes": {atom["atom_id"]: atom["content_hash"]},
            "content": "Adopted rule", "status": "ACTIVE",
        }]})
        self.sync()
        self.assertEqual(validate_all_layers(self.draft("RULE_1")), [])
        self.write_yaml(self.rules, {"rules": []})
        self.sync()
        before = validate_all_layers(self.draft("RULE_1"))
        self.assertTrue(before)
        config.CACHE_DB_PATH.unlink()
        self.sync()
        self.assertEqual(validate_all_layers(self.draft("RULE_1")), before)
        self.assertEqual(validate_all_layers(self.draft(atom["atom_id"])), [])

    def test_source_edit_and_deletion_reconfirm_without_losing_human_text(self):
        self.document([("Order", ["Credit check", "Keep"])])
        self.ingest()
        atom = self.active("Credit check")[0]
        self.approve(atom)
        self.write_yaml(self.specs / "03_usecases" / "UC_F1.yaml", self.draft("DEC_1"))
        self.write_yaml(self.rules, {"rules": [{
            "rule_id": "RULE_1", "source_atom_id": atom["atom_id"],
            "source_hashes": {atom["atom_id"]: atom["content_hash"]},
            "content": "Human-authored adopted rule", "status": "ACTIVE",
        }]})
        self.document([("Order", ["Changed credit check", "Keep"])])
        self.ingest()
        decision = self.read_yaml(self.context)["decision_items"][0]
        self.assertEqual(decision["status"], "NEEDS_RECONFIRM")
        self.assertEqual(decision["human_decision_text"], "Preserve the approved behavior")
        rule = self.read_yaml(self.rules)["rules"][0]
        self.assertEqual(rule["status"], "NEEDS_RECONFIRM")
        self.assertEqual(rule["content"], "Human-authored adopted rule")
        self.assertTrue(validate_all_layers(self.draft("DEC_1")))
        report = self.read_yaml(self.specs / "00_traceability" / "lifecycle_report.yaml")
        self.assertIn("DEC_1", {item["id"] for item in report["unconfirmed_items"]})
        self.assertIn("UC_F1", {item["usecase_id"] for item in report["affected_usecases"]})
        self.assertTrue(any(not r["active"] and r["atom_id"] == atom["atom_id"] for r in self.records()))
        keep = self.active("Keep")[0]
        self.approve(keep)
        self.document([("Order", ["Changed credit check"])])
        self.ingest()
        self.assertEqual(self.read_yaml(self.context)["decision_items"][0]["status"], "NEEDS_RECONFIRM")

    def test_identical_text_in_other_section_never_inherits_decision(self):
        self.document([("Order", ["Shared condition"]), ("Shipping", ["Other"])])
        self.ingest()
        original = self.active("Shared condition")[0]
        self.approve(original)
        self.document([("Order", ["Shared condition"]), ("Shipping", ["Shared condition"])])
        self.ingest()
        copies = self.active("Shared condition")
        self.assertEqual(len(copies), 2)
        self.assertEqual(len({r["atom_id"] for r in copies}), 2)
        self.assertEqual(
            next(r for r in copies if r["section_path"] == ["Order"])["atom_id"],
            original["atom_id"],
        )
        self.document([("Shipping", ["Shared condition"])])
        self.ingest()
        self.assertNotEqual(self.active("Shared condition")[0]["atom_id"], original["atom_id"])
        self.assertEqual(self.read_yaml(self.context)["decision_items"][0]["status"], "NEEDS_RECONFIRM")

    def test_insertion_and_duplicate_ambiguity(self):
        self.document([("Order", ["A", "B"])])
        self.ingest()
        old_ids = {r["text_content"]: r["atom_id"] for r in self.records() if r["active"]}
        self.document([("Order", ["New", "A", "B"])])
        self.ingest()
        self.assertEqual(self.active("A")[0]["atom_id"], old_ids["A"])
        self.assertEqual(self.active("B")[0]["atom_id"], old_ids["B"])
        self.approve(self.active("A")[0])
        self.document([("Order", ["New", "A", "A", "B"])])
        self.ingest()
        self.assertNotIn(old_ids["A"], {r["atom_id"] for r in self.active("A")})
        self.assertEqual(self.read_yaml(self.context)["decision_items"][0]["status"], "NEEDS_RECONFIRM")

    def test_table_change_and_document_order(self):
        doc = Document()
        doc.add_heading("Order", level=1)
        doc.add_paragraph("Before")
        table = doc.add_table(rows=2, cols=2)
        table.cell(0, 0).text = "Condition"
        table.cell(0, 1).text = "Result"
        table.cell(1, 0).text = "Limit"
        table.cell(1, 1).text = "Hold"
        doc.add_paragraph("After")
        doc.save(self.docs / "legacy.docx")
        self.ingest()
        records = [r for r in self.records() if r["active"]]
        self.assertEqual([r["kind"] for r in records], ["paragraph", "table", "paragraph"])
        self.assertEqual(records[1]["table_rows"][1], ["Limit", "Hold"])
        self.approve(records[1])
        table.cell(1, 1).text = "Reject"
        doc.save(self.docs / "legacy.docx")
        self.ingest()
        self.assertEqual(self.read_yaml(self.context)["decision_items"][0]["status"], "NEEDS_RECONFIRM")

    def test_invalid_input_does_not_replace_cache_or_canonical_files(self):
        self.document([("Order", ["Keep"])])
        self.ingest()
        original = (self.atoms / "legacy.jsonl").read_bytes()
        (self.docs / "broken.docx").write_bytes(b"not a Word document")
        with self.assertRaises(BadZipFile):
            self.ingest()
        self.assertEqual((self.atoms / "legacy.jsonl").read_bytes(), original)
        conn = sqlite3.connect(config.CACHE_DB_PATH)
        try:
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM atoms").fetchone()[0], 1)
        finally:
            conn.close()

    def test_repeated_ingest_and_sync_preserve_duplicate_ids_and_metadata(self):
        self.document([("Order", ["Same", "Same"])])
        self.ingest()
        before = (self.atoms / "legacy.jsonl").read_bytes()
        self.ingest()
        self.sync()
        self.sync()
        self.assertEqual((self.atoms / "legacy.jsonl").read_bytes(), before)
        conn = get_db_connection()
        try:
            row = conn.execute("SELECT * FROM ingestion_meta").fetchone()
            self.assertEqual(row["extracted_elements"], 2)
        finally:
            conn.close()

    def test_invalid_ledger_preserves_cache(self):
        self.document([("Order", ["Keep"])])
        self.ingest()
        self.write_yaml(self.rules, {"rules": [
            {"rule_id": "RULE_BAD", "content": "text", "status": "UNKNOWN"},
        ]})
        with self.assertRaisesRegex(ValueError, "status"):
            self.sync()
        conn = get_db_connection()
        try:
            self.assertEqual(conn.execute("SELECT COUNT(*) FROM atoms").fetchone()[0], 1)
        finally:
            conn.close()

    def test_decision_deletion_is_reflected_and_other_feature_is_loaded(self):
        self.document([("Order", ["Keep"])])
        self.ingest()
        atom = self.active("Keep")[0]
        self.approve(atom)
        other = self.read_yaml(self.context)
        other["feature_id"] = "F2"
        other["decision_items"][0]["decision_id"] = "DEC_OTHER"
        self.write_yaml(self.context.parent / "F2_context.yaml", other)
        self.sync()
        self.assertEqual(validate_all_layers(self.draft("DEC_OTHER")), [])
        self.write_yaml(self.context, {"feature_id": "F1", "decision_items": []})
        self.assertTrue(validate_all_layers(self.draft("DEC_1")))
        self.assertEqual(validate_all_layers(self.draft("DEC_OTHER")), [])

    def test_legacy_missing_provenance_requires_reconfirmation(self):
        self.document([("Order", ["Keep"])])
        self.ingest()
        self.approve(self.active("Keep")[0])
        document = self.read_yaml(self.context)
        del document["decision_items"][0]["source_hashes"]
        self.write_yaml(self.context, document)
        self.sync()
        self.assertEqual(self.read_yaml(self.context)["decision_items"][0]["status"], "NEEDS_RECONFIRM")

    def test_dependent_rule_and_human_rule_content_are_preserved(self):
        self.document([("Order", ["Keep"])])
        self.ingest()
        self.approve(self.active("Keep")[0])
        decision = self.read_yaml(self.context)["decision_items"][0]
        self.write_yaml(self.rules, {"rules": [{
            "rule_id": "RULE_DERIVED", "content": "Human rule", "status": "ACTIVE",
            "source_decision_ids": ["DEC_1"], "decision_hashes": {"DEC_1": decision_hash(decision)},
        }]})
        self.assertEqual(validate_all_layers(self.draft("RULE_DERIVED")), [])
        document = self.read_yaml(self.context)
        document["decision_items"][0]["human_decision_text"] = "Different decision"
        self.write_yaml(self.context, document)
        self.assertTrue(validate_all_layers(self.draft("RULE_DERIVED")))
        rule = self.read_yaml(self.rules)["rules"][0]
        self.assertEqual(rule["status"], "NEEDS_RECONFIRM")
        self.assertEqual(rule["content"], "Human rule")

    def test_pending_decision_is_rendered_without_llm_regeneration(self):
        from main import render_markdown

        self.document([("Order", ["Keep"])])
        self.ingest()
        self.approve(self.active("Keep")[0])
        document = self.read_yaml(self.context)
        document["decision_items"][0]["status"] = "PENDING"
        self.write_yaml(self.context, document)
        uc_path = self.specs / "03_usecases" / "UC_F1.yaml"
        self.write_yaml(uc_path, self.draft(self.active("Keep")[0]["atom_id"]))
        self.assertEqual(validate_all_layers(self.read_yaml(uc_path)), [])
        render_markdown(uc_path)
        self.assertIn("DEC_1", uc_path.with_suffix(".md").read_text(encoding="utf-8"))
        self.assertNotIn("unconfirmed_issues", self.read_yaml(uc_path))

    def test_shape_only_paragraph_has_a_locatable_unextracted_record(self):
        doc = Document()
        doc.add_heading("Order", level=1)
        paragraph = doc.add_paragraph()
        paragraph.add_run()._r.append(OxmlElement("w:drawing"))
        doc.save(self.docs / "legacy.docx")
        self.ingest()
        record = next(r for r in self.records() if r["active"])
        self.assertEqual(record["kind"], "unextracted")
        self.assertEqual(record["section_path"], ["Order"])
        self.assertIn("source_location", record)

    def test_cli_verify_uses_current_canonical_snapshot(self):
        from main import cmd_verify

        self.document([("Order", ["Keep"])])
        self.ingest()
        self.approve(self.active("Keep")[0])
        uc_path = self.specs / "03_usecases" / "UC_F1.yaml"
        self.write_yaml(uc_path, self.draft("DEC_1"))
        with patch("sys.stdout", new_callable=io.StringIO):
            cmd_verify(argparse.Namespace(yaml_file=str(uc_path)))
        self.assertTrue(uc_path.with_suffix(".md").exists())
        document = self.read_yaml(self.context)
        document["decision_items"][0]["status"] = "PENDING"
        self.write_yaml(self.context, document)
        with patch("sys.stdout", new_callable=io.StringIO):
            with self.assertRaises(SystemExit) as failure:
                cmd_verify(argparse.Namespace(yaml_file=str(uc_path)))
        self.assertEqual(failure.exception.code, 1)

    def test_explicit_reconfirmation_uses_new_evidence(self):
        self.document([("Order", ["Old condition"])])
        self.ingest()
        self.approve(self.active("Old condition")[0])
        self.document([("Order", ["New condition"])])
        self.ingest()
        current = self.active("New condition")[0]
        document = self.read_yaml(self.context)
        decision = document["decision_items"][0]
        decision.update({
            "source_atom_id": current["atom_id"],
            "source_hashes": {current["atom_id"]: current["content_hash"]},
            "status": "CONFIRMED",
        })
        self.write_yaml(self.context, document)
        self.assertEqual(validate_all_layers(self.draft("DEC_1")), [])
        self.assertEqual(self.read_yaml(self.context)["decision_items"][0]["human_decision_text"],
                         "Preserve the approved behavior")

    def test_duplicate_heading_sections_do_not_exchange_ids(self):
        self.document([("Order", ["First"]), ("Order", ["Second"])])
        self.ingest()
        old = self.active("Second")[0]
        self.approve(old)
        self.document([("Order", ["Second"])])
        self.ingest()
        self.assertNotEqual(self.active("Second")[0]["atom_id"], old["atom_id"])
        self.assertEqual(self.read_yaml(self.context)["decision_items"][0]["status"], "NEEDS_RECONFIRM")

    def test_long_table_content_is_not_truncated(self):
        doc = Document()
        doc.add_heading("Order", level=1)
        table = doc.add_table(rows=2, cols=2)
        table.cell(0, 0).text = "Condition"
        table.cell(0, 1).text = "Result"
        table.cell(1, 0).text = "X" * 300
        table.cell(1, 1).text = "Important final condition"
        doc.save(self.docs / "legacy.docx")
        self.ingest()
        record = next(r for r in self.records() if r["active"])
        self.assertIn("Important final condition", record["text_content"])
        self.assertEqual(record["table_rows"][1][0], "X" * 300)

    def test_llm_extracts_traceable_facts_and_drafts_valid_usecase(self):
        from src.parsers.drafter import generate_usecase
        from src.parsers.extractor import extract_and_build_context

        class FakeLLM:
            def __init__(self, responses):
                self.responses = iter(responses)

            def generate_json(self, system_prompt, user_prompt):
                return next(self.responses)

        self.document([("Order", ["Operator submits an order."])])
        self.ingest()
        atom = self.active("Operator submits an order.")[0]
        self.approve(atom)
        original_decisions = self.read_yaml(
            self.specs / "02_extracted_context" / "F1_context.yaml"
        )["decision_items"]
        context_path = self.specs / "02_extracted_context" / "F1_context.yaml"
        self.specs.joinpath("03_usecases", "MOD01_Order").mkdir(parents=True)

        extract_and_build_context(
            "F1",
            context_path,
            FakeLLM([
                {
                    "extracted_facts": {
                        "actors_and_triggers": [],
                        "normal_flow_facts": [{
                            "text": "The operator submits an order.",
                            "source_atoms": [atom["atom_id"]],
                        }],
                        "exception_and_validation_facts": [],
                        "data_and_entities": [],
                    },
                },
                {
                    "analysis": {
                        "summary": "The source describes a simple order request.",
                        "conflicts": [],
                        "ambiguities": [],
                        "gaps": [],
                    },
                },
            ]),
        )
        self.assertEqual(
            self.read_yaml(context_path)["extracted_facts"]["normal_flow_facts"][0]["source_atoms"],
            [atom["atom_id"]],
        )
        self.assertIn("summary", self.read_yaml(context_path)["analysis"])
        self.assertEqual(self.read_yaml(context_path)["decision_items"], original_decisions)

        candidate = {
            "id": "UC_F1",
            "title": "Register an order",
            "module": "MOD01_Order",
            "feature_id": "F1",
            "actor": "Operator",
            "success_guarantees": ["The order is registered."],
            "basic_flow": [{
                "step": 1,
                "actor_action": "Submit an order",
                "system_response": "Register the order",
                "source_atom_ref": atom["atom_id"],
            }],
            "robustness_model": {
                "boundaries": [],
                "controls": [],
                "entities": [],
                "relations": [],
            },
        }
        output = generate_usecase(
            "F1",
            "MOD01_Order",
            llm_client=FakeLLM([candidate]),
        )
        self.assertTrue(output.exists())
        self.assertEqual(
            self.read_yaml(output)["basic_flow"][0]["source_atom_ref"],
            atom["atom_id"],
        )

    def test_extraction_rejects_llm_source_ids_not_in_the_batch(self):
        from src.parsers.extractor import _validate_extraction

        with self.assertRaisesRegex(ValueError, "unknown or out-of-batch"):
            _validate_extraction({
                "extracted_facts": {
                    "normal_flow_facts": [{
                        "text": "Untraceable fact",
                        "source_atoms": ["ATOM_NOT_IN_BATCH"],
                    }],
                },
            }, {"ATOM_ALLOWED"})

    def test_local_llm_client_uses_chat_completions_json_mode(self):
        from unittest.mock import Mock

        from src.clients.llm_client import LocalLLMClient

        response = Mock()
        response.json.return_value = {
            "choices": [{"message": {"content": '```json\n{"ok": true}\n```'}}],
        }
        with patch.multiple(
            config,
            LLM_API_BASE_URL="http://llm.internal/v1",
            LLM_MODEL_NAME="local-model",
            LLM_API_KEY="test-token",
        ), patch("src.clients.llm_client.httpx.post", return_value=response) as post:
            self.assertEqual(LocalLLMClient().generate_json("system", "user"), {"ok": True})
        self.assertEqual(post.call_args.args[0], "http://llm.internal/v1/chat/completions")
        self.assertEqual(post.call_args.kwargs["headers"]["Authorization"], "Bearer test-token")
        self.assertEqual(post.call_args.kwargs["json"]["response_format"], {"type": "json_object"})


if __name__ == "__main__":
    unittest.main()
