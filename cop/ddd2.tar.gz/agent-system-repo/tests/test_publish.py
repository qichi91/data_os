import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from src.config import config
from src.publish import PublishError, publish_changes


class PublishTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        self.repo = root / "specs"
        self.remote = root / "remote.git"
        self.repo.mkdir()
        self.git("init", "-b", "main")
        self.git("config", "user.name", "Test User")
        self.git("config", "user.email", "test@example.invalid")
        (self.repo / "tracked.txt").write_text("before\n", encoding="utf-8")
        self.git("add", "tracked.txt")
        self.git("commit", "-m", "initial")
        subprocess.run(["git", "init", "--bare", str(self.remote)], check=True, capture_output=True)
        self.git("remote", "add", "origin", str(self.remote))
        self.git("push", "-u", "origin", "main")
        self.settings = patch.multiple(
            config,
            SPECS_REPO_PATH=self.repo,
            GITEA_API_URL="http://gitea.internal",
            GITEA_API_TOKEN="test-secret",
            GITEA_REPO_OWNER="architect",
            GITEA_REPO_NAME="specs",
            GIT_REMOTE_NAME="origin",
            GIT_BASE_BRANCH="main",
            GIT_AUTHOR_NAME="Spec Agent",
            GIT_AUTHOR_EMAIL="spec-agent@example.invalid",
        )
        self.settings.start()
        self.addCleanup(self.settings.stop)

    def git(self, *args):
        return subprocess.run(
            ["git", "-C", str(self.repo), *args],
            check=True,
            capture_output=True,
            text=True,
        )

    def mock_api(self, existing=None):
        response_get = Mock()
        response_get.json.return_value = existing or []
        response_post = Mock()
        response_post.json.return_value = {
            "html_url": "http://gitea.internal/architect/specs/pulls/42",
            "head": {"ref": "agent/issue-42"},
        }
        client = Mock()
        client.__enter__ = Mock(return_value=client)
        client.__exit__ = Mock(return_value=False)
        client.get.return_value = response_get
        client.post.return_value = response_post
        return client

    def test_publishes_only_explicit_files_and_creates_pull_request(self):
        selected = self.repo / "03_usecases" / "MOD01_Order" / "UC_F1.yaml"
        selected.parent.mkdir(parents=True)
        selected.write_text("title: Draft\n", encoding="utf-8")
        unrelated = self.repo / "private-notes.txt"
        unrelated.write_text("must remain uncommitted\n", encoding="utf-8")
        client = self.mock_api()

        with patch("src.publish.httpx.Client", return_value=client):
            result = publish_changes(
                42,
                ["03_usecases/MOD01_Order/UC_F1.yaml"],
                self.repo,
            )

        self.assertTrue(result["created"])
        self.assertEqual(result["branch"], "agent/issue-42")
        self.assertEqual(
            self.git("show", "--pretty=format:", "--name-only", "HEAD").stdout.strip(),
            "03_usecases/MOD01_Order/UC_F1.yaml",
        )
        self.assertEqual(
            subprocess.run(
                ["git", "--git-dir", str(self.remote), "show", "refs/heads/agent/issue-42:03_usecases/MOD01_Order/UC_F1.yaml"],
                check=True,
                capture_output=True,
                text=True,
            ).stdout,
            "title: Draft\n",
        )
        self.assertIn("private-notes.txt", self.git("status", "--short").stdout)
        client.post.assert_called_once()
        self.assertEqual(
            client.post.call_args.kwargs["json"]["head"],
            "agent/issue-42",
        )

    def test_retry_reuses_existing_branch_and_pull_request(self):
        selected = self.repo / "UC_F1.yaml"
        selected.write_text("title: Draft\n", encoding="utf-8")
        client = self.mock_api()
        with patch("src.publish.httpx.Client", return_value=client):
            first = publish_changes(42, ["UC_F1.yaml"], self.repo)
        self.assertTrue(first["created"])

        client = self.mock_api([{
            "html_url": "http://gitea.internal/architect/specs/pulls/42",
            "head": {"ref": "agent/issue-42"},
        }])
        with patch("src.publish.httpx.Client", return_value=client):
            retry = publish_changes(42, ["UC_F1.yaml"], self.repo)
        self.assertFalse(retry["created"])
        client.post.assert_not_called()

    def test_refuses_staged_changes(self):
        selected = self.repo / "UC_F1.yaml"
        selected.write_text("title: Draft\n", encoding="utf-8")
        self.git("add", "UC_F1.yaml")
        with self.assertRaisesRegex(PublishError, "Staged changes"):
            publish_changes(42, ["UC_F1.yaml"], self.repo)
        self.assertEqual(self.git("branch", "--show-current").stdout.strip(), "main")

    def test_refuses_paths_outside_repository(self):
        selected = self.repo / "UC_F1.yaml"
        selected.write_text("title: Draft\n", encoding="utf-8")
        with self.assertRaisesRegex(PublishError, "outside specs repository"):
            publish_changes(42, [str(selected.parent.parent / "outside.yaml")], self.repo)

    def test_refuses_env_secret_files(self):
        secret = self.repo / ".env.production"
        secret.write_text("TOKEN=do-not-publish\n", encoding="utf-8")
        with self.assertRaisesRegex(PublishError, "repository metadata or secrets"):
            publish_changes(42, [".env.production"], self.repo)

    def test_refuses_no_change_without_creating_issue_branch(self):
        with self.assertRaisesRegex(PublishError, "None of the selected paths has changes"):
            publish_changes(42, ["tracked.txt"], self.repo)
        self.assertEqual(self.git("branch", "--show-current").stdout.strip(), "main")

    def test_rejects_missing_gitea_configuration(self):
        selected = self.repo / "UC_F1.yaml"
        selected.write_text("title: Draft\n", encoding="utf-8")
        with patch.object(config, "GITEA_API_TOKEN", ""):
            with self.assertRaisesRegex(PublishError, "GITEA_API_TOKEN"):
                publish_changes(42, ["UC_F1.yaml"], self.repo)


if __name__ == "__main__":
    unittest.main()
