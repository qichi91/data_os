import hashlib
import json
import re
from collections import Counter, defaultdict
from contextlib import closing
from pathlib import Path
from uuid import uuid4

from docx import Document
from docx.table import Table
from docx.text.paragraph import Paragraph
from lxml import etree

from src.config import config
from src.parsers.canonical import (
    ledger_contents,
    lifecycle_report,
    load_ledger,
    publish_files,
    read_atoms,
    reconcile_ledger,
    replace_cache,
)
from src.parsers.db import get_db_connection


def get_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _parse_document(path: Path) -> list[dict]:
    document = Document(path)
    version = hashlib.sha256(path.read_bytes()).hexdigest()
    headings = []
    records = []
    section_counts = Counter()
    current_scope = ((), 0)
    for location, block in enumerate(document.iter_inner_content()):
        if isinstance(block, Paragraph):
            text = block.text.strip()
            style = block.style.name if block.style is not None else ""
            heading = re.fullmatch(r"Heading ([1-9])", style)
            if heading:
                depth = int(heading.group(1))
                headings = headings[:depth - 1] + [text]
                section_counts[tuple(headings)] += 1
                current_scope = (tuple(headings), section_counts[tuple(headings)])
            elif text:
                records.append(_record(path, version, headings, location, "paragraph", text, current_scope))
            for index, shape in enumerate(block._p.xpath(
                ".//*[local-name()='drawing' or local-name()='shape']"
            )):
                record = _record(
                    path, version, headings, location, "unextracted",
                    f"Unextracted drawing at block {location}, item {index}", current_scope,
                )
                record["content_hash"] = get_hash(etree.tostring(shape, encoding="unicode"))
                record["shape_index"] = index
                records.append(record)
        elif isinstance(block, Table):
            rows = [[cell.text for cell in row.cells] for row in block.rows]
            record = _record(
                path, version, headings, location, "table",
                "\n".join("| " + " | ".join(row) + " |" for row in rows), current_scope,
            )
            record["table_rows"] = rows
            records.append(record)
    return records


def _record(path: Path, version: str, headings: list[str], location: int,
            kind: str, text: str, scope: tuple) -> dict:
    return {
        "source_doc": path.name,
        "document_version": version,
        "section_path": list(headings),
        "section_id": "SEC_" + get_hash(path.name + json.dumps(scope, ensure_ascii=False))[:24],
        "section_occurrence": scope[1],
        "source_location": location,
        "kind": kind,
        "text_content": text,
        "content_hash": get_hash(text),
        "active": True,
    }


def _match_records(old: list[dict], new: list[dict]) -> list[dict]:
    old_groups = defaultdict(list)
    new_groups = defaultdict(list)
    for record in old:
        if record.get("active", True) and "section_path" in record and "kind" in record:
            old_groups[(tuple(record["section_path"]), record["kind"], record.get("section_occurrence", 0))].append(record)
    for record in new:
        new_groups[(tuple(record["section_path"]), record["kind"], record["section_occurrence"])].append(record)
    reused = set()
    for key, candidates in new_groups.items():
        previous = old_groups.get(key, [])
        old_hashes = Counter(record["content_hash"] for record in previous)
        new_hashes = Counter(record["content_hash"] for record in candidates)
        # Duplicated heading paths are not safe identity anchors.
        repeated_heading = any(k[0] == key[0] and k[2] != key[2] for k in old_groups) or any(
            k[0] == key[0] and k[2] != key[2] for k in new_groups
        )
        for index, record in enumerate(candidates):
            content_hash = record["content_hash"]
            unchanged_snapshot = (
                previous and record["document_version"] == previous[0].get("document_version")
                and len(previous) == len(candidates)
            )
            if unchanged_snapshot:
                original = previous[index]
                record["atom_id"] = original["atom_id"]
                reused.add(original["atom_id"])
            elif not repeated_heading and old_hashes[content_hash] == new_hashes[content_hash] == 1:
                original = next(item for item in previous if item["content_hash"] == content_hash)
                record["atom_id"] = original["atom_id"]
                reused.add(original["atom_id"])
            else:
                record["atom_id"] = "ATOM_" + uuid4().hex
    history = []
    for record in old:
        if record["atom_id"] not in reused:
            history.append({**record, "active": False})
    return new + history


def ingest_directory(input_dir: Path, jsonl_output_dir: Path) -> None:
    if not input_dir.is_dir():
        raise ValueError(f"Input directory does not exist: {input_dir}")
    paths = sorted(path for path in input_dir.glob("*.docx") if not path.name.startswith("~$"))
    if not paths:
        raise ValueError("No Word documents found; refusing to replace the current source snapshot")
    documents = read_atoms(jsonl_output_dir)
    updated = {}
    for path in paths:
        target = jsonl_output_dir / f"{path.stem}.jsonl"
        updated[target] = _match_records(documents.get(target, []), _parse_document(path))
    for path, records in documents.items():
        if path not in updated:
            updated[path] = [{**record, "active": False} for record in records]

    root = config.SPECS_REPO_PATH
    rules_path = root / "01_architecture" / "business_rules.yaml"
    contexts, rules = load_ledger(root / "02_extracted_context", rules_path)
    reconcile_ledger(updated, contexts, rules)
    contents = ledger_contents(contexts, rules, rules_path)
    contents.update(lifecycle_report(updated, contexts, rules))
    for path, records in updated.items():
        contents[path] = "".join(json.dumps(item, ensure_ascii=False) + "\n" for item in records)

    # All Word files and canonical ledgers have been parsed before publishing.
    publish_files(contents)
    with closing(get_db_connection()) as conn:
        replace_cache(conn, updated, contexts, rules)
    print(f"[INGEST] Published {len(paths)} documents; changed or ambiguous evidence requires reconfirmation.")
