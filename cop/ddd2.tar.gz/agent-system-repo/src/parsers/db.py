import sqlite3

from src.config import config


def get_db_connection() -> sqlite3.Connection:
    config.CACHE_DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(config.CACHE_DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


def init_spec_db(conn: sqlite3.Connection, force_rebuild: bool = False) -> sqlite3.Connection:
    """Keep the live cache until a validated canonical snapshot is ready."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS ingestion_meta (
            doc_name TEXT PRIMARY KEY, total_elements INTEGER,
            extracted_elements INTEGER, unextracted_elements INTEGER
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sections (
            section_id TEXT PRIMARY KEY, doc_name TEXT, section_path TEXT,
            is_common_spec INTEGER DEFAULT 0
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS atoms (
            atom_id TEXT PRIMARY KEY, doc_name TEXT, section_id TEXT,
            text_content TEXT, content_hash TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS feature_mappings (
            feature_id TEXT, atom_id TEXT, disposition TEXT, category TEXT,
            PRIMARY KEY (feature_id, atom_id)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS decision_items (
            decision_id TEXT PRIMARY KEY, feature_id TEXT, source_atom_id TEXT,
            issue_summary TEXT, status TEXT, human_decision_text TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS common_rules (
            rule_id TEXT PRIMARY KEY, source_atom_id TEXT, content TEXT, status TEXT
        )
    """)
    # Older caches are disposable, but their missing columns must not break refresh.
    for table, columns in {
        "atoms": {"doc_name": "TEXT", "section_id": "TEXT", "content_hash": "TEXT"},
        "ingestion_meta": {"unextracted_elements": "INTEGER"},
    }.items():
        present = {row["name"] for row in conn.execute(f"PRAGMA table_info({table})")}
        for column, sql_type in columns.items():
            if column not in present:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {sql_type}")
    if force_rebuild:
        for table in ("ingestion_meta", "sections", "atoms", "feature_mappings",
                      "decision_items", "common_rules"):
            conn.execute(f"DELETE FROM {table}")
    return conn
