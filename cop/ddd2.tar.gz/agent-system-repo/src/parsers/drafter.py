import json
import re
from pathlib import Path

import jsonschema
import yaml

from src.clients.llm_client import LocalLLMClient
from src.config import config
from src.parsers.canonical import publish_files, read_atoms, read_mapping
from src.parsers.extractor import _load_prompt
from src.parsers.feature_catalog import load_feature
from src.validators.semantic_validator import validate_all_layers


def _read_optional(path: Path) -> object:
    if not path.is_file():
        return None
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def _architecture_context(root: Path) -> dict:
    paths = {
        "domain_vocabulary": root / "01_architecture" / "domain_vocabulary.yaml",
        "business_rules": root / "01_architecture" / "business_rules.yaml",
        "module_boundaries": root / "01_architecture" / "modular_boundaries.md",
        "common_messaging": root / "01_architecture" / "common_messaging_spec.md",
    }
    return {
        name: (
            path.read_text(encoding="utf-8")
            if path.suffix == ".md" and path.is_file()
            else _read_optional(path)
        )
        for name, path in paths.items()
    }


def generate_usecase(
    feature_id: str,
    module: str,
    output_path: Path | None = None,
    force: bool = False,
    llm_client: LocalLLMClient | None = None,
) -> Path:
    if not re.fullmatch(r"MOD[0-9]{2}_[A-Za-z0-9_]+", module):
        raise ValueError(f"Invalid module directory name: {module!r}")
    root = config.SPECS_REPO_PATH.resolve()
    module_directory = root / "03_usecases" / module
    target = (output_path or module_directory / f"UC_{feature_id}.yaml").resolve()
    if target.parent != module_directory.resolve() or target.suffix.lower() not in {".yaml", ".yml"}:
        raise ValueError("Use case output must be a YAML file directly in the selected module directory")
    if target.exists() and not force:
        raise FileExistsError(f"Refusing to overwrite existing canonical use case: {target}; pass --force")

    feature = load_feature(feature_id)
    context_path = root / "02_extracted_context" / f"{feature_id}_context.yaml"
    if not context_path.is_file():
        raise FileNotFoundError(f"Extract feature {feature_id} before drafting: {context_path}")
    context = read_mapping(context_path)
    if context.get("feature_id") != feature_id:
        raise ValueError(f"{context_path}: feature_id does not match {feature_id}")
    facts = context.get("extracted_facts")
    if not isinstance(facts, dict) or not any(facts.values()):
        raise ValueError(f"No extracted facts for {feature_id}; run extract before generate")

    atoms_by_path = read_atoms(root / "00_traceability" / "atoms")
    active_atoms = [
        atom for records in atoms_by_path.values() for atom in records
        if atom.get("active", True) and atom.get("kind") != "unextracted"
        and isinstance(atom.get("text_content"), str) and atom["text_content"].strip()
    ]
    active_ids = {atom["atom_id"] for atom in active_atoms}
    relevant_ids = {
        atom_id
        for entries in facts.values()
        if isinstance(entries, list)
        for fact in entries
        if isinstance(fact, dict)
        for atom_id in fact.get("source_atoms", [])
        if isinstance(atom_id, str)
    }
    if not relevant_ids or not relevant_ids <= active_ids:
        raise ValueError("Extracted facts contain no current, active source atom references")
    relevant_atoms = [atom for atom in active_atoms if atom["atom_id"] in relevant_ids]

    schema_path = root / ".schemas" / "usecase.schema.yaml"
    if not schema_path.is_file():
        raise FileNotFoundError(f"Use case schema not found: {schema_path}")
    schema = yaml.safe_load(schema_path.read_text(encoding="utf-8"))
    prompt_context = {
        "feature": feature,
        "module": module,
        "extracted_facts": facts,
        "analysis": context.get("analysis", {}),
        "atoms": [
            {
                "atom_id": atom["atom_id"],
                "source_doc": atom.get("source_doc", ""),
                "section_path": atom.get("section_path", []),
                "text_content": atom["text_content"],
            }
            for atom in relevant_atoms
        ],
        "architecture": _architecture_context(root),
        "schema": schema,
        "existing_context": {
            "decision_items": context.get("decision_items", []),
        },
    }
    client = llm_client or LocalLLMClient()
    candidate = client.generate_json(
        _load_prompt("draft_usecase.j2"),
        json.dumps(prompt_context, ensure_ascii=False),
    )
    candidate.setdefault("feature_id", feature_id)
    try:
        jsonschema.validate(instance=candidate, schema=schema)
    except jsonschema.ValidationError as exc:
        raise ValueError(f"Generated use case violates schema at {exc.json_path}: {exc.message}") from exc
    if candidate.get("feature_id") != feature_id:
        raise ValueError("LLM draft feature_id does not match the requested feature")
    if candidate.get("module") != module:
        raise ValueError("LLM draft module does not match the requested module")
    if not str(candidate.get("id", "")).startswith("UC_"):
        raise ValueError("LLM draft must provide a UC_ identifier")
    if not isinstance(candidate.get("success_guarantees"), list) or not candidate["success_guarantees"]:
        raise ValueError("LLM draft must state at least one success guarantee")
    cited_ids = {
        step.get("source_atom_ref")
        for key in ("basic_flow", "alternative_flows")
        for step in candidate.get(key, [])
        if isinstance(step, dict)
    }
    unrelated_ids = cited_ids - relevant_ids
    if unrelated_ids:
        raise ValueError(
            "LLM draft cites atoms outside the extracted feature evidence: "
            + ", ".join(sorted(unrelated_ids))
        )
    errors = validate_all_layers(candidate)
    if errors:
        raise ValueError("Generated use case failed semantic validation: " + "; ".join(errors))
    publish_files({
        target: yaml.safe_dump(candidate, allow_unicode=True, sort_keys=False),
    })
    return target
