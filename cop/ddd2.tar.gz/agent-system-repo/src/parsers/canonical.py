import json
import hashlib
import os
import sqlite3
import tempfile
from pathlib import Path

import yaml

from src.config import config
from src.parsers.db import init_spec_db


def read_mapping(path: Path) -> dict:
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"{path}: expected a YAML mapping")
    return data


def read_atoms(directory: Path) -> dict[Path, list[dict]]:
    documents = {}
    seen = set()
    for path in sorted(directory.glob("*.jsonl")):
        records = []
        for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip():
                continue
            atom = json.loads(line)
            if not isinstance(atom, dict) or not isinstance(atom.get("atom_id"), str):
                raise ValueError(f"{path}:{number}: invalid atom record")
            if atom["atom_id"] in seen:
                raise ValueError(f"{path}:{number}: duplicate atom ID {atom['atom_id']}")
            seen.add(atom["atom_id"])
            records.append(atom)
        documents[path] = records
    return documents


def publish_files(contents: dict[Path, str]) -> None:
    """Stage all candidates; roll back already replaced files on publication error."""
    staged = {}
    originals = {}
    replaced = []
    try:
        for path, text in contents.items():
            path.parent.mkdir(parents=True, exist_ok=True)
            originals[path] = path.read_bytes() if path.exists() else None
            if originals[path] == text.encode("utf-8"):
                continue
            with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as stream:
                temporary = Path(stream.name)
                staged[path] = temporary
                stream.write(text.encode("utf-8"))
        for path, temporary in staged.items():
            os.replace(temporary, path)
            replaced.append(path)
    except OSError:
        for path in reversed(replaced):
            original = originals[path]
            if original is None:
                path.unlink()
            else:
                path.write_bytes(original)
        raise
    finally:
        for temporary in staged.values():
            temporary.unlink(missing_ok=True)


def source_ids(record: dict) -> list[str]:
    ids = record.get("source_atom_ids", [])
    if not isinstance(ids, list):
        raise ValueError("source_atom_ids must be a list")
    ids = list(ids)
    if record.get("source_atom_id"):
        ids.append(record["source_atom_id"])
    if any(not isinstance(ref, str) or not ref.strip() for ref in ids):
        raise ValueError("Source references must be nonempty strings")
    return list(dict.fromkeys(ids))


def load_ledger(context_directory: Path, rules_path: Path) -> tuple[dict[Path, dict], dict]:
    contexts = {path: read_mapping(path) for path in sorted(context_directory.glob("*_context.yaml"))}
    rules = read_mapping(rules_path) if rules_path.exists() else {"rules": []}
    seen = set()
    for path, document in contexts.items():
        feature = document.get("feature_id")
        if not isinstance(feature, str) or not feature:
            raise ValueError(f"{path}: missing feature_id")
        items = document.get("decision_items", [])
        if not isinstance(items, list):
            raise ValueError(f"{path}: decision_items must be a list")
        for item in items:
            _validate_record(item, "decision_id", {"PENDING", "CONFIRMED", "NEEDS_RECONFIRM", "IGNORED"}, seen)
        facts = document.get("extracted_facts", {})
        if not isinstance(facts, dict):
            raise ValueError(f"{path}: extracted_facts must be a mapping")
        for entries in facts.values():
            if not isinstance(entries, list) or any(not isinstance(item, dict) for item in entries):
                raise ValueError(f"{path}: fact categories must contain lists of mappings")
    seen = set()
    if not isinstance(rules.get("rules"), list):
        raise ValueError(f"{rules_path}: rules must be a list")
    for item in rules["rules"]:
        _validate_record(item, "rule_id", {"ACTIVE", "NEEDS_RECONFIRM", "INACTIVE", "DEPRECATED", "PENDING"}, seen)
        if not isinstance(item.get("content"), str):
            raise ValueError(f"{item['rule_id']}: content must be a string")
        refs = item.get("source_decision_ids", [])
        if not isinstance(refs, list) or any(not isinstance(ref, str) or not ref for ref in refs):
            raise ValueError(f"{item['rule_id']}: invalid source_decision_ids")
        if not isinstance(item.get("decision_hashes", {}), dict):
            raise ValueError(f"{item['rule_id']}: decision_hashes must be a mapping")
    return contexts, rules


def _validate_record(record: dict, key: str, statuses: set[str], seen: set[str]) -> None:
    if not isinstance(record, dict):
        raise ValueError(f"Expected mapping for {key}")
    identifier = record.get(key)
    if not isinstance(identifier, str) or not identifier or identifier in seen:
        raise ValueError(f"Missing or duplicate {key}: {identifier}")
    seen.add(identifier)
    if record.get("status") not in statuses:
        raise ValueError(f"{identifier}: invalid or missing status")
    source_ids(record)
    hashes = record.get("source_hashes", {})
    if not isinstance(hashes, dict) or any(
        not isinstance(key, str) or not isinstance(value, str) for key, value in hashes.items()
    ):
        raise ValueError(f"{identifier}: source_hashes must map IDs to hashes")


def reconcile_ledger(documents: dict[Path, list[dict]], contexts: dict[Path, dict], rules: dict) -> None:
    active = {
        atom["atom_id"]: atom for records in documents.values() for atom in records
        if atom.get("active", True)
    }
    decisions = {}
    for document in contexts.values():
        for item in document.get("decision_items", []):
            decisions[item["decision_id"]] = item
            _reconfirm(item, active, "CONFIRMED")
    for rule in rules["rules"]:
        _reconfirm(rule, active, "ACTIVE")
        for reference in rule.get("source_decision_ids", []):
            decision = decisions.get(reference)
            if rule["status"] == "ACTIVE" and (
                decision is None or decision["status"] != "CONFIRMED"
                or rule.get("decision_hashes", {}).get(reference) != decision_hash(decision)
            ):
                rule["status"] = "NEEDS_RECONFIRM"
                rule["reconfirmation_reason"] = f"Decision unavailable, changed or unconfirmed: {reference}"


def decision_hash(decision: dict) -> str:
    payload = {
        "human_decision_text": decision.get("human_decision_text", ""),
        "source_atom_ids": source_ids(decision),
        "source_hashes": decision.get("source_hashes", {}),
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()


def _reconfirm(record: dict, active: dict, approved_status: str) -> None:
    if record["status"] != approved_status:
        return
    references = source_ids(record)
    reasons = []
    if not references and not record.get("source_decision_ids"):
        reasons.append("No source provenance recorded")
    for ref in references:
        atom = active.get(ref)
        expected = record.get("source_hashes", {}).get(ref)
        if atom is None:
            reasons.append(f"Source removed or ambiguous: {ref}")
        elif not expected or expected != atom.get("content_hash"):
            reasons.append(f"Source changed or has no confirmed hash: {ref}")
    if reasons:
        record["status"] = "NEEDS_RECONFIRM"
        record["reconfirmation_reason"] = "; ".join(reasons)


def ledger_contents(contexts: dict[Path, dict], rules: dict, rules_path: Path) -> dict[Path, str]:
    output = {
        path: yaml.safe_dump(data, allow_unicode=True, sort_keys=False)
        for path, data in contexts.items()
    }
    if rules_path.exists() or rules["rules"]:
        output[rules_path] = yaml.safe_dump(rules, allow_unicode=True, sort_keys=False)
    return output


def replace_cache(conn: sqlite3.Connection, documents: dict[Path, list[dict]],
                  contexts: dict[Path, dict], rules: dict) -> None:
    with conn:
        init_spec_db(conn, force_rebuild=True)
        for path, records in documents.items():
            active_records = [atom for atom in records if atom.get("active", True)]
            unextracted = sum(atom.get("kind") == "unextracted" for atom in active_records)
            conn.execute(
                """INSERT INTO ingestion_meta
                   (doc_name, total_elements, extracted_elements, unextracted_elements)
                   VALUES (?, ?, ?, ?)""",
                (path.stem, len(active_records), len(active_records) - unextracted, unextracted),
            )
            for atom in records:
                if not atom.get("active", True):
                    continue
                section = atom.get("section_id")
                if section:
                    conn.execute(
                        "INSERT OR IGNORE INTO sections (section_id, doc_name, section_path) VALUES (?, ?, ?)",
                        (section, atom.get("source_doc", path.stem), json.dumps(atom.get("section_path", []))),
                    )
                conn.execute(
                    "INSERT INTO atoms (atom_id, doc_name, section_id, text_content, content_hash) VALUES (?, ?, ?, ?, ?)",
                    (atom["atom_id"], atom.get("source_doc", path.stem), section,
                     atom.get("text_content", atom.get("text", "")), atom.get("content_hash")),
                )
        for document in contexts.values():
            categories = {
                "actors_and_triggers": "TRIGGER_PRECOND",
                "normal_flow_facts": "NORMAL_BEHAVIOR",
                "exception_and_validation_facts": "ALTERNATE_EXCEPTION",
                "data_and_entities": "DATA_INTERFACE",
            }
            for category, facts in document.get("extracted_facts", {}).items():
                for fact in facts:
                    for atom_id in fact.get("source_atoms", []):
                        if conn.execute("SELECT 1 FROM atoms WHERE atom_id = ?", (atom_id,)).fetchone():
                            conn.execute(
                                """INSERT OR REPLACE INTO feature_mappings
                                   (feature_id, atom_id, disposition, category) VALUES (?, ?, 'ADOPTED', ?)""",
                                (document["feature_id"], atom_id, categories.get(category, category)),
                            )
            for item in document.get("decision_items", []):
                conn.execute(
                    """INSERT INTO decision_items
                       (decision_id, feature_id, source_atom_id, issue_summary, status, human_decision_text)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (item["decision_id"], document["feature_id"], item.get("source_atom_id"),
                     item.get("issue_summary", ""), item["status"], item.get("human_decision_text", "")),
                )
        for rule in rules["rules"]:
            conn.execute(
                "INSERT INTO common_rules (rule_id, source_atom_id, content, status) VALUES (?, ?, ?, ?)",
                (rule["rule_id"], rule.get("source_atom_id"), rule.get("content", ""), rule["status"]),
            )


def synchronize_canonical(conn: sqlite3.Connection) -> None:
    root = config.SPECS_REPO_PATH
    documents = read_atoms(root / "00_traceability" / "atoms")
    rules_path = root / "01_architecture" / "business_rules.yaml"
    contexts, rules = load_ledger(root / "02_extracted_context", rules_path)
    reconcile_ledger(documents, contexts, rules)
    contents = ledger_contents(contexts, rules, rules_path)
    contents.update(lifecycle_report(documents, contexts, rules))
    publish_files(contents)
    replace_cache(conn, documents, contexts, rules)


def lifecycle_report(documents: dict[Path, list[dict]], contexts: dict[Path, dict],
                     rules: dict) -> dict[Path, str]:
    pending = []
    valid = {
        atom["atom_id"] for records in documents.values() for atom in records
        if atom.get("active", True)
    }
    for document in contexts.values():
        for item in document.get("decision_items", []):
            if item["status"] == "CONFIRMED":
                valid.add(item["decision_id"])
            if item["status"] in {"PENDING", "NEEDS_RECONFIRM"}:
                pending.append({
                    "id": item["decision_id"], "feature_id": document["feature_id"],
                    "status": item["status"], "description": item.get("issue_summary", ""),
                    "reason": item.get("reconfirmation_reason", ""),
                })
    for rule in rules["rules"]:
        if rule["status"] == "ACTIVE":
            valid.add(rule["rule_id"])
        if rule["status"] in {"PENDING", "NEEDS_RECONFIRM"}:
            pending.append({
                "id": rule["rule_id"], "status": rule["status"],
                "reason": rule.get("reconfirmation_reason", ""),
            })
    affected = []
    for path in sorted((config.SPECS_REPO_PATH / "03_usecases").rglob("*.yaml")):
        uc = read_mapping(path)
        references = set()
        for key in ("basic_flow", "alternative_flows"):
            steps = uc.get(key, [])
            if not isinstance(steps, list) or any(not isinstance(step, dict) for step in steps):
                raise ValueError(f"{path}: {key} must contain a list of mappings")
            for step in steps:
                reference = step.get("source_atom_ref")
                if isinstance(reference, str) and reference:
                    references.add(reference)
        impacted = sorted(references - valid)
        if impacted or any(item.get("feature_id") == uc.get("feature_id") for item in pending):
            affected.append({"usecase_id": uc.get("id", path.stem), "references": impacted})
    report = {"unconfirmed_items": pending, "affected_usecases": affected}
    path = config.SPECS_REPO_PATH / "00_traceability" / "lifecycle_report.yaml"
    return {path: yaml.safe_dump(report, allow_unicode=True, sort_keys=False)}
