import csv
from pathlib import Path

from src.config import config


def load_feature(feature_id: str) -> dict[str, str]:
    path = config.SPECS_REPO_PATH / "inputs" / "features.tsv"
    if not path.is_file():
        raise FileNotFoundError(f"Feature catalog not found: {path}")
    with path.open(encoding="utf-8-sig", newline="") as stream:
        for row in csv.DictReader(stream, delimiter="\t"):
            if row.get("機能ID") == feature_id:
                return {
                    "feature_id": feature_id,
                    "major_category": row.get("大区分", "").strip(),
                    "middle_category": row.get("中区分", "").strip(),
                    "small_category": row.get("小区分", "").strip(),
                    "name": row.get("機能名", "").strip(),
                    "summary": row.get("概要", "").strip(),
                }
    raise ValueError(f"Feature ID {feature_id!r} is not present in {path}")
