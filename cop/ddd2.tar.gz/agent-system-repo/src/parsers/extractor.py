import json
import sqlite3
from contextlib import closing
from pathlib import Path

import yaml

from src.clients.llm_client import LocalLLMClient
from src.config import config
from src.parsers.canonical import (
    lifecycle_report,
    load_ledger,
    publish_files,
    read_atoms,
    read_mapping,
    reconcile_ledger,
    synchronize_canonical,
)
from src.parsers.db import get_db_connection
from src.parsers.feature_catalog import load_feature


FACT_CATEGORIES = (
    "actors_and_triggers",
    "normal_flow_facts",
    "exception_and_validation_facts",
    "data_and_entities",
)


def _active_atoms() -> list[dict]:
    atom_files = read_atoms(config.SPECS_REPO_PATH / "00_traceability" / "atoms")
    atoms = [
        atom for records in atom_files.values() for atom in records
        if atom.get("active", True) and atom.get("kind") != "unextracted"
        and isinstance(atom.get("text_content"), str) and atom["text_content"].strip()
    ]
    if not atoms:
        raise ValueError("No active text atoms found; ingest Word documents before extraction")
    return atoms


def _load_prompt(name: str) -> str:
    prompt_path = Path(__file__).resolve().parents[1] / "prompts" / name
    return prompt_path.read_text(encoding="utf-8")


def _validate_extraction(result: dict, allowed_ids: set[str]) -> dict[str, list[dict]]:
    facts = result.get("extracted_facts")
    if not isinstance(facts, dict):
        raise ValueError("LLM extraction response must contain extracted_facts object")
    normalized = {category: [] for category in FACT_CATEGORIES}
    for category, entries in facts.items():
        if category not in normalized:
            raise ValueError(f"LLM returned unknown fact category: {category}")
        if not isinstance(entries, list):
            raise ValueError(f"LLM fact category {category} must be a list")
        for entry in entries:
            if not isinstance(entry, dict) or not isinstance(entry.get("text"), str):
                raise ValueError(f"LLM facts in {category} must have text")
            text = entry["text"].strip()
            refs = entry.get("source_atoms")
            if not text or not isinstance(refs, list) or not refs:
                raise ValueError(f"LLM fact in {category} requires text and source_atoms")
            if any(not isinstance(ref, str) or ref not in allowed_ids for ref in refs):
                raise ValueError(f"LLM fact in {category} references an unknown or out-of-batch atom")
            normalized[category].append({
                "text": text,
                "source_atoms": list(dict.fromkeys(refs)),
            })
    return normalized


def _validate_analysis(result: dict, allowed_ids: set[str]) -> dict:
    analysis = result.get("analysis")
    if not isinstance(analysis, dict) or not isinstance(analysis.get("summary"), str):
        raise ValueError("LLM analysis response must contain an analysis object and summary")
    if set(analysis) - {"summary", "conflicts", "ambiguities", "gaps"}:
        raise ValueError("LLM analysis response contains unsupported fields")
    normalized = {"summary": analysis["summary"].strip()}
    for category in ("conflicts", "ambiguities", "gaps"):
        entries = analysis.get(category)
        if not isinstance(entries, list):
            raise ValueError(f"LLM analysis category {category} must be a list")
        normalized[category] = []
        for entry in entries:
            if not isinstance(entry, dict) or not isinstance(entry.get("finding"), str):
                raise ValueError(f"LLM analysis findings in {category} must have finding text")
            refs = entry.get("source_atoms")
            if not entry["finding"].strip() or not isinstance(refs, list) or not refs:
                raise ValueError(f"LLM analysis finding in {category} requires text and source_atoms")
            if any(not isinstance(ref, str) or ref not in allowed_ids for ref in refs):
                raise ValueError(f"LLM analysis finding in {category} references an unknown atom")
            normalized[category].append({
                "finding": entry["finding"].strip(),
                "source_atoms": list(dict.fromkeys(refs)),
            })
    return normalized


def extract_and_build_context(
    feature_id: str,
    output_yaml_path: Path,
    llm_client: LocalLLMClient | None = None,
) -> None:
    feature = load_feature(feature_id)
    atoms = _active_atoms()
    client = llm_client or LocalLLMClient()
    system_prompt = _load_prompt("filter_atoms_batch.j2")
    batch_size = config.LLM_ATOMS_PER_REQUEST
    extracted = {category: [] for category in FACT_CATEGORIES}
    atoms_by_id = {atom["atom_id"]: atom for atom in atoms}
    for start in range(0, len(atoms), batch_size):
        batch = atoms[start:start + batch_size]
        payload = [
            {
                "atom_id": atom["atom_id"],
                "source_doc": atom.get("source_doc", ""),
                "section_path": atom.get("section_path", []),
                "kind": atom.get("kind", ""),
                "text_content": atom["text_content"],
            }
            for atom in batch
        ]
        result = client.generate_json(
            system_prompt,
            json.dumps(
                {"feature": feature, "atoms": payload},
                ensure_ascii=False,
            ),
        )
        facts = _validate_extraction(result, {atom["atom_id"] for atom in batch})
        for category in FACT_CATEGORIES:
            extracted[category].extend(facts[category])

    referenced_ids = {
        atom_id
        for entries in extracted.values()
        for fact in entries
        for atom_id in fact["source_atoms"]
    }
    if not referenced_ids:
        raise ValueError(f"LLM found no traceable facts for feature {feature_id}; context was not written")
    analysis_input = {
        "feature": feature,
        "extracted_facts": extracted,
        "source_atoms": [
            {
                "atom_id": atom_id,
                "section_path": atoms_by_id[atom_id].get("section_path", []),
                "text_content": atoms_by_id[atom_id]["text_content"],
            }
            for atom_id in sorted(referenced_ids)
        ],
    }
    analysis_result = client.generate_json(
        _load_prompt("analyze_feature.j2"),
        json.dumps(analysis_input, ensure_ascii=False),
    )
    analysis = _validate_analysis(analysis_result, referenced_ids)

    root = config.SPECS_REPO_PATH
    expected_path = root / "02_extracted_context" / f"{feature_id}_context.yaml"
    if output_yaml_path.resolve() != expected_path.resolve():
        raise ValueError("Extraction output must be the canonical feature context path")
    if expected_path.exists():
        context = read_mapping(expected_path)
        if context.get("feature_id") != feature_id:
            raise ValueError(f"{expected_path}: feature_id does not match {feature_id}")
    else:
        context = {"feature_id": feature_id, "decision_items": []}
    context["extracted_facts"] = extracted
    context["analysis"] = analysis
    context["feature"] = feature

    documents = read_atoms(root / "00_traceability" / "atoms")
    contexts, rules = load_ledger(
        root / "02_extracted_context",
        root / "01_architecture" / "business_rules.yaml",
    )
    contexts[expected_path] = context
    reconcile_ledger(documents, contexts, rules)
    lifecycle_report(documents, contexts, rules)
    context = contexts[expected_path]
    publish_files({
        expected_path: yaml.safe_dump(context, allow_unicode=True, sort_keys=False),
    })
    with closing(get_db_connection()) as conn:
        sync_yaml_to_db(
            conn,
            feature_id,
            expected_path,
            root / "01_architecture" / "business_rules.yaml",
        )
    print(f"[EXTRACT] Extracted traceable facts for {feature_id} from {len(atoms)} atoms.")


def sync_yaml_to_db(conn: sqlite3.Connection, feature_id: str,
                    context_yaml: Path, rules_yaml: Path) -> None:
    """Rebuild the complete canonical snapshot, including deletions and other UCs."""
    root = config.SPECS_REPO_PATH
    expected_context = root / "02_extracted_context" / f"{feature_id}_context.yaml"
    expected_rules = root / "01_architecture" / "business_rules.yaml"
    if context_yaml.resolve() != expected_context.resolve() or rules_yaml.resolve() != expected_rules.resolve():
        raise ValueError("Synchronization paths must belong to the configured canonical repository")
    synchronize_canonical(conn)
