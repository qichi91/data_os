import yaml, jsonschema
from contextlib import closing
from src.config import config
from src.parsers.db import get_db_connection
from src.parsers.canonical import synchronize_canonical

def validate_all_layers(draft_data: dict) -> list[str]:
    errors = []

    schema_path = config.SPECS_REPO_PATH / ".schemas" / "usecase.schema.yaml"
    if not schema_path.exists():
        return ["スキーマファイルが存在しません。検証を中止します。"]
        
    with open(schema_path, "r", encoding="utf-8") as f:
        schema = yaml.safe_load(f)
    try:
        jsonschema.validate(instance=draft_data, schema=schema)
    except jsonschema.exceptions.ValidationError as e:
        return [f"スキーマ違反 (Layer 1): {e.json_path} - {e.message}"]

    basic_flow = draft_data.get("basic_flow", [])
    step_numbers = set()
    for s in basic_flow:
        step = s.get("step")
        if step in step_numbers:
            errors.append(f"フローエラー: ステップ番号 {step} が重複しています。")
        step_numbers.add(step)

    for alt in draft_data.get("alternative_flows", []):
        b_step = alt.get("branch_from_step")
        r_step = alt.get("resume_to_step")
        if b_step not in step_numbers:
            errors.append(f"フローエラー: 代替分岐元 step={b_step} が基本フローに存在しません。")
        if r_step is not None and r_step not in step_numbers:
            errors.append(f"フローエラー: 復帰先 step={r_step} が基本フローに存在しません。")

    model = draft_data.get("robustness_model", {})
    boundaries = {b["alias"] for b in model.get("boundaries", [])}
    entities = {e["alias"] for e in model.get("entities", [])}

    aliases = set()
    for cat in ["boundaries", "controls", "entities"]:
        for item in model.get(cat, []):
            alias = item.get("alias")
            if alias in aliases:
                errors.append(f"モデルエラー: 別名(alias) '{alias}' が重複しています。")
            aliases.add(alias)
    aliases.add("Actor")

    for rel in model.get("relations", []):
        f, t = rel.get("from"), rel.get("to")
        if f not in aliases: errors.append(f"モデルエラー: 未定義の接続元 '{f}' が指定されています。")
        if t not in aliases: errors.append(f"モデルエラー: 未定義の接続先 '{t}' が指定されています。")
        if (f in boundaries and t in entities) or (f in entities and t in boundaries):
            errors.append(f"ICONIX違反: Boundary({f})とEntity({t})の直結は禁止です。")

    all_refs = [s.get("source_atom_ref") for s in basic_flow] + [a.get("source_atom_ref") for a in draft_data.get("alternative_flows", [])]
    with closing(get_db_connection()) as conn:
        synchronize_canonical(conn)
        errors.extend(_validate_references(conn, all_refs))
    return errors


def _validate_references(conn, all_refs: list[str]) -> list[str]:
    errors = []
    for ref in all_refs:
        # 空文字やNoneを厳格にエラー化
        if ref is None or str(ref).strip() == "":
            errors.append("根拠エラー: 根拠IDが空文字または未指定の箇所があります。")
            continue

        if ref.startswith("ATOM_"):
            if not conn.execute("SELECT 1 FROM atoms WHERE atom_id = ?", (ref,)).fetchone():
                errors.append(f"根拠エラー: アトムID {ref} はデータベースに存在しません。")
        elif ref.startswith("RULE_"):
            rule = conn.execute("SELECT status FROM common_rules WHERE rule_id = ?", (ref,)).fetchone()
            if not rule: errors.append(f"根拠エラー: ルールID {ref} が存在しません。")
            elif rule["status"] != "ACTIVE": errors.append(f"根拠エラー: ルール {ref} は有効(ACTIVE)ではありません。")
        elif ref.startswith("DEC_"):
            dec = conn.execute("SELECT status FROM decision_items WHERE decision_id = ?", (ref,)).fetchone()
            if not dec: errors.append(f"根拠エラー: 決定ID {ref} が存在しません。")
            elif dec["status"] != "CONFIRMED": errors.append(f"根拠エラー: 決定 {ref} は確定済(CONFIRMED)ではありません。")
        else:
            errors.append(f"根拠エラー: 未知のID形式です ({ref})。")

    return errors
