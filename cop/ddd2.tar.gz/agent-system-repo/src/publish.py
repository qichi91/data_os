import re
import subprocess
from pathlib import Path
from urllib.parse import quote

import httpx

from src.config import config


class PublishError(RuntimeError):
    pass


def _git(repo: Path, *args: str, check: bool = True) -> subprocess.CompletedProcess:
    result = subprocess.run(
        ["git", "-C", str(repo), *args],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
    )
    if check and result.returncode:
        detail = result.stderr.strip() or result.stdout.strip()
        raise PublishError(f"git {' '.join(args[:2])} failed: {detail}")
    return result


def _api_config() -> tuple[str, str, str, str]:
    values = {
        "GITEA_API_URL": config.GITEA_API_URL.strip().rstrip("/"),
        "GITEA_API_TOKEN": config.GITEA_API_TOKEN.strip(),
        "GITEA_REPO_OWNER": config.GITEA_REPO_OWNER.strip(),
        "GITEA_REPO_NAME": config.GITEA_REPO_NAME.strip(),
    }
    missing = [key for key, value in values.items() if not value]
    if missing:
        raise PublishError(f"Publishing configuration missing: {', '.join(missing)}")
    if not values["GITEA_API_URL"].startswith(("http://", "https://")):
        raise PublishError("GITEA_API_URL must use http:// or https://")
    return (
        values["GITEA_API_URL"],
        values["GITEA_API_TOKEN"],
        values["GITEA_REPO_OWNER"],
        values["GITEA_REPO_NAME"],
    )


def _resolve_repo(specs_repo: Path) -> Path:
    result = _git(specs_repo, "rev-parse", "--show-toplevel")
    return Path(result.stdout.strip()).resolve()


def _selected_paths(repo: Path, paths: list[str]) -> list[str]:
    if not paths:
        raise PublishError("Specify at least one path to publish")
    selected = []
    for raw_path in paths:
        path = Path(raw_path)
        if path.is_absolute():
            resolved = path.resolve()
        else:
            resolved = (repo / path).resolve()
        try:
            relative = resolved.relative_to(repo)
        except ValueError as exc:
            raise PublishError(f"Path is outside specs repository: {raw_path}") from exc
        if any(part.casefold() == ".git" for part in relative.parts) or (
            relative.name.casefold().startswith(".env.")
            and relative.name.casefold() != ".env.example"
        ) or relative.name.casefold() == ".env":
            raise PublishError(f"Refusing to publish repository metadata or secrets: {raw_path}")
        if not resolved.is_file():
            raise PublishError(f"Publish path does not exist or is not a file: {raw_path}")
        git_path = relative.as_posix()
        if git_path not in selected:
            selected.append(git_path)
    return selected


def _create_or_get_pull_request(
    api_url: str,
    token: str,
    owner: str,
    repository: str,
    branch: str,
    base: str,
    issue_index: int,
) -> tuple[dict, bool]:
    repo_path = f"{quote(owner, safe='')}/{quote(repository, safe='')}"
    headers = {"Authorization": f"token {token}", "Accept": "application/json"}
    params = {"state": "all", "head": f"{owner}:{branch}", "base": base}
    try:
        with httpx.Client(base_url=api_url, headers=headers, timeout=30.0) as client:
            response = client.get(f"/api/v1/repos/{repo_path}/pulls", params=params)
            response.raise_for_status()
            existing = response.json()
            if not isinstance(existing, list):
                raise PublishError("Gitea PR list response must be a JSON array")
            for pull_request in existing:
                if not isinstance(pull_request, dict):
                    raise PublishError("Gitea PR list contains an invalid entry")
                head = pull_request.get("head")
                if isinstance(head, dict) and head.get("ref") == branch:
                    if not pull_request.get("html_url"):
                        raise PublishError("Existing Gitea PR response is missing html_url")
                    return pull_request, False
            response = client.post(
                f"/api/v1/repos/{repo_path}/pulls",
                json={
                    "title": f"仕様ドラフト: Issue #{issue_index}",
                    "head": branch,
                    "base": base,
                    "body": (
                        f"Issue #{issue_index} に基づく仕様ドラフトです。\n\n"
                        "生成されたYAML・根拠・未確定事項をレビューしてください。\n\n"
                        f"Refs #{issue_index}"
                    ),
                },
            )
            response.raise_for_status()
            pull_request = response.json()
            if not isinstance(pull_request, dict) or not pull_request.get("html_url"):
                raise PublishError("Gitea PR creation response is missing html_url")
            return pull_request, True
    except httpx.HTTPStatusError as exc:
        raise PublishError(
            f"Gitea API returned HTTP {exc.response.status_code} for {exc.request.method} {exc.request.url.path}"
        ) from exc
    except httpx.RequestError as exc:
        raise PublishError(f"Unable to reach Gitea API: {exc}") from exc
    except ValueError as exc:
        if isinstance(exc, PublishError):
            raise
        raise PublishError("Gitea API returned invalid JSON") from exc


def publish_changes(issue_index: int, paths: list[str], specs_repo: Path | None = None) -> dict:
    if issue_index < 1:
        raise PublishError("Issue index must be a positive integer")
    if not re.fullmatch(r"[A-Za-z0-9._-]+", config.GIT_BASE_BRANCH):
        raise PublishError("GIT_BASE_BRANCH contains unsupported characters")
    if not re.fullmatch(r"[A-Za-z0-9._-]+", config.GIT_REMOTE_NAME):
        raise PublishError("GIT_REMOTE_NAME contains unsupported characters")

    api_url, token, owner, repository = _api_config()
    repo = _resolve_repo((specs_repo or config.SPECS_REPO_PATH).resolve())
    selected = _selected_paths(repo, paths)
    if _git(repo, "diff", "--cached", "--name-only").stdout.strip():
        raise PublishError("Staged changes already exist; unstage or commit them before publishing")

    remote = config.GIT_REMOTE_NAME
    remotes = _git(repo, "remote").stdout.splitlines()
    if remote not in remotes:
        raise PublishError(f"Git remote {remote!r} is not configured in {repo}")
    branch = f"agent/issue-{issue_index}"
    current_branch = _git(repo, "branch", "--show-current").stdout.strip()
    changed = _git(repo, "status", "--porcelain", "--untracked-files=all", "--", *selected).stdout.strip()
    if not changed and current_branch != branch:
        raise PublishError("None of the selected paths has changes to publish")
    if not changed:
        head = _git(repo, "rev-parse", "HEAD").stdout.strip()
        base_ref = _git(repo, "rev-parse", config.GIT_BASE_BRANCH).stdout.strip()
        if head == base_ref:
            raise PublishError("No changes to publish")
    if current_branch != branch:
        branch_exists = _git(repo, "show-ref", "--verify", "--quiet", f"refs/heads/{branch}", check=False)
        if branch_exists.returncode == 0:
            raise PublishError(
                f"Branch {branch} already exists; switch to it and retry only if it is this issue's publish branch"
            )
        _git(repo, "switch", "-c", branch)

    if changed:
        _git(repo, "add", "--", *selected)
        _git(
            repo,
            "-c", f"user.name={config.GIT_AUTHOR_NAME}",
            "-c", f"user.email={config.GIT_AUTHOR_EMAIL}",
            "commit",
            "--only",
            "-m", f"docs(spec): draft from issue #{issue_index}",
            "--",
            *selected,
        )

    _git(repo, "push", "-u", remote, branch)
    pull_request, created = _create_or_get_pull_request(
        api_url,
        token,
        owner,
        repository,
        branch,
        config.GIT_BASE_BRANCH,
        issue_index,
    )
    return {
        "branch": branch,
        "commit": _git(repo, "rev-parse", "HEAD").stdout.strip(),
        "pull_request_url": pull_request.get("html_url", ""),
        "created": created,
    }
