import json
import re
from typing import Any

import httpx

from src.config import config


class LocalLLMClient:
    def __init__(self) -> None:
        if not config.LLM_MODEL_NAME:
            raise ValueError("LLM_MODEL_NAME must be configured")
        if config.LLM_ATOMS_PER_REQUEST < 1:
            raise ValueError("LLM_ATOMS_PER_REQUEST must be positive")

    def generate_json(self, system_prompt: str, user_prompt: str) -> dict[str, Any]:
        headers = {"Content-Type": "application/json"}
        if config.LLM_API_KEY:
            headers["Authorization"] = f"Bearer {config.LLM_API_KEY}"
        response = httpx.post(
            f"{config.LLM_API_BASE_URL.rstrip('/')}/chat/completions",
            headers=headers,
            json={
                "model": config.LLM_MODEL_NAME,
                "temperature": config.LLM_TEMPERATURE,
                "max_tokens": config.LLM_MAX_TOKENS,
                "response_format": {"type": "json_object"},
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
            },
            timeout=config.LLM_TIMEOUT_SECONDS,
        )
        response.raise_for_status()
        try:
            content = response.json()["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise ValueError("LLM response does not contain a chat completion message") from exc
        if not isinstance(content, str):
            raise ValueError("LLM response content must be text")
        content = re.sub(r"\A\s*```(?:json)?\s*|\s*```\s*\Z", "", content, flags=re.IGNORECASE)
        try:
            result = json.loads(content)
        except json.JSONDecodeError as exc:
            raise ValueError(f"LLM returned invalid JSON: {exc}") from exc
        if not isinstance(result, dict):
            raise ValueError("LLM JSON response must be an object")
        return result
