from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict


class AppConfig(BaseSettings):
    SPECS_REPO_PATH: Path = Path("../specs-repo")
    CACHE_DB_PATH: Path = Path(".cache/spec_store.sqlite")
    LLM_API_BASE_URL: str = "http://localhost:30000/v1"
    LLM_MODEL_NAME: str = ""
    LLM_API_KEY: str = ""
    LLM_TEMPERATURE: float = 0.1
    LLM_MAX_TOKENS: int = 4096
    LLM_TIMEOUT_SECONDS: float = 120.0
    LLM_ATOMS_PER_REQUEST: int = 20
    GITEA_API_URL: str = ""
    GITEA_API_TOKEN: str = ""
    GITEA_REPO_OWNER: str = ""
    GITEA_REPO_NAME: str = ""
    GIT_REMOTE_NAME: str = "origin"
    GIT_BASE_BRANCH: str = "main"
    GIT_AUTHOR_NAME: str = "Specification Agent"
    GIT_AUTHOR_EMAIL: str = "spec-agent@localhost"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


config = AppConfig()
