# agent-system-repo

旧Word仕様から仕様書のたたき台を作る基盤です。原文取込、根拠に紐づくローカルLLM抽出、ユースケース起草、構造・根拠検証、Markdown生成を行います。人の確定判断はLLMで生成・上書きしません。Issue起点の自動処理は対象外ですが、ブランチpush・Gitea PR発行を行う独立CLIを提供します。

## 正本とキャッシュ

- 正本は `specs-repo/00_traceability/atoms/*.jsonl`、`02_extracted_context/*_context.yaml`、`01_architecture/business_rules.yaml` です。
- SQLiteはキャッシュです。検証時に全正本を読み直し、削除も含めてトランザクション内で置換します。他機能の判断も読み込むため、キャッシュ再構築前後で合否が変わりません。
- Wordの取込先は入力ディレクトリ全体のスナップショットです。取込時は全対象文書を配置してください。文書や記述の削除はJSONLの `active: false` として保持します。
- 既存のJSONLも必ず引き継いでください。初回取込では不要ですが、更新時に失うとID対応を復元できません。

## 原文IDと変更検知

本文・表を文書順に取得し、見出しパス、要素種別、所在、文書版、内容ハッシュを保持します。IDは内容ハッシュとは別のUUIDです。

同じ文書・見出しパス・要素種別の中で一意に一致する記述だけが旧IDを継承します。変更のない文書は重複記述のIDも維持します。変更された文書に同文や同じ見出しが重複する場合は、対応を推測せず新規IDにします。本文変更・章移動・文書名変更も自動継承を保証しません。旧記述は履歴として残り、関連判断を再確認へ戻します。

Word標準のHeading 1～9を章節として扱います。独自見出し、入れ子表、ヘッダー・フッター等の全形式対応は対象外です。本文段落内の画像・図形は所在付きの未抽出記録として保持します。数の集計は抽出内容の意味的な完全性を保証しません。

## 判断・共通ルールの再確認

判断は `PENDING`、`CONFIRMED`、`NEEDS_RECONFIRM`、`IGNORED`、ルールは `ACTIVE`、`NEEDS_RECONFIRM`、`INACTIVE`、`DEPRECATED`、`PENDING` を使用します。

確定する際は、確認した原文IDとその時点のハッシュを記録します。

```yaml
decision_items:
  - decision_id: DEC_credit
    source_atom_id: ATOM_example
    source_hashes:
      ATOM_example: "<JSONLのcontent_hash>"
    status: CONFIRMED
    human_decision_text: "採用する業務動作と判断理由"
```

複数根拠は `source_atom_ids` と `source_hashes` に列挙できます。ルールにも同じ根拠形式を使います。人の決定を根拠にするルールは `source_decision_ids` と `decision_hashes` を持ち、ハッシュは `src.parsers.canonical.decision_hash` で取得します。

原文の変更・削除・曖昧な対応、確認ハッシュの未記録で、関連する確定判断・有効ルールは `NEEDS_RECONFIRM` になります。人の判断本文や採用ルール本文を旧仕様で上書きしません。旧形式に確認ハッシュがない場合も、安全側で再確認にします。

再確認後は、現在の根拠ID・ハッシュと判断内容を確認して `CONFIRMED`／`ACTIVE` へ戻してください。状態だけ戻しても根拠不一致が残れば、再び再確認になります。

`00_traceability/lifecycle_report.yaml` に未解決事項と影響UCを再生成します。Markdownには関連判断の `PENDING`／`NEEDS_RECONFIRM` を機械的に追加表示します。UC正本へ判断本文を複製しません。

## コマンド

基盤ディレクトリで実行します。

```powershell
python -m pip install -r requirements.txt
python main.py ingest --input-dir ..\specs-repo\inputs\raw_docs
python main.py extract --feature-id F_ORD_001
python main.py generate --feature-id F_ORD_001 --module MOD01_Order
python main.py verify --yaml-file ..\specs-repo\03_usecases\MOD01_Order\UC_F_ORD_001.yaml
python main.py publish --issue-index 42 --path 03_usecases/MOD01_Order/UC_F_ORD_001.yaml --path 03_usecases/MOD01_Order/UC_F_ORD_001.md
python -m unittest discover -s tests -v
```

`extract` はアクティブな原文アトムを `LLM_ATOMS_PER_REQUEST` 件ずつローカルLLMへ渡し、出典ID付きの事実を抽出します。続けて事実間の矛盾・曖昧さ・不足を分析し、`02_extracted_context/<feature_id>_context.yaml` に保存します。既存の `decision_items` は保持されます。LLMの出力が不正、または入力にない根拠IDを参照する場合は失敗し、候補を正本として公開しません。

`generate` は抽出済みコンテキストと分析、根拠アトム、用語集、共通ルール、モジュール境界、ユースケーススキーマをLLMに渡してYAML候補を起草します。候補はスキーマ・構造・根拠の検証を通過してから正本へ保存されます。既存YAMLは `--force` を指定しない限り上書きしません。生成物は必ず人がレビューし、曖昧な業務判断を確定してください。

LLMはOpenAI互換のローカル推論サーバーを使います。`.env.example` を `.env` にコピーし、`LLM_API_BASE_URL` と `LLM_MODEL_NAME` を設定してください。Compose実行時の既定URLは `http://host.docker.internal:30000/v1` です。ホストから直接CLIを実行する場合は、同じホスト上の推論サーバーに対してURLを `http://localhost:30000/v1` に変更してください。推論サーバーは閉域網内で到達可能にし、外部APIへ接続しない構成にしてください。

`publish` はIssue kickや監視を行わず、呼び出し側からIssue番号と `specs-repo` ルートからの相対パスを1ファイルずつ `--path` で受け取ります。Gitea PR APIの接続先・PAT・owner・repositoryは `.env` の `GITEA_API_URL`、`GITEA_API_TOKEN`、`GITEA_REPO_OWNER`、`GITEA_REPO_NAME` で設定します。Git pushは `GIT_REMOTE_NAME` のremoteを使用するため、実行環境にSSH鍵とknown_hostsを事前設定してください。PATはリポジトリへ登録しないでください。

このコマンドは未コミットの変更があることを許しますが、**既にステージされた変更がある場合は停止**します。選択した `--path` のみをコミットし、それ以外の未コミット変更は残します。ブランチは `agent/issue-<番号>` です。push後にAPI処理が失敗した場合、ブランチを維持するので原因を直して同じIssue・同じパスで再実行できます。既存PRがあれば再利用します。PR作成時点の差分が空になる再試行や、別ブランチへの変更持ち込みは自動解決せず、エラーとして人が確認してください。

実行例:

```powershell
python main.py publish --issue-index 42 --path 00_traceability/atoms/legacy.jsonl --path 03_usecases/MOD01_Order/UC_F_ORD_001.yaml --path 03_usecases/MOD01_Order/UC_F_ORD_001.md
```

取込・同期は全入力を検証してから候補ファイルを公開し、失敗した入力で稼働中キャッシュを先に削除しません。複数プロセスの同時更新やプロセス強制終了をまたぐ原子的な複数ファイル更新は保証しません。正本更新と取込・検証は直列に実行してください。

## 受入テスト

テストは一時ディレクトリと隔離SQLiteのみを使用します。

1. ルール削除後の検証結果が、キャッシュ再構築前後で一致する。
2. 原文の変更・削除で関連判断とルールが再確認になり、人の記述が残る。
3. 同文を別章へ追加・削除しても、判断が別の所在へ移らない。
