import argparse, sys, yaml
from pathlib import Path
from jinja2 import Environment, FileSystemLoader
from src.config import config
from src.validators.semantic_validator import validate_all_layers
from src.parsers.atomizer import ingest_directory
from src.parsers.drafter import generate_usecase
from src.parsers.extractor import extract_and_build_context
from src.parsers.canonical import read_mapping
from src.publish import PublishError, publish_changes

def render_markdown(yaml_path: Path):
    with open(yaml_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    report_path = config.SPECS_REPO_PATH / "00_traceability" / "lifecycle_report.yaml"
    if report_path.exists():
        report = read_mapping(report_path)
        issues = list(data.get("unconfirmed_issues", []))
        existing_ids = {issue["issue_id"] for issue in issues}
        references = {
            step.get("source_atom_ref")
            for key in ("basic_flow", "alternative_flows") for step in data.get(key, [])
        }
        for item in report["unconfirmed_items"]:
            if item.get("feature_id") == data.get("feature_id") or item["id"] in references:
                if item["id"] not in existing_ids:
                    issues.append({
                        "issue_id": item["id"], "title": item["status"],
                        "description": item.get("description") or item.get("reason", ""),
                        "impact": item.get("reason", ""),
                    })
                    existing_ids.add(item["id"])
        data["unconfirmed_issues"] = issues
    env = Environment(loader=FileSystemLoader(str(config.SPECS_REPO_PATH / "templates")), trim_blocks=True)
    md_content = env.get_template("usecase.md.j2").render(**data)
    with open(yaml_path.with_suffix(".md"), "w", encoding="utf-8") as f:
        f.write(md_content)
    print(f"   [RENDER] Generated Markdown: {yaml_path.with_suffix('.md').name}")

def run_pipeline(target_yaml: Path):
    print(f"=== Pipeline: {target_yaml.name} ===")
    if not target_yaml.exists():
        print(f"[FAIL] {target_yaml} が見つかりません。")
        sys.exit(1)

    with open(target_yaml, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}

    errors = validate_all_layers(data)
    if errors:
        print(f"[FAIL] 検証エラーが {len(errors)} 件検出されました:")
        for e in errors: print(f"  - {e}")
        print("=== Pipeline Aborted ===")
        sys.exit(1)
        
    print("[PASS] スキーマ、構造的意味、根拠の有効性検証をパスしました。")
    render_markdown(target_yaml)
    print("=== Pipeline Completed Successfully ===")

def cmd_generate(args):
    yaml_path = generate_usecase(
        args.feature_id,
        args.module,
        Path(args.output) if args.output else None,
        args.force,
    )
    run_pipeline(yaml_path)

def cmd_verify(args):
    run_pipeline(Path(args.yaml_file))


def cmd_publish(args):
    try:
        result = publish_changes(args.issue_index, args.paths)
    except PublishError as exc:
        print(f"[PUBLISH FAILED] {exc}", file=sys.stderr)
        sys.exit(1)
    action = "Created" if result["created"] else "Reused existing"
    print(f"[PUBLISH] Branch: {result['branch']}")
    print(f"[PUBLISH] Pull request: {result['pull_request_url']} ({action})")


def main():
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)
    
    p_ingest = subparsers.add_parser("ingest")
    p_ingest.add_argument("--input-dir", required=True)
    
    p_extract = subparsers.add_parser("extract")
    p_extract.add_argument("--feature-id", required=True)
    
    p_generate = subparsers.add_parser("generate")
    p_generate.add_argument("--feature-id", required=True)
    p_generate.add_argument("--module", required=True, help="specs-repo module directory, e.g. MOD01_Order")
    p_generate.add_argument("--output", help="optional YAML output path inside the selected module directory")
    p_generate.add_argument("--force", action="store_true", help="replace an existing use case YAML")
    
    p_verify = subparsers.add_parser("verify")
    p_verify.add_argument("--yaml-file", required=True)

    p_publish = subparsers.add_parser(
        "publish",
        help="commit explicitly selected specs-repo changes, push a branch, and open a Gitea PR",
    )
    p_publish.add_argument("--issue-index", type=int, required=True)
    p_publish.add_argument(
        "--path",
        dest="paths",
        action="append",
        required=True,
        help="path relative to specs-repo; repeat for each file to publish",
    )
    
    args = parser.parse_args()
    if args.command == "ingest":
        ingest_directory(Path(args.input_dir), config.SPECS_REPO_PATH / "00_traceability" / "atoms")
    elif args.command == "extract":
        extract_and_build_context(args.feature_id, config.SPECS_REPO_PATH / "02_extracted_context" / f"{args.feature_id}_context.yaml")
    elif args.command == "generate":
        cmd_generate(args)
    elif args.command == "verify":
        cmd_verify(args)
    elif args.command == "publish":
        cmd_publish(args)

if __name__ == "__main__":
    main()
