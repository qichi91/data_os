from __future__ import annotations

import shutil
import tempfile
import unittest
from pathlib import Path

from specforge.pipeline import SpecError, build_project, validate_project


PROJECT_ROOT = Path(__file__).resolve().parents[1]


class PipelineTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary_directory.name) / "project"
        shutil.copytree(
            PROJECT_ROOT,
            self.root,
            ignore=shutil.ignore_patterns(
                ".venv", "build", "__pycache__", ".git", "*.pyc"
            ),
        )

    def tearDown(self) -> None:
        self.temporary_directory.cleanup()

    def test_build_follows_layout_and_resolves_aliases(self) -> None:
        outputs = build_project(self.root)

        self.assertEqual(len(outputs), 1)
        document = outputs[0].read_text(encoding="utf-8")
        self.assertIn("### プロセス入出力一覧: UC-001", document)
        self.assertIn("IF-001", document)
        self.assertIn("DB-001", document)
        self.assertIn("この機能では受注対象となる購入依頼を指す。", document)
        self.assertNotIn("顧客から受け付けた商品購入の依頼。", document)
        self.assertLess(document.index("## DBレコード定義"), document.index("## ユビキタス言語集"))
        self.assertLess(document.index("## ユビキタス言語集"), document.index("## ユースケース図"))

    def test_validation_rejects_unknown_alias(self) -> None:
        io_path = self.root / "02_features/受注登録/注文管理/受注処理/UC-001/io_list.yaml"
        content = io_path.read_text(encoding="utf-8").replace(
            "MSG_ORDER_REQ", "MSG_NOT_REGISTERED"
        )
        io_path.write_text(content, encoding="utf-8")

        with self.assertRaisesRegex(SpecError, "未登録のIDエイリアス"):
            validate_project(self.root)

    def test_validation_rejects_use_case_id_mismatch(self) -> None:
        spec_path = self.root / "02_features/受注登録/注文管理/受注処理/UC-001/uc_spec.yaml"
        content = spec_path.read_text(encoding="utf-8").replace(
            'use_case_id: "UC-001"', 'use_case_id: "UC-999"'
        )
        spec_path.write_text(content, encoding="utf-8")

        with self.assertRaisesRegex(SpecError, "use_case_idがfeatures.tsvと一致しません"):
            validate_project(self.root)

    def test_validation_rejects_invalid_yaml_shape(self) -> None:
        spec_path = self.root / "02_features/受注登録/注文管理/受注処理/UC-001/uc_spec.yaml"
        content = spec_path.read_text(encoding="utf-8").replace(
            'actors:\n  - "顧客"', 'actors: "顧客"'
        )
        spec_path.write_text(content, encoding="utf-8")

        with self.assertRaisesRegex(SpecError, "スキーマ違反"):
            validate_project(self.root)

    def test_validation_requires_explicit_vocabulary_override(self) -> None:
        vocabulary_path = self.root / "02_features/受注登録/vocabulary.yaml"
        content = vocabulary_path.read_text(encoding="utf-8").replace(
            "    allow_override: true\n", ""
        )
        vocabulary_path.write_text(content, encoding="utf-8")

        with self.assertRaisesRegex(SpecError, "allow_override: true"):
            validate_project(self.root)

    def test_validation_rejects_unregistered_feature_directory(self) -> None:
        (self.root / "02_features/未登録機能").mkdir()

        with self.assertRaisesRegex(SpecError, "未登録の機能ディレクトリ"):
            validate_project(self.root)

    def test_validation_rejects_markdown_outside_plantuml_block(self) -> None:
        diagram_path = self.root / "02_features/受注登録/uc_diagram.md"
        diagram_path.write_text(
            "# 見出し\n```plantuml\n@startuml\n@enduml\n```\n",
            encoding="utf-8",
        )

        with self.assertRaisesRegex(SpecError, "PlantUMLコードブロック以外"):
            validate_project(self.root)


if __name__ == "__main__":
    unittest.main()
