import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import yaml

from config.watch import (
    adjust_markdown_content,
    build_markdown_for_feature,
    generate_markdown_toc,
)


class MarkdownHeadingTests(unittest.TestCase):
    def test_heading_numbers_reset_below_the_current_level(self):
        self.assertEqual(
            adjust_markdown_content(
                "# 概要\n本文\n## 詳細A\n## 詳細B\n# 補足\n## 詳細C\n", 2, "1"
            ),
            "### 1.1. 概要\n本文\n#### 1.1.1. 詳細A\n"
            "#### 1.1.2. 詳細B\n### 1.2. 補足\n#### 1.2.1. 詳細C\n",
        )


class MarkdownTocTests(unittest.TestCase):
    def test_toc_preserves_hierarchy_and_disambiguates_links(self):
        self.assertEqual(
            generate_markdown_toc([
                "## 1. 概要", "### 詳細 ###", "## 詳細", "## 詳細-1", "## 詳細",
            ]),
            "- [1. 概要](#1-概要)\n"
            "  - [詳細](#詳細)\n"
            "- [詳細](#詳細-1)\n"
            "- [詳細-1](#詳細-1-1)\n"
            "- [詳細](#詳細-2)",
        )

    def test_depth_filters_headings_without_changing_duplicate_anchors(self):
        self.assertEqual(
            generate_markdown_toc(["## 概要", "### 概要", "## 概要"], depth=2),
            "- [概要](#概要)\n- [概要](#概要-2)",
        )
        self.assertEqual(generate_markdown_toc(["### 詳細"], depth=2), "")
        self.assertEqual(generate_markdown_toc([]), "")
        with self.assertRaises(ValueError):
            generate_markdown_toc(["# 概要"], depth=0)


class WatchBuildTests(unittest.TestCase):
    def test_toc_is_generated_after_all_markdown_is_rendered(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            config = root / "config"
            config.mkdir()
            feature = root / "02_features" / "sample"
            process = feature / "blocks" / "block" / "process"
            process.mkdir(parents=True)
            (feature / "feature.yaml").write_text("{}\n", encoding="utf-8")
            (config / "global_layout.yaml").write_text(
                yaml.safe_dump({"chapters": [
                    {"title": "概要", "type": "dynamic_scan"},
                    {"title": "制限事項", "type": "static_include"},
                ]}),
                encoding="utf-8",
            )
            (process / "a.md").write_text("# 最初\n", encoding="utf-8")
            (process / "z.md").write_text(
                "# 最後\n```text\n# サンプルコード\n```\n"
                "~~~~\n# 別のコード\n~~~~\n",
                encoding="utf-8",
            )
            direct_block = feature / "blocks" / "direct"
            direct_block.mkdir()
            (direct_block / "b.md").write_text("# 別ブロック\n", encoding="utf-8")
            (feature / "blocks" / "empty").mkdir()
            templates = [
                Path(__file__).resolve().parents[1].joinpath(
                    "config/template.j2"
                ).read_text(encoding="utf-8"),
            ]
            templates.append(templates[0].replace("{{ toc }}", "[TOC]"))
            templates.append(templates[0].replace("{{ toc }}", "目次なし"))
            with patch("config.watch.FEATURES_DIR", root / "02_features"):
                for template in templates:
                    with self.subTest(template=template):
                        (config / "template.j2").write_text(template, encoding="utf-8")
                        build_markdown_for_feature("sample")
                        document = (root / "03_output" / "sample.md").read_text(
                            encoding="utf-8"
                        )
                        self.assertNotIn("[TOC]", document)
                        if "目次なし" in template:
                            self.assertNotIn("- [", document)
                        else:
                            first = "- [1.1.1.1.1. 最初](#11111-最初)"
                            last = "- [1.1.1.2.1. 最後](#11121-最後)"
                            self.assertIn(first, document)
                            self.assertIn(last, document)
                            self.assertLess(document.index(first), document.index(last))
                            self.assertLess(
                                document.index(last),
                                document.index("###### 1.1.1.1.1. 最初"),
                            )
                            self.assertNotIn("サンプルコード](", document)
                            self.assertNotIn("別のコード](", document)
                            self.assertIn(
                                "- [1.2.1.1.1. 別ブロック](#12111-別ブロック)", document
                            )

                (config / "template.j2").unlink()
                build_markdown_for_feature("sample")
                document = (root / "03_output" / "sample.md").read_text(
                    encoding="utf-8"
                )
                self.assertTrue(document.startswith("## 1. 概要\n"))
                self.assertNotIn("- [", document)
                self.assertEqual(
                    document,
                    "## 1. 概要\n\n### 1.1. block\n\n#### 1.1.1. process\n\n"
                    "##### 1.1.1.1. a\n\n###### 1.1.1.1.1. 最初\n\n"
                    "##### 1.1.1.2. z\n\n###### 1.1.1.2.1. 最後\n```text\n"
                    "###### 1.1.1.2.2. サンプルコード\n```\n"
                    "~~~~\n###### 1.1.1.2.3. 別のコード\n~~~~\n\n"
                    "### 1.2. direct\n\n#### 1.2.1. direct\n\n"
                    "##### 1.2.1.1. b\n\n###### 1.2.1.1.1. 別ブロック\n\n"
                    "## 2. 制限事項\n",
                )


class LayoutBuildTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.config = self.root / "config"
        self.config.mkdir()
        self.feature = self.root / "02_features" / "sample"
        self.feature.mkdir(parents=True)
        (self.feature / "feature.yaml").write_text("{}\n", encoding="utf-8")
        self.output = self.root / "03_output" / "sample.md"
        patcher = patch("config.watch.FEATURES_DIR", self.root / "02_features")
        patcher.start()
        self.addCleanup(patcher.stop)

    def write_layout(self, chapters):
        (self.config / "global_layout.yaml").write_text(
            yaml.safe_dump({"chapters": chapters}), encoding="utf-8"
        )

    def test_layout_controls_scan_directory_file_order_and_headings(self):
        self.write_layout([
            {
                "title": "図一覧", "type": "dynamic_scan",
                "scan_target_dir": "diagrams", "path": "unused",
                "expected_files": [
                    {"filename": "sequence.md", "heading": "シーケンス図", "required": True},
                    {"filename": "optional.md", "heading": "省略する図"},
                    {"filename": "overview.md", "heading": "処理概要", "required": True},
                ],
            },
            {"title": "制限事項", "type": "static_include", "content": "制限の本文"},
        ])
        for process in ("process-b", "process-a"):
            for use_case in ("UC-002", "UC-001"):
                directory = self.feature / "diagrams" / "block" / process / use_case
                directory.mkdir(parents=True)
                for filename in ("overview.md", "sequence.md", "unlisted.md"):
                    (directory / filename).write_text(
                        f"body {process} {use_case} {filename}\n", encoding="utf-8"
                    )

        for with_template in (False, True):
            with self.subTest(with_template=with_template):
                if with_template:
                    template = Path(__file__).resolve().parents[1] / "config/template.j2"
                    (self.config / "template.j2").write_text(
                        template.read_text(encoding="utf-8"), encoding="utf-8"
                    )
                build_markdown_for_feature("sample")
                document = self.output.read_text(encoding="utf-8")
                positions = [
                    document.index(f"body {process} {use_case} {filename}")
                    for process in ("process-a", "process-b")
                    for filename in ("sequence.md", "overview.md")
                    for use_case in ("UC-001", "UC-002")
                ]
                self.assertEqual(positions, sorted(positions))
                self.assertNotIn("unlisted.md", document)
                self.assertNotIn("省略する図", document)
                self.assertIn("##### 1.1.1.1. シーケンス図", document)
                self.assertIn("##### 1.1.1.3. 処理概要", document)
                self.assertLess(document.index("## 1. 図一覧"), document.index("## 2. 制限事項"))
                if with_template:
                    self.assertLess(
                        document.index("- [1.1.1.1. シーケンス図]"),
                        document.index("- [1.1.1.3. 処理概要]"),
                    )

    def test_only_required_true_stops_build_when_file_is_missing(self):
        process = self.feature / "blocks" / "block" / "process"
        process.mkdir(parents=True)
        (process / "overview.md").write_text("存在する本文\n", encoding="utf-8")
        for required in (None, False, "true", True):
            with self.subTest(required=required):
                missing = {"filename": "missing.md"}
                if required is not None:
                    missing["required"] = required
                self.write_layout([{
                    "title": "概要", "type": "dynamic_scan",
                    "expected_files": [missing, {"filename": "overview.md"}],
                }])
                with patch("builtins.print") as print_mock:
                    if required is True:
                        previous = self.output.read_text(encoding="utf-8")
                        with self.assertRaisesRegex(FileNotFoundError, "missing.md"):
                            build_markdown_for_feature("sample")
                        self.assertEqual(self.output.read_text(encoding="utf-8"), previous)
                        print_mock.assert_not_called()
                    else:
                        build_markdown_for_feature("sample")
                        document = self.output.read_text(encoding="utf-8")
                        self.assertIn("##### 1.1.1.1. overview", document)
                        self.assertNotIn("missing", document)
                        print_mock.assert_called_once_with(f"仕様書を出力しました: {self.output}")


if __name__ == "__main__":
    unittest.main()
