# システム要件定義書：ICONIX仕様書自動生成・GitOps連携基盤

## 1. システム概要および目的

本システムは、ICONIXプロセスに基づくシステム仕様の策定において、複数名の執筆者が競合や手戻りを起こさずに要件定義・設計情報を記述・レビューするための自動化基盤である。
データの正本（Single Source of Truth）をYAMLファイルとして構造化し、レイアウト定義と分離することで、見出し階層や出力順序の変更に柔軟に対応する。また、Git（Gitea）を用いたPRレビューと連携し、仕様の変更履歴管理およびCIによる静的検証（Linter）を自動化する。

---

## 2. システムアーキテクチャ・技術要件

* **執筆環境**: VSCode（標準のYAML拡張機能を利用）
* **データ構造化**: YAML（文章・表データ）、Markdown（PlantUML図表）
* **静的検証（ローカル）**: JSON Schema（YAML検証用）
* **変換・結合処理**: Python（`watchdog` によるファイル監視、`Jinja2` によるMarkdownレンダリング）
* **バージョン管理・CI/CD**: Git、Gitea、Gitea Actions

---

## 3. ディレクトリ・ファイル構成要件

### 3.1 階層構造とスコープ分離

システムは「プログラム ＞ サービス ＞ 機能（約45個）＞ 機能ブロック ＞ 処理 ＞ ユースケース」の6階層で管理される。最終的な仕様書は「機能」単位で1つのMarkdownファイルとして出力される。
人間による視認性と機械的な整合性を両立するため、上位ディレクトリは日本語名とし、末端のユースケースのみIDフォルダとする。

* **プロジェクト共通階層 (`01_common/`)**:
* 全体共通のユビキタス言語集、DBレコード表、メッセージ構造テーブルを配置する。


* **機能階層 (`02_features/{機能名}/`)**:
* 機能単位のユビキタス言語集、ユースケース図を配置する。


* **機能ブロック階層 (`.../{機能名}/{機能ブロック名}/`)**:
* ドメインモデル図を配置する。


* **ユースケース階層 (`.../{処理名}/{UC_ID}/`)**:
* ユースケース記述、プロセス入出力一覧テーブル、ロバストネス図、シーケンス図を配置する。



### 3.2 構成管理マスター（features.tsv）

フォルダパスと正式な機能ID・ユースケースIDの紐付け、および結合順序の制御は `features.tsv` にて一元管理する。Python変換スクリプトは本ファイルを正とし、実在するディレクトリパスとの整合性を検証する。

---

## 4. 対象成果物と記述形式要件

ICONIX分析の対象となる9つの成果物を、データ特性に応じてYAMLとMarkdown（PlantUML）に分けて管理する。

### 4.1 YAML形式で記述する項目（JSON Schema検証対象）

VSCode上でリアルタイムに型チェックや必須入力チェックを行う。

1. **ユースケース記述** (`uc_spec.yaml`): アクター、事前条件、基本コース、代替コース
2. **プロセス入出力一覧テーブル** (`io_list.yaml`): 方向、対象、データ参照キー
3. **DBのレコード表** (`db_records.yaml`): 物理/論理名、カラム定義
4. **メッセージ構造テーブル** (`messages.yaml`): 電文レイアウト、プロトコル
5. **ユビキタス言語集** (`vocabulary.yaml`): 用語、区分、定義

### 4.2 Markdown（PlantUML）形式で記述する項目

ファイル内には見出し（`#`）を一切記述せず、PlantUMLのコードブロックのみを記述する。
6.  **ユースケース図** (`uc_diagram.md`)
7.  **ドメインモデル図** (`domain_model.md`)
8.  **ロバストネス図** (`robustness.md`)
9.  **シーケンス図** (`sequence.md`)

---

## 5. コア処理・変換スクリプト要件

### 5.1 IDエイリアス参照と解決機能（id_mapping.yaml）

協力会社等の外部連携仕様が未確定である状況に対応するため、YAMLファイル内の参照（DBテーブル、メッセージ構造など）は全て論理エイリアス（例: `MSG_PARTNER_ORDER_REQ`）で記述する。
変換スクリプト実行時に、共通配置された `id_mapping.yaml` を引き当て、最終的なMarkdown出力時に正式採番ID（例: `IF-EXT-001`）やステータスに自動置換する機能を持つこと。

### 5.2 ユビキタス言語の2階層検証機能

45機能の規模に対応するため、用語集は「システム全体（global）」と「機能個別（feature）」の2階層で管理する。
変換スクリプトは、両方のYAMLを合算して用語辞書を構築し、意図しない同名異義語の定義（上書き許可フラグのない重複定義）をエラーとして検知するロジックを実装すること。

### 5.3 レイアウト定義ベースの動的Markdown結合機能

見出しレベルや掲載順序の変動を吸収するため、結合処理は `layout.yaml` の定義に完全に従うこと。

* Pythonスクリプト（`watchdog`ベース）はファイルの保存を検知し、即座にビルドを実行する。
* `layout.yaml` に指定された順序と見出しレベル（`level: 3` であれば `###` を付与）に従って、YAML（Jinja2経由）とMarkdown（PlantUML）を連結する。
* 最終的に `build/{機能名}_仕様書.md` を生成する。この成果物ファイルはGitのコミット対象外（`.gitignore`）とする。

---

## 6. GitOps / CI・CD要件

執筆環境のリアルタイムプレビューとは別に、GiteaでのPRレビューを支える自動検証ワークフロー（Gitea Actions）を実装する。

1. **整合性検証ジョブ**:
* YAMLファイル群が規定のJSON Schemaに適合しているかを検証する。
* `features.tsv` の定義パスと実際のディレクトリ構造に乖離がないかを検証する。
* YAML内に記述された論理エイリアスが `id_mapping.yaml` に存在するかを検証する。


2. **PlantUML Linterジョブ**:
* `.md` ファイル内のPlantUML構文エラーを検証する。
* ロバストネス図において「バウンダリとエンティティが直接接続されている」などのICONIX原則違反を静的解析で検知・警告する。


3. **アーティファクト生成ジョブ**:
* PR作成時および更新時にPython変換スクリプトを実行し、結合された最終Markdown（全機能分）をビルドする。
* レビュアーがGitea上で完成状態を確認できるよう、成果物をCIのArtifactsとして保存する（またはPRコメントにプレビューを通知する）。

---

## 7. ローカル執筆環境の使い方

初期環境では、ローカルでのYAML検証・Markdown生成・保存時ビルドを利用できる。Gitea ActionsによるCI/CDは別途整備する。

### 7.1 セットアップ

Python 3.10以降を用意し、プロジェクトのルートで仮想環境を作成して依存パッケージをインストールする。

Linux/macOS:

```shell
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -e .
```

Windows PowerShell:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -e .
```

VS CodeではYAML拡張機能（推奨拡張）が利用でき、`.vscode/settings.json`でYAMLファイルとJSON Schemaを紐付ける。

### 7.2 検証と仕様書生成

```shell
specforge validate
specforge build
specforge watch
```

`validate`はYAMLスキーマ、`features.tsv`と機能ディレクトリ、IDエイリアス、全体/機能別用語の重複、PlantUMLコードブロック形式を検証する。`build`は`layout.yaml`の順序と見出しレベルに従い、`build/{機能名}_仕様書.md`を生成する。`watch`は起動時に生成した後、ファイル保存に応じて再ビルドする。生成物はGit管理対象外である。

#### config/watch.py の目次生成

`config/watch.py`の`build_markdown_for_feature()`は、`config/template.j2`がある場合にJinjaテンプレートを使用する。テンプレートの独立した行に`{{ toc }}`または`[TOC]`を置くと、すべてのMarkdownを取り込んだ描画結果からリンク付き目次を生成する。コードフェンス内の見出しは対象外で、テンプレートに目次の指定がなければ挿入しない。

`generate_markdown_toc(headings, depth=None)`は、`["## 概要", "### 詳細"]`のような`#`付き見出しのリストを受け取り、Markdownの目次文字列を返す。`depth=2`なら`##`までを対象とし、省略時は全階層を対象とする。深さは1以上を指定する。見出しがない場合は空文字列を返す。

`config/global_layout.yaml`の`chapters`順に章を出力する。`dynamic_scan`では`scan_target_dir`（機能ディレクトリからの相対パス）配下を検索し、各処理のMarkdownを`expected_files`の定義順に掲載する。見出しは各項目の`heading`を使用する。定義外のファイルは掲載しない。`required: true`のファイルが処理配下に1つもなければビルドを停止し、それ以外は警告なしでスキップする。

ブロック・処理のディレクトリ、および同じ`filename`で見つかった複数ファイルはパス順に並べる。`scan_target_dir`未指定時は従来の`path`（省略時`blocks`）を使用する。`expected_files`未指定時のみ全Markdownをパス順に掲載し、空リスト指定時は掲載しない。

### 7.3 構成データの記入

`features.tsv`はタブ区切りで、`feature_id`、`feature_name`、`feature_path`、`use_case_id`、`use_case_path`、`order`の列を持つ。1ユースケースにつき1行を記載し、同じ機能に複数のユースケースがある場合は機能情報を各行に繰り返す。同一機能の`order`は同じ値にし、機能内のユースケース順はTSVの行順とする。

各YAMLファイルの項目名と必須項目は`schemas/`のJSON Schemaを参照する。外部仕様のIDは論理エイリアスで記述し、`id_mapping.yaml`に正式IDと状態を登録する。全体用語と同じ用語を機能用語集で定義する場合は、その機能側の項目に`allow_override: true`を指定する。

図ファイル（`.md`）には見出しや説明文を含めず、`@startuml`と`@enduml`で囲んだPlantUMLコードブロックのみを記述する。