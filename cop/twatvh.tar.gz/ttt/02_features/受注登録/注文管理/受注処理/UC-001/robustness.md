```plantuml
@startuml
boundary 注文画面
control 注文登録処理
entity 注文
注文画面 --> 注文登録処理
注文登録処理 --> 注文
@enduml
```
