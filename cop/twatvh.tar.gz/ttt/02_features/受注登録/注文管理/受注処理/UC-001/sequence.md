```plantuml
@startuml
actor 顧客
participant 注文画面
participant 注文登録処理
database 注文DB
顧客 -> 注文画面: 注文内容を送信
注文画面 -> 注文登録処理: 登録要求
注文登録処理 -> 注文DB: 注文を保存
注文DB --> 注文登録処理: 保存結果
注文登録処理 --> 顧客: 受付結果
@enduml
```
