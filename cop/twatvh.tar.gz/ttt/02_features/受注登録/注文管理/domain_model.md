```plantuml
@startuml
class 注文 {
  注文ID
  状態
}
@enduml
```
