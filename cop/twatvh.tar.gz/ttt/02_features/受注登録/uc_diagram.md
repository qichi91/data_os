```plantuml
@startuml
actor 顧客
usecase "注文を登録する" as UC001
顧客 --> UC001
@enduml
```
