import re
import time
from pathlib import Path
from threading import Lock, Timer

import yaml
from jinja2 import Environment, FileSystemLoader, StrictUndefined
from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer

# 監視対象のディレクトリ
FEATURES_DIR = Path("02_features").resolve()

# ディバウンスの設定（最後の変更検知からビルドを開始するまでの待機秒数）
DEBOUNCE_DELAY = 1.0

# ビルド待ちの機能名を保持するセットと、排他制御用のロック
pending_features = set()
timer_lock = Lock()
build_timer = None


def generate_markdown_toc(headings: list[str], depth: int | None = None) -> str:
    """# 付き見出しのリストからリンク付き目次を返す。depth は見出しレベルの上限。"""
    if depth is not None and depth < 1:
        raise ValueError("depth は1以上で指定してください")

    entries = []
    anchors = set()
    for heading in headings:
        match = re.match(r"^ {0,3}(#+)[ \t]+(.+?)\s*$", heading)
        if not match:
            continue
        level = len(match.group(1))
        title = re.sub(r"[ \t]+#+$", "", match.group(2)).strip()
        slug = re.sub(r"[^\w\- ]", "", title.lower()).replace(" ", "-")
        # 深さで除外する見出しも数え、本文の重複見出しとリンク先を一致させる。
        anchor = slug
        suffix = 1
        while anchor in anchors:
            anchor = f"{slug}-{suffix}"
            suffix += 1
        anchors.add(anchor)
        if depth is None or level <= depth:
            entries.append((level, title, anchor))

    if not entries:
        return ""
    base_level = min(level for level, _, _ in entries)
    return "\n".join(
        f"{'  ' * (level - base_level)}- [{title}](#{anchor})"
        for level, title, anchor in entries
    )


def _collect_markdown_headings(document: str) -> list[str]:
    """コードフェンス内を除き、目次の対象となる見出しを集める。"""
    headings = []
    fence = None
    for line in document.splitlines():
        if fence is not None:
            if re.fullmatch(rf" {{0,3}}{re.escape(fence[0])}{{{len(fence)},}}[ \t]*", line):
                fence = None
            continue
        match = re.match(r"^ {0,3}(`{3,}|~{3,})", line)
        if match:
            fence = match.group(1)
        elif re.match(r"^ {0,3}#+[ \t]+\S", line):
            headings.append(line)
    return headings


def adjust_markdown_content(content: str, base_level: int, base_number: str) -> str:
    """
    ファイルの中身の Markdown 見出しを、親のレベルと番号に合わせて調整する。
    例: 親が `##### 1.1.1.1.` (level=5) の場合、
        ファイル内の `# 概要` -> `###### 1.1.1.1.1. 概要` に変換する。
    """
    adjusted_lines = []
    counters = {}
    header_pattern = re.compile(r'^(#+)\s+(.*)')

    for line in content.split('\n'):
        match = header_pattern.match(line)
        if not match:
            adjusted_lines.append(line)
            continue

        # 同じ階層を進めたら、配下の見出し番号は振り直す。
        local_level = len(match.group(1))
        counters = {level: count for level, count in counters.items() if level <= local_level}
        counters[local_level] = counters.get(local_level, 0) + 1
        local_number = ".".join(str(counters[level]) for level in range(1, local_level + 1))

        hashes = '#' * (base_level + local_level)
        adjusted_lines.append(
            f"{hashes} {base_number}.{local_number}. {match.group(2).strip()}"
        )

    return '\n'.join(adjusted_lines)


def _walk_sections(sections, level=2, prefix=""):
    """章 → ブロック → 処理 → ファイルの順に、階層と番号を添えて巡回する。"""
    child_keys = {2: "scanned_data", 3: "processes", 4: "contents"}
    for index, section in enumerate(sections, 1):
        number = f"{prefix}.{index}" if prefix else str(index)
        yield section, level, number
        if level == 2 and section.get("type") != "dynamic_scan":
            continue
        child_key = child_keys.get(level)
        if child_key:
            yield from _walk_sections(section.get(child_key, []), level + 1, number)


def build_tree_with_numbers(chapters_config):
    """章階層に採番し、末端のMarkdown見出しを親の番号・階層に合わせる。"""
    for section, level, number in _walk_sections(chapters_config):
        section.update(level=level, number=number)
        if level == 5:
            section["content"] = adjust_markdown_content(section["content"], level, number)
    return chapters_config


def _load_yaml(candidates):
    """優先順に候補を探し、最初に見つかった設定を読み込む。"""
    for candidate in candidates:
        if candidate.is_file():
            with candidate.open(encoding="utf-8") as stream:
                return yaml.safe_load(stream) or {}
    raise FileNotFoundError(f"設定ファイルが見つかりません: {candidates[0]}")


def _scan_blocks(scan_root: Path, expected_files=None) -> list[dict]:
    """ブロック配下のMarkdownを、expected_filesの定義順に読み込む。"""
    blocks = []
    if not scan_root.is_dir():
        return blocks

    # 定義がない既存レイアウトだけは、従来どおり全Markdownを対象にする。
    file_specs = expected_files if expected_files is not None else [{"filename": "*.md"}]
    for block_dir in sorted(p for p in scan_root.iterdir() if p.is_dir()):
        processes = []
        # 処理ディレクトリがなければ、ブロック直下を1つの処理として扱う。
        process_dirs = sorted(p for p in block_dir.iterdir() if p.is_dir()) or [block_dir]
        for process_dir in process_dirs:
            contents = []
            # ファイル名順ではなく定義順を優先し、配下の複数ディレクトリも検索する。
            for spec in file_specs:
                paths = sorted(
                    path for path in process_dir.rglob(spec["filename"]) if path.is_file()
                )
                if not paths and spec.get("required") is True:
                    raise FileNotFoundError(
                        f"必須Markdownが見つかりません: {process_dir} / {spec['filename']}"
                    )
                for path in paths:
                    contents.append({
                        "name": path.stem,
                        "heading": spec.get("heading", path.stem),
                        "content": path.read_text(encoding="utf-8"),
                    })
            if contents:
                processes.append({"name": process_dir.name, "contents": contents})
        if processes:
            blocks.append({"name": block_dir.name, "processes": processes})
    return blocks


def _render_markdown(chapters, feature, template_path: Path) -> str:
    """テンプレートがあれば描画し、なければ従来の見出しと本文を連結する。"""
    if template_path.is_file():
        environment = Environment(
            loader=FileSystemLoader(str(template_path.parent)),
            undefined=StrictUndefined,
            autoescape=False,
            keep_trailing_newline=True,
        )
        document = environment.get_template(template_path.name).render(
            metadata=feature.get("metadata", {}),
            changelog_content=feature.get("changelog_content", ""),
            chapters=chapters,
            toc="[TOC]",
        )
        # 本文の全見出しが確定してから目次を差し込む。
        toc_marker = re.compile(r"(?m)^[ \t]*\[TOC\][ \t]*$")
        if toc_marker.search(document):
            toc = generate_markdown_toc(_collect_markdown_headings(document))
            document = toc_marker.sub(lambda match: toc, document)
        return document

    output = []
    for section, level, number in _walk_sections(chapters):
        title = section.get("title", section.get("name", ""))
        if level == 5:
            title = section.get("heading", title)
        title = str(title or "").strip()
        output.extend([f"{'#' * level} {number}. {title}".rstrip(), ""])
        if level == 5 or (level == 2 and section.get("type") != "dynamic_scan"):
            body = section.get("content", "")
            if body:
                output.extend([str(body).rstrip(), ""])
    return "\n".join(output)


def build_markdown_for_feature(feature_name: str):
    """設定読み込み → Markdown収集 → 採番 → 描画 → 保存の順に仕様書を生成する。"""
    project_dir = FEATURES_DIR.parent
    feature_dir = FEATURES_DIR / feature_name
    layout = _load_yaml([
        project_dir / "global_layout.yaml",
        project_dir / "config" / "global_layout.yaml",
        Path(__file__).resolve().parent / "global_layout.yaml",
    ])
    feature = _load_yaml([feature_dir / "feature.yaml"])
    chapters = layout.get("chapters", layout.get("sections", [])) if isinstance(layout, dict) else layout
    chapters = list(chapters or [])

    for chapter in chapters:
        if chapter.get("type") == "dynamic_scan":
            scan_dir = chapter.get("scan_target_dir", chapter.get("path", "blocks"))
            chapter["scanned_data"] = _scan_blocks(
                feature_dir / scan_dir, chapter.get("expected_files")
            )
    build_tree_with_numbers(chapters)
    document = _render_markdown(chapters, feature, project_dir / "config" / "template.j2")

    output_path = feature.get("output", feature.get("output_file"))
    destination = Path(output_path) if output_path else project_dir / "03_output" / f"{feature_name}.md"
    if not destination.is_absolute():
        destination = project_dir / destination
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(document.rstrip() + "\n", encoding="utf-8")
    print(f"仕様書を出力しました: {destination}")


def execute_build():
    """溜まっていた機能のビルドを実際に実行する処理"""
    global build_timer
    
    with timer_lock:
        # セットから対象機能を取り出し、セットとタイマーをリセット
        features_to_build = list(pending_features)
        pending_features.clear()
        build_timer = None

    if not features_to_build:
        return

    print("\n--- ビルド処理開始 ---")
    for feature_name in features_to_build:
        print(f"[{feature_name}] の仕様書をビルドしています...")
        
        build_markdown_for_feature(feature_name)
        

    print("--- ビルド処理完了 ---\n")

def schedule_build(feature_name: str):
    """変更を検知した機能をセットに追加し、タイマーをリセットする"""
    global build_timer
    
    with timer_lock:
        pending_features.add(feature_name)
        
        # 既にタイマーが動いていればキャンセル（延長）
        if build_timer is not None:
            build_timer.cancel()
            
        # 新しいタイマーをセット
        build_timer = Timer(DEBOUNCE_DELAY, execute_build)
        build_timer.start()

class FeatureChangeHandler(FileSystemEventHandler):
    """ファイル変更イベントを受け取るハンドラ"""
    def _process_event(self, event):
        if event.is_directory:
            return
            
        path = Path(event.src_path).resolve()
        
        try:
            # FEATURES_DIR からの相対パスを取得し、最初の要素を機能名とする
            # 例: features/feature_A/blocks/UC-001/doc.md -> relative_parts[0] は 'feature_A'
            relative_path = path.relative_to(FEATURES_DIR)
            feature_name = relative_path.parts[0]
            
            # ビルドをスケジュール
            schedule_build(feature_name)
            
        except ValueError:
            # FEATURES_DIR 配下以外の変更（出力先など）は無視する
            pass

    def on_created(self, event): self._process_event(event)
    def on_modified(self, event): self._process_event(event)
    def on_deleted(self, event): self._process_event(event)
    def on_moved(self, event):
        self._process_event(event)
        # 移動先が features 配下の場合も考慮
        if hasattr(event, 'dest_path'):
            event.src_path = event.dest_path
            self._process_event(event)

def start_watching():
    print(f"監視を開始します... (Target: {FEATURES_DIR})")
    event_handler = FeatureChangeHandler()
    observer = Observer()
    observer.schedule(event_handler, str(FEATURES_DIR), recursive=True)
    observer.start()
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
        if build_timer is not None:
            build_timer.cancel()
    observer.join()

if __name__ == "__main__":
    start_watching()