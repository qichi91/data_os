from __future__ import annotations

import csv
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import jsonschema
import yaml
from jinja2 import Environment, FileSystemLoader, StrictUndefined
from jinja2.exceptions import TemplateError


class SpecError(Exception):
    """Raised when the authoring data or project structure is invalid."""


@dataclass(frozen=True)
class Feature:
    feature_id: str
    feature_name: str
    feature_path: str
    use_case_id: str
    use_case_path: str
    order: int


SCHEMA_BY_FILENAME = {
    "uc_spec.yaml": "uc_spec.schema.json",
    "io_list.yaml": "io_list.schema.json",
    "db_records.yaml": "db_records.schema.json",
    "messages.yaml": "messages.schema.json",
    "vocabulary.yaml": "vocabulary.schema.json",
    "layout.yaml": "layout.schema.json",
    "id_mapping.yaml": "id_mapping.schema.json",
}

ALIAS_REFERENCE_KEYS = {
    "alias",
    "data_ref",
    "table_ref",
    "message_ref",
    "record_ref",
}


def _relative(path: Path, root: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return str(path)


def _project_path(root: Path, relative_path: str) -> Path:
    candidate = (root / relative_path).resolve()
    try:
        candidate.relative_to(root.resolve())
    except ValueError as exc:
        raise SpecError(f"プロジェクト外のパスは使用できません: {relative_path}") from exc
    return candidate


def _load_yaml(path: Path, root: Path) -> Any:
    try:
        with path.open(encoding="utf-8") as stream:
            return yaml.safe_load(stream)
    except (OSError, yaml.YAMLError) as exc:
        raise SpecError(f"{_relative(path, root)}: YAMLを読み込めません: {exc}") from exc


def _load_schema(root: Path, schema_name: str) -> dict[str, Any]:
    path = root / "schemas" / schema_name
    try:
        with path.open(encoding="utf-8") as stream:
            schema = json.load(stream)
        jsonschema.Draft202012Validator.check_schema(schema)
        return schema
    except (OSError, json.JSONDecodeError, jsonschema.SchemaError) as exc:
        raise SpecError(f"{_relative(path, root)}: JSON Schemaを読み込めません: {exc}") from exc


def _validate_document(path: Path, root: Path, schema_name: str) -> Any:
    document = _load_yaml(path, root)
    schema = _load_schema(root, schema_name)
    errors = sorted(
        jsonschema.Draft202012Validator(schema).iter_errors(document),
        key=lambda error: list(error.absolute_path),
    )
    if errors:
        details = "; ".join(
            f"{'.'.join(map(str, error.absolute_path)) or '<root>'}: {error.message}"
            for error in errors
        )
        raise SpecError(f"{_relative(path, root)}: スキーマ違反: {details}")
    return document


def _load_features(root: Path) -> list[Feature]:
    path = root / "features.tsv"
    expected_columns = [
        "feature_id",
        "feature_name",
        "feature_path",
        "use_case_id",
        "use_case_path",
        "order",
    ]
    try:
        with path.open(encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream, delimiter="\t")
            if reader.fieldnames != expected_columns:
                raise SpecError(
                    "features.tsv: 列は次の順で指定してください: "
                    + "\t".join(expected_columns)
                )
            records = []
            for line_number, row in enumerate(reader, start=2):
                if None in row:
                    raise SpecError(
                        f"features.tsv:{line_number}: 列数がヘッダーと一致しません"
                    )
                try:
                    order = int(row["order"])
                except (TypeError, ValueError) as exc:
                    raise SpecError(
                        f"features.tsv:{line_number}: orderは正の整数で指定してください"
                    ) from exc
                values = [
                    (row.get(column) or "").strip()
                    for column in expected_columns[:-1]
                ]
                if any(not value for value in values) or order < 1:
                    raise SpecError(
                        f"features.tsv:{line_number}: 空欄または不正な値があります"
                    )
                records.append(Feature(*values, order))
    except OSError as exc:
        raise SpecError(f"features.tsvを読み込めません: {exc}") from exc

    if not records:
        raise SpecError("features.tsvに機能とユースケースを1件以上定義してください")

    feature_by_id: dict[str, tuple[str, str, int]] = {}
    use_case_ids: set[str] = set()
    feature_orders: dict[str, int] = {}
    feature_names: dict[str, str] = {}
    for record in records:
        definition = (
            record.feature_name,
            record.feature_path,
            record.order,
        )
        previous = feature_by_id.setdefault(record.feature_id, definition)
        if previous != definition:
            raise SpecError(
                f"features.tsv: 機能ID {record.feature_id} の定義が行間で一致しません"
            )
        previous_id = feature_names.setdefault(record.feature_name, record.feature_id)
        if previous_id != record.feature_id:
            raise SpecError(f"features.tsv: 機能名が重複しています: {record.feature_name}")
        if record.use_case_id in use_case_ids:
            raise SpecError(f"features.tsv: ユースケースIDが重複しています: {record.use_case_id}")
        use_case_ids.add(record.use_case_id)
        if record.feature_path.split("/")[0] != "02_features":
            raise SpecError(
                f"features.tsv: feature_pathは02_features配下に指定してください: "
                f"{record.feature_path}"
            )
        if Path(record.feature_path).name != record.feature_name:
            raise SpecError(
                f"features.tsv: feature_pathの末端名とfeature_nameが一致しません: "
                f"{record.feature_path}"
            )
        if not record.use_case_path.startswith(record.feature_path.rstrip("/") + "/"):
            raise SpecError(
                f"features.tsv: use_case_pathは対応機能配下に指定してください: "
                f"{record.use_case_path}"
            )
        if Path(record.use_case_path).name != record.use_case_id:
            raise SpecError(
                f"features.tsv: use_case_pathの末端名とuse_case_idが一致しません: "
                f"{record.use_case_path}"
            )
        feature_orders[record.feature_id] = record.order

    if len(set(feature_orders.values())) != len(feature_orders):
        raise SpecError("features.tsv: 異なる機能に同じorderを指定できません")
    return records


def _validate_directory_registry(root: Path, features: list[Feature]) -> None:
    registered = {feature.feature_path for feature in features}
    feature_root = root / "02_features"
    if not feature_root.is_dir():
        raise SpecError("02_featuresディレクトリがありません")
    actual = {
        _relative(path, root)
        for path in feature_root.iterdir()
        if path.is_dir()
    }
    if actual != registered:
        missing = sorted(registered - actual)
        unregistered = sorted(actual - registered)
        details = []
        if missing:
            details.append(f"存在しない機能パス: {', '.join(missing)}")
        if unregistered:
            details.append(f"features.tsv未登録の機能ディレクトリ: {', '.join(unregistered)}")
        raise SpecError("features.tsvと機能ディレクトリが一致しません: " + "; ".join(details))

    for feature in features:
        feature_path = _project_path(root, feature.feature_path)
        use_case_path = _project_path(root, feature.use_case_path)
        if not feature_path.is_dir():
            raise SpecError(f"機能ディレクトリがありません: {feature.feature_path}")
        if not use_case_path.is_dir():
            raise SpecError(f"ユースケースディレクトリがありません: {feature.use_case_path}")
        if not (use_case_path / "uc_spec.yaml").is_file():
            raise SpecError(
                f"ユースケース記述がありません: {feature.use_case_path}/uc_spec.yaml"
            )

    for feature_path in registered:
        expected_use_cases = {
            item.use_case_path for item in features if item.feature_path == feature_path
        }
        actual_use_cases = {
            _relative(path.parent, root)
            for path in _project_path(root, feature_path).rglob("uc_spec.yaml")
        }
        if actual_use_cases != expected_use_cases:
            unregistered = sorted(actual_use_cases - expected_use_cases)
            missing = sorted(expected_use_cases - actual_use_cases)
            details = []
            if missing:
                details.append(f"ユースケース記述がない登録パス: {', '.join(missing)}")
            if unregistered:
                details.append(f"features.tsv未登録のユースケース: {', '.join(unregistered)}")
            raise SpecError("features.tsvとユースケース記述が一致しません: " + "; ".join(details))


def _load_layout(root: Path) -> dict[str, Any]:
    return _validate_document(root / "layout.yaml", root, "layout.schema.json")


def _section_sources(
    root: Path,
    feature: Feature,
    section: dict[str, Any],
    feature_use_cases: list[Feature],
) -> list[tuple[Path, dict[str, str]]]:
    scope = section["scope"]
    source = section.get("source")
    feature_path = _project_path(root, feature.feature_path)
    if scope == "vocabulary":
        return []
    if scope == "common":
        return [(_project_path(root, source), {})]
    if scope == "feature":
        return [(_project_path(root, f"{feature.feature_path}/{source}"), {})]
    if scope == "blocks":
        matches = sorted(feature_path.glob(f"*/{source}"))
        if not matches:
            raise SpecError(
                f"{feature.feature_path}: layout.yamlのblocks sourceが見つかりません: {source}"
            )
        return [
            (path, {"block_name": path.parent.name})
            for path in matches
        ]
    if scope == "use_cases":
        return [
            (
                _project_path(root, f"{use_case.use_case_path}/{source}"),
                {"use_case_id": use_case.use_case_id},
            )
            for use_case in feature_use_cases
        ]
    raise SpecError(f"layout.yaml: 未対応のscopeです: {scope}")


def _check_plantuml_markdown(path: Path, root: Path) -> None:
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise SpecError(f"{_relative(path, root)}: 読み込めません: {exc}") from exc
    pattern = re.compile(r"```plantuml[ \t]*\r?\n(.*?)```", re.DOTALL)
    blocks = pattern.findall(text)
    remainder = pattern.sub("", text).strip()
    if not blocks or remainder:
        raise SpecError(
            f"{_relative(path, root)}: PlantUMLコードブロック以外の記述があります"
        )
    for index, block in enumerate(blocks, start=1):
        lines = [line.strip() for line in block.strip().splitlines() if line.strip()]
        if not lines or lines[0] != "@startuml" or lines[-1] != "@enduml":
            raise SpecError(
                f"{_relative(path, root)}: {index}番目のPlantUMLブロックは"
                "@startumlと@endumlで囲んでください"
            )


def _iter_alias_references(value: Any):
    if isinstance(value, dict):
        for key, child in value.items():
            if key in ALIAS_REFERENCE_KEYS and isinstance(child, str):
                yield child
            elif key.endswith("_refs") and isinstance(child, list):
                yield from (item for item in child if isinstance(item, str))
            yield from _iter_alias_references(child)
    elif isinstance(value, list):
        for child in value:
            yield from _iter_alias_references(child)


def _validate_aliases(root: Path, mapping: dict[str, Any]) -> None:
    known_aliases = mapping["mappings"]
    for path in sorted(root.rglob("*.yaml")):
        if path.name in {"id_mapping.yaml", "layout.yaml"}:
            continue
        if any(part in {"build", ".venv", "__pycache__"} for part in path.parts):
            continue
        document = _load_yaml(path, root)
        for alias in _iter_alias_references(document):
            if alias not in known_aliases:
                raise SpecError(
                    f"{_relative(path, root)}: 未登録のIDエイリアスです: {alias}"
                )


def _merged_vocabulary(root: Path, feature: Feature) -> dict[str, Any]:
    global_path = root / "01_common" / "vocabulary.yaml"
    feature_path = _project_path(root, f"{feature.feature_path}/vocabulary.yaml")
    global_data = _validate_document(global_path, root, "vocabulary.schema.json")
    feature_data = _validate_document(feature_path, root, "vocabulary.schema.json")
    merged: dict[str, dict[str, Any]] = {}
    for term in global_data["terms"]:
        if term["term"] in merged:
            raise SpecError(
                f"{_relative(global_path, root)}: 用語が重複しています: {term['term']}"
            )
        merged[term["term"]] = term
    feature_terms: set[str] = set()
    for term in feature_data["terms"]:
        name = term["term"]
        if name in feature_terms:
            raise SpecError(f"{_relative(feature_path, root)}: 用語が重複しています: {name}")
        feature_terms.add(name)
        if name in merged and not term.get("allow_override", False):
            raise SpecError(
                f"{_relative(feature_path, root)}: 全体用語「{name}」の上書きには"
                "allow_override: trueが必要です"
            )
        merged[name] = term
    return {"terms": list(merged.values())}


def validate_project(root: Path) -> list[Feature]:
    root = root.resolve()
    features = _load_features(root)
    _validate_directory_registry(root, features)

    for path in sorted(root.rglob("*.yaml")):
        if any(part in {"build", ".venv", "__pycache__"} for part in path.parts):
            continue
        schema_name = SCHEMA_BY_FILENAME.get(path.name)
        if schema_name is None:
            raise SpecError(
                f"{_relative(path, root)}: 対応するJSON Schemaがありません"
            )
        _validate_document(path, root, schema_name)

    layout = _load_layout(root)
    mapping = _validate_document(
        root / "id_mapping.yaml", root, "id_mapping.schema.json"
    )
    _validate_aliases(root, mapping)

    unique_features_by_id: dict[str, Feature] = {}
    for feature in features:
        unique_features_by_id.setdefault(feature.feature_id, feature)
    unique_features = list(unique_features_by_id.values())
    for feature in features:
        use_case_file = _project_path(
            root, f"{feature.use_case_path}/uc_spec.yaml"
        )
        use_case_data = _load_yaml(use_case_file, root)
        if use_case_data["use_case_id"] != feature.use_case_id:
            raise SpecError(
                f"{_relative(use_case_file, root)}: use_case_idがfeatures.tsvと一致しません"
            )
    for feature in unique_features:
        _merged_vocabulary(root, feature)
        feature_use_cases = [
            item for item in features if item.feature_id == feature.feature_id
        ]
        for section in layout["sections"]:
            for path, _ in _section_sources(
                root, feature, section, feature_use_cases
            ):
                if not path.is_file():
                    raise SpecError(
                        f"layout.yamlで指定されたファイルがありません: "
                        f"{_relative(path, root)}"
                    )

    for path in sorted((root / "02_features").rglob("*.md")):
        _check_plantuml_markdown(path, root)
    return features


def _environment(root: Path, mapping: dict[str, Any]) -> Environment:
    environment = Environment(
        loader=FileSystemLoader(root / "templates"),
        undefined=StrictUndefined,
        autoescape=False,
        trim_blocks=True,
        lstrip_blocks=True,
    )

    def resolve_id(alias: str) -> str:
        try:
            return mapping["mappings"][alias]["id"]
        except KeyError as exc:
            raise SpecError(f"未登録のIDエイリアスです: {alias}") from exc

    def resolve_status(alias: str) -> str:
        try:
            return mapping["mappings"][alias]["status"]
        except KeyError as exc:
            raise SpecError(f"未登録のIDエイリアスです: {alias}") from exc

    environment.filters["resolve_id"] = resolve_id
    environment.filters["resolve_status"] = resolve_status
    return environment


def _render_yaml(
    root: Path,
    path: Path,
    template_name: str,
    context: dict[str, Any],
    environment: Environment,
    document: Any | None = None,
) -> str:
    if document is None:
        document = _load_yaml(path, root)
    try:
        return environment.get_template(template_name).render(
            **{**context, "data": document}
        ).strip()
    except (OSError, TemplateError, ValueError) as exc:
        raise SpecError(
            f"{_relative(path, root)}: テンプレートを描画できません: {exc}"
        ) from exc


def build_project(root: Path) -> list[Path]:
    root = root.resolve()
    features = validate_project(root)
    layout = _load_layout(root)
    mapping = _validate_document(
        root / "id_mapping.yaml", root, "id_mapping.schema.json"
    )
    environment = _environment(root, mapping)
    feature_by_id = {feature.feature_id: feature for feature in features}
    ordered_features = sorted(
        feature_by_id.values(), key=lambda feature: (feature.order, feature.feature_id)
    )
    output: list[Path] = []
    rendered_files: list[tuple[Path, str]] = []

    for feature in ordered_features:
        feature_use_cases = [
            item for item in features if item.feature_id == feature.feature_id
        ]
        context: dict[str, Any] = {
            "feature_id": feature.feature_id,
            "feature_name": feature.feature_name,
            "use_case_id": "",
            "block_name": "",
            "mapping": mapping["mappings"],
        }
        parts = [f"# {feature.feature_id} {feature.feature_name} 仕様書"]
        for section in layout["sections"]:
            sources = _section_sources(root, feature, section, feature_use_cases)
            if section["scope"] == "vocabulary":
                merged_vocabulary = _merged_vocabulary(root, feature)
                body = _render_yaml(
                    root,
                    root / "01_common" / "vocabulary.yaml",
                    section["template"],
                    context,
                    environment,
                    document=merged_vocabulary,
                )
                sources_with_body = [(section["title"], body)]
            else:
                sources_with_body = []
                for path, section_context in sources:
                    current_context = {**context, **section_context}
                    try:
                        title = environment.from_string(section["title"]).render(
                            **current_context
                        )
                    except TemplateError as exc:
                        raise SpecError(f"layout.yaml: 見出しを描画できません: {exc}") from exc
                    if path.suffix == ".yaml":
                        template_name = section.get("template")
                        if not template_name:
                            raise SpecError(
                                f"layout.yaml: YAMLにはtemplateが必要です: {section['source']}"
                            )
                        body = _render_yaml(
                            root, path, template_name, current_context, environment
                        )
                    else:
                        if section.get("template"):
                            raise SpecError(
                                f"layout.yaml: Markdown sourceにtemplateは指定できません: "
                                f"{section['source']}"
                            )
                        body = path.read_text(encoding="utf-8").strip()
                    sources_with_body.append((title, body))

            for title, body in sources_with_body:
                if not body:
                    continue
                heading = "#" * section["level"]
                parts.extend([f"{heading} {title}", body])

        filename = f"{feature.feature_name}_仕様書.md"
        destination = _project_path(root, f"build/{filename}")
        rendered_files.append((destination, "\n\n".join(parts).rstrip() + "\n"))
        output.append(destination)

    for destination, content in rendered_files:
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(content, encoding="utf-8")
    return output
