from __future__ import annotations

import argparse
import sys
import threading
from pathlib import Path

from watchdog.events import FileSystemEvent, FileSystemEventHandler
from watchdog.observers import Observer

from .pipeline import SpecError, build_project, validate_project


def _is_generated_path(path: str, root: Path) -> bool:
    try:
        relative = Path(path).resolve().relative_to(root.resolve())
    except ValueError:
        return True
    return bool(relative.parts) and relative.parts[0] in {
        "build",
        ".venv",
        "__pycache__",
    }


class _BuildOnChange(FileSystemEventHandler):
    def __init__(self, root: Path, delay: float = 0.3) -> None:
        self.root = root
        self.delay = delay
        self._timer: threading.Timer | None = None
        self._lock = threading.Lock()

    def on_any_event(self, event: FileSystemEvent) -> None:
        if event.is_directory or _is_generated_path(event.src_path, self.root):
            return
        if getattr(event, "dest_path", None) and _is_generated_path(event.dest_path, self.root):
            return
        with self._lock:
            if self._timer is not None:
                self._timer.cancel()
            self._timer = threading.Timer(self.delay, self._rebuild)
            self._timer.daemon = True
            self._timer.start()

    def _rebuild(self) -> None:
        try:
            outputs = build_project(self.root)
            print(
                "自動ビルド完了: " + ", ".join(str(path.relative_to(self.root)) for path in outputs),
                flush=True,
            )
        except (SpecError, OSError) as exc:
            print(f"自動ビルド失敗: {exc}", file=sys.stderr, flush=True)


def _watch(root: Path) -> None:
    outputs = build_project(root)
    print(
        "初回ビルド完了: " + ", ".join(str(path.relative_to(root)) for path in outputs),
        flush=True,
    )
    observer = Observer()
    observer.schedule(_BuildOnChange(root), str(root), recursive=True)
    observer.start()
    print("ファイル変更を監視中です。終了するにはCtrl+Cを押してください。", flush=True)
    try:
        observer.join()
    except KeyboardInterrupt:
        observer.stop()
        observer.join()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="specforge",
        description="ICONIX仕様のローカル検証とMarkdown生成",
    )
    parser.add_argument(
        "--root",
        type=Path,
        default=Path.cwd(),
        help="仕様プロジェクトのルートディレクトリ（既定: カレントディレクトリ）",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("validate", help="YAML、エイリアス、用語、構成を検証")
    subparsers.add_parser("build", help="機能ごとのMarkdown仕様書を生成")
    subparsers.add_parser("watch", help="初回ビルド後、ファイル保存を監視")
    args = parser.parse_args(argv)
    root = args.root.resolve()

    try:
        if args.command == "validate":
            features = validate_project(root)
            print(f"検証成功: {len({item.feature_id for item in features})}機能")
        elif args.command == "build":
            outputs = build_project(root)
            print("ビルド成功: " + ", ".join(str(path.relative_to(root)) for path in outputs))
        else:
            _watch(root)
    except (SpecError, OSError) as exc:
        print(f"エラー: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
