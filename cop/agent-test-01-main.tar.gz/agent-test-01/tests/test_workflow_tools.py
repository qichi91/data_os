import contextlib
import io
import json
import os
import sqlite3
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import yaml
from docx import Document

ROOT = Path(__file__).resolve().parents[1]
import sys

sys.path.insert(0, str(ROOT / "scripts"))

from agent_protocol import run_agent
from check_trace_coverage import check_coverage
from check_vocabulary_drift import main as check_vocabulary_main
from orchestrate_spec_issue import parse_issue_body, safe_component
import orchestrate_spec_issue
from parse_legacy_docs import init_db, parse_docx
from update_trace_status import update_status
from validate_spec_yaml import validate_spec


class TraceWorkflowTests(unittest.TestCase):
    def test_import_and_update_trace_status(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            docx_path = Path(temp_dir) / "legacy.docx"
            db_path = Path(temp_dir) / "trace.sqlite"
            document = Document()
            document.add_heading("Section A", level=1)
            document.add_paragraph("First requirement")
            document.add_heading("Section B", level=1)
            document.add_paragraph("Second requirement")
            document.save(docx_path)

            connection = init_db(str(db_path))
            try:
                parse_docx(str(docx_path), connection, "Section B")
            finally:
                connection.close()

            with sqlite3.connect(db_path) as connection:
                rows = connection.execute(
                    "SELECT p_id, text, status FROM legacy_traces ORDER BY p_id"
                ).fetchall()
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0][1:], ("Second requirement", "UNUSED"))

            update_status(str(db_path), rows[0][0], "USED", "UC-001", None)
            with self.assertRaisesRegex(ValueError, "cannot change terminal status"):
                update_status(str(db_path), rows[0][0], "DISCARDED", None, "not needed")
            self.assertEqual(check_coverage(str(db_path), "legacy.docx"), 0)

    def test_import_refreshes_unused_text_but_protects_assigned_text(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            docx_path = Path(temp_dir) / "legacy.docx"
            db_path = Path(temp_dir) / "trace.sqlite"
            document = Document()
            document.add_paragraph("Initial text")
            document.save(docx_path)
            connection = init_db(str(db_path))
            parse_docx(str(docx_path), connection)
            document = Document()
            document.add_paragraph("Updated text")
            document.save(docx_path)
            parse_docx(str(docx_path), connection)
            trace_id = connection.execute("SELECT p_id FROM legacy_traces").fetchone()[0]
            connection.execute(
                "UPDATE legacy_traces SET status = 'USED', used_in_uc = 'UC-001' WHERE p_id = ?",
                (trace_id,),
            )
            connection.commit()
            document = Document()
            document.add_paragraph("Changed after assignment")
            document.save(docx_path)
            with self.assertRaisesRegex(ValueError, "changed after being marked"):
                parse_docx(str(docx_path), connection)
            connection.close()

    def test_discard_requires_reason(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            db_path = Path(temp_dir) / "trace.sqlite"
            with sqlite3.connect(db_path) as connection:
                connection.execute(
                    "CREATE TABLE legacy_traces (p_id TEXT PRIMARY KEY, status TEXT, "
                    "used_in_uc TEXT, discard_reason TEXT)"
                )
                connection.execute(
                    "INSERT INTO legacy_traces (p_id, status) VALUES ('P-1', 'UNUSED')"
                )
            with self.assertRaisesRegex(ValueError, "--reason is required"):
                update_status(str(db_path), "P-1", "DISCARDED", None, None)


class ValidationAndIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.schema = yaml.safe_load((ROOT / "schemas/usecase.schema.yaml").read_text(encoding="utf-8"))
        cls.spec = yaml.safe_load(
            (ROOT / "docs/design/order_management/place_order/UC-001.spec.yaml").read_text(encoding="utf-8")
        )

    def test_checked_in_usecase_matches_schema_and_trace_refs(self):
        trace_ids = {
            step["source_p_id"] for step in self.spec["items"]
        } | {
            flow["source_p_id"] for flow in self.spec["alternate_flows"]
        }
        self.assertEqual(validate_spec(self.spec, self.schema, "fixture", trace_ids), [])

    def test_missing_alternate_source_is_rejected(self):
        spec = yaml.safe_load(yaml.safe_dump(self.spec, allow_unicode=True))
        del spec["alternate_flows"][0]["source_p_id"]
        errors = validate_spec(spec, self.schema, "fixture")
        self.assertTrue(any("alternate_flows[0].source_p_id" in error for error in errors))

    def test_non_string_field_is_rejected(self):
        spec = yaml.safe_load(yaml.safe_dump(self.spec, allow_unicode=True))
        spec["items"][0]["action"] = 17
        errors = validate_spec(spec, self.schema, "fixture")
        self.assertTrue(any("items[0].action: expected a string" in error for error in errors))

    def test_unknown_trace_id_is_rejected(self):
        errors = validate_spec(self.spec, self.schema, "fixture", {"unknown"})
        self.assertTrue(any("unknown trace ID" in error for error in errors))

    def test_issue_parsing_and_path_component_guard(self):
        body = (
            "- **新モジュール名**: `order_management`\n"
            "- **機能名**: `place_order`\n"
            "- **対象ユースケースID**: `UC-002`\n"
            "- **主仕様書（Word）**: `docs/original/legacy.docx`\n"
            "- **原本抽出対象セクション**: `注文`\n"
            "- [x] エージェント実行準備完了"
        )
        meta = parse_issue_body(body)
        self.assertEqual(meta["module"], "order_management")
        self.assertEqual(meta["uc_id"], "UC-002")
        self.assertEqual(meta["section"], "注文")
        self.assertEqual(meta["ready"], "true")
        with self.assertRaisesRegex(ValueError, "only letters"):
            safe_component("../outside", "module")

    def test_orchestrator_does_not_create_pr_after_spec_validation_failure(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            source = root / "docs/original/source.docx"
            source.parent.mkdir(parents=True)
            source.write_bytes(b"fixture")
            body = (
                "- **新モジュール名**: `sample`\n"
                "- **機能名**: `feature`\n"
                "- **対象ユースケースID**: `UC-001`\n"
                "- **主仕様書（Word）**: `docs/original/source.docx`\n"
                "- [x] エージェント実行準備完了"
            )
            calls = []

            def fake_run_cmd(command, check=True):
                calls.append(command)
                if command[:3] == ["tea", "issue", "show"]:
                    return subprocess.CompletedProcess(command, 0, json.dumps({"body": body}), "")
                if command[:3] == ["git", "diff", "--cached"]:
                    return subprocess.CompletedProcess(command, 1, "", "")
                if any("validate_spec_yaml.py" in part for part in command):
                    raise RuntimeError("fixture schema failure")
                return subprocess.CompletedProcess(command, 0, "", "")

            def fake_agent(_meta, _issue, out_dir, _source):
                out_dir.mkdir(parents=True, exist_ok=True)
                (out_dir / "UC-001.spec.yaml").write_text("fixture", encoding="utf-8")
                diagrams = out_dir / "diagrams"
                diagrams.mkdir()
                (diagrams / "sequence.puml").write_text("@startuml\n@enduml\n", encoding="utf-8")

            with (
                patch.object(orchestrate_spec_issue, "ROOT", root),
                patch.object(orchestrate_spec_issue, "run_cmd", side_effect=fake_run_cmd),
                patch.object(orchestrate_spec_issue, "invoke_agent", side_effect=fake_agent),
            ):
                with self.assertRaisesRegex(RuntimeError, "fixture schema failure"):
                    orchestrate_spec_issue.execute_issue(17)

            self.assertFalse(any(command[:3] == ["tea", "pr", "create"] for command in calls))
            self.assertIn(
                ["tea", "issue", "edit", "17", "--remove-labels", "status:in-progress", "--add-labels", "status:error"],
                calls,
            )

    def test_agent_protocol_requires_command(self):
        with patch.dict(os.environ, {}, clear=True):
            with self.assertRaisesRegex(RuntimeError, "SPEC_AGENT_COMMAND is not configured"):
                run_agent({"task": "test"})

    def test_agent_protocol_sends_json_on_stdin(self):
        output = io.StringIO()
        with patch.dict(os.environ, {"SPEC_AGENT_COMMAND": "/bin/cat"}):
            with contextlib.redirect_stdout(output):
                run_agent({"task": "test", "issue": 3}, cwd=ROOT)
        self.assertEqual(yaml.safe_load(output.getvalue()), {"task": "test", "issue": 3})

    def test_missing_vocabulary_returns_failure(self):
        with patch("sys.argv", ["check_vocabulary_drift.py", "--vocab", "/missing/vocabulary.yaml", "--terms", "term"]):
            with contextlib.redirect_stderr(io.StringIO()):
                self.assertEqual(check_vocabulary_main(), 1)

    def test_coverage_reports_unconsumed_source(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            db_path = Path(temp_dir) / "trace.sqlite"
            with sqlite3.connect(db_path) as connection:
                connection.execute(
                    "CREATE TABLE legacy_traces (p_id TEXT, doc_name TEXT, section TEXT, "
                    "text TEXT, status TEXT)"
                )
                connection.execute(
                    "INSERT INTO legacy_traces VALUES ('P-1', 'a.docx', 'TOP', 'body', 'UNUSED')"
                )
            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                result = check_coverage(str(db_path), "a.docx")
            self.assertEqual(result, 1)
            self.assertIn("未消化(UNUSED): 1", output.getvalue())


if __name__ == "__main__":
    unittest.main()
