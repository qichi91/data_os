#!/usr/bin/env python3
"""Shared stdin JSON contract for configured specification agents."""

import json
import os
import shlex
import subprocess
from pathlib import Path


def run_agent(payload: dict, cwd: Path | None = None) -> None:
    configured = os.environ.get("SPEC_AGENT_COMMAND", "").strip()
    if not configured:
        raise RuntimeError(
            "SPEC_AGENT_COMMAND is not configured. Set it to an executable that reads the JSON "
            "request from stdin and exits non-zero on failure."
        )
    command = shlex.split(configured)
    if not command:
        raise RuntimeError("SPEC_AGENT_COMMAND must not be empty")

    result = subprocess.run(
        command,
        cwd=cwd,
        input=json.dumps(payload, ensure_ascii=False),
        capture_output=True,
        text=True,
        check=False,
    )
    if result.stdout:
        print(result.stdout, end="")
    if result.returncode:
        if result.stderr:
            import sys

            print(result.stderr, file=sys.stderr, end="")
        raise RuntimeError(f"specification agent failed with exit code {result.returncode}")
