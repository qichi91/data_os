#!/usr/bin/env python3
"""Prepare a spec-generation issue, invoke the configured agent, validate, and open a PR."""

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path

from agent_protocol import run_agent


ROOT = Path(__file__).resolve().parents[1]
TRACE_DB = "docs/extraction_trace/trace_db.sqlite"


def log(step: str, message: str) -> None:
    print(f"\n[ORCHESTRATOR][{step}] {message}", flush=True)


def run_cmd(command: list[str], check: bool = True) -> subprocess.CompletedProcess:
    log("EXEC", " ".join(command))
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, check=False)
    if result.stdout:
        print(result.stdout, end="")
    if result.returncode and result.stderr:
        print(result.stderr, file=sys.stderr, end="")
    if check and result.returncode:
        raise RuntimeError(f"Command failed with exit code {result.returncode}: {command[0]}")
    return result


def parse_issue_body(body: str) -> dict[str, str]:
    fields = {
        "module": "新モジュール名",
        "function": "機能名",
        "uc_id": "対象ユースケースID",
        "doc_path": "主仕様書（Word）",
        "excel_path": "データ仕様（Excel等）",
        "section": "原本抽出対象セクション",
    }
    info = {key: "" for key in fields}
    for key, label in fields.items():
        match = re.search(
            rf"^\s*-\s*\*\*{re.escape(label)}\*\*:\s*`?([^`\n]*)`?\s*$",
            body,
            flags=re.MULTILINE,
        )
        if match:
            info[key] = match.group(1).strip()
    info["uc_id"] = info["uc_id"] or "UC-001"
    ready = re.search(r"^\s*-\s*\[[xX]\]\s*エージェント実行準備完了", body, re.MULTILINE)
    info["ready"] = "true" if ready else "false"
    return info


def safe_component(value: str, label: str) -> str:
    if not re.fullmatch(r"[\w-]+", value, flags=re.UNICODE):
        raise ValueError(f"{label} must contain only letters, numbers, '_' or '-': {value!r}")
    return value


def changed_paths() -> set[str]:
    result = run_cmd(["git", "status", "--porcelain=v1", "-z", "--untracked-files=all"])
    return {
        record[3:]
        for record in result.stdout.split("\0")
        if record
    }


def repo_file(path_value: str) -> Path:
    candidate = (ROOT / path_value).resolve()
    if candidate != ROOT and ROOT not in candidate.parents:
        raise ValueError(f"source path must be inside the repository: {path_value}")
    if not candidate.is_file():
        raise ValueError(f"source file not found: {path_value}")
    return candidate


def invoke_agent(meta: dict[str, str], issue_num: int, out_dir: Path, source: Path) -> None:
    payload = {
        "task": "generate_spec",
        "issue": issue_num,
        "module": meta["module"],
        "function": meta["function"],
        "uc_id": meta["uc_id"],
        "source_docx": str(source.relative_to(ROOT)),
        "section": meta["section"],
        "output_dir": str(out_dir.relative_to(ROOT)),
        "trace_db": TRACE_DB,
        "skills": [
            ".coder/skills/01_doc_trace_extract/SKILL.md",
            ".coder/skills/02_domain_vocabulary/SKILL.md",
            ".coder/skills/03_iconix_modeling/SKILL.md",
        ],
    }
    log("AGENT", f"Invoking configured agent for Issue #{issue_num}")
    try:
        run_agent(payload, cwd=ROOT)
    except OSError as error:
        raise RuntimeError(f"unable to start specification agent: {error}") from error


def update_issue_error(issue_num: int, error: Exception) -> None:
    comment = f"【エラー】自動生成処理に失敗しました:\n```\n{error}\n```"
    run_cmd(["tea", "issue", "comment", str(issue_num), comment])
    run_cmd([
        "tea", "issue", "edit", str(issue_num),
        "--remove-labels", "status:in-progress",
        "--add-labels", "status:error",
    ])


def execute_issue(issue_num: int) -> None:
    if issue_num <= 0:
        raise ValueError("issue number must be positive")

    status = run_cmd(["git", "status", "--porcelain", "--untracked-files=all"])
    if status.stdout.strip():
        raise RuntimeError("refusing to run with a dirty worktree; preserve or commit existing changes first")

    issue_result = run_cmd(["tea", "issue", "show", str(issue_num), "--output", "json"])
    issue_data = json.loads(issue_result.stdout)
    if not isinstance(issue_data, dict) or not isinstance(issue_data.get("body"), str):
        raise ValueError(f"Gitea returned an invalid Issue payload for #{issue_num}")
    meta = parse_issue_body(issue_data["body"])
    if not (meta["module"] and meta["function"] and meta["doc_path"]):
        raise ValueError("Issue body is missing required module, function, or Word source path")
    if meta["ready"] != "true":
        raise ValueError("Issue is not marked 'エージェント実行準備完了'")
    module = safe_component(meta["module"], "module")
    function = safe_component(meta["function"], "function")
    if not re.fullmatch(r"UC-\d{3}", meta["uc_id"]):
        raise ValueError(f"invalid use-case ID: {meta['uc_id']!r}")
    source = repo_file(meta["doc_path"])
    if source.suffix.lower() != ".docx":
        raise ValueError("only Word .docx sources are supported; Excel input is not processed")

    branch_name = f"feature/{module}-{function}"
    out_dir = (ROOT / "docs/design" / module / function).resolve()
    if ROOT not in out_dir.parents:
        raise ValueError(f"spec output path must be inside the repository: {out_dir}")

    run_cmd([
        "tea", "issue", "edit", str(issue_num),
        "--remove-labels", "status:queued",
        "--add-labels", "status:in-progress",
    ])
    try:
        run_cmd(["git", "switch", "main"])
        run_cmd(["git", "pull", "--ff-only", "origin", "main"])
        run_cmd(["git", "switch", "-c", branch_name])
        run_cmd([
            "python3", "scripts/parse_legacy_docs.py",
            "--input", str(source.relative_to(ROOT)),
            "--db", TRACE_DB,
            *(["--section", meta["section"]] if meta["section"] else []),
        ])
        out_dir_relative = str(out_dir.relative_to(ROOT))
        invoke_agent(meta, issue_num, out_dir, source)

        allowed_roots = (
            out_dir_relative,
            "docs/extraction_trace/",
            "docs/glossary/",
        )
        unexpected = {
            path for path in changed_paths()
            if not any(path == root or path.startswith(root.rstrip("/") + "/") for root in allowed_roots)
        }
        if unexpected:
            raise RuntimeError(
                "agent modified files outside its generation scope: " + ", ".join(sorted(unexpected))
            )

        spec_files = sorted(out_dir.glob("*.spec.yaml"))
        diagram_files = sorted((out_dir / "diagrams").glob("*.puml"))
        if not spec_files or not diagram_files:
            raise RuntimeError(
                f"agent did not produce both spec YAML and PlantUML diagrams under {out_dir}"
            )
        run_cmd([
            "python3", "scripts/validate_spec_yaml.py", "--schemas", "schemas",
            "--design-dir", out_dir_relative, "--trace-db", TRACE_DB,
        ])
        run_cmd(["python3", "scripts/lint_plantuml.py", out_dir_relative])

        coverage = run_cmd([
            "python3", "scripts/check_trace_coverage.py", TRACE_DB,
            "--doc-name", source.name,
        ], check=False)
        if coverage.returncode not in (0, 1):
            raise RuntimeError("trace coverage check failed; refusing to create a PR")
        coverage_text = coverage.stdout
        warning = (
            "【要確認】原本から未消化の文章が存在します。\n\n"
            if coverage.returncode else ""
        )

        run_cmd(["git", "add", out_dir_relative, TRACE_DB, "docs/glossary/"])
        staged = run_cmd(["git", "diff", "--cached", "--quiet"], check=False)
        if staged.returncode == 0:
            raise RuntimeError("agent completed without producing staged changes")
        if staged.returncode != 1:
            raise RuntimeError(f"unable to inspect staged changes (exit {staged.returncode})")
        run_cmd([
            "git", "commit", "-m",
            f"docs: generate internal spec for {module}/{function} (refs #{issue_num})\n\n"
            "Co-authored-by: Copilot <223556219+Copilot@users.noreply.github.com>",
        ])
        run_cmd(["git", "push", "-u", "origin", branch_name])

        pr_title = f"[SPEC] {module} - {function} 内部仕様 (#{issue_num})"
        pr_description = (
            f"{warning}## 機能内部仕様書 自動生成レポート\n\n"
            f"- **元Issue**: #{issue_num}\n"
            f"- **モジュール**: `{module}`\n"
            f"- **機能**: `{function}`\n\n"
            f"### 原本トレース検証\n```text\n{coverage_text}```\n"
        )
        run_cmd([
            "tea", "pr", "create", "--title", pr_title,
            "--description", pr_description, "--base", "main", "--head", branch_name,
        ])
        run_cmd([
            "tea", "issue", "comment", str(issue_num),
            f"仕様書ブランチ `{branch_name}` からPRを起票しました。レビューをお願いします。",
        ])
        run_cmd([
            "tea", "issue", "edit", str(issue_num),
            "--remove-labels", "status:in-progress",
            "--add-labels", "status:needs-review",
        ])
    except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as error:
        log("ERROR", str(error))
        update_issue_error(issue_num, error)
        raise


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--issue", type=int, required=True, help="Target Gitea Issue number")
    args = parser.parse_args()
    try:
        execute_issue(args.issue)
    except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as error:
        print(f"Orchestration failed: {error}", file=sys.stderr)
        return 1
    log("FINISH", "Successfully generated specification and created PR")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
