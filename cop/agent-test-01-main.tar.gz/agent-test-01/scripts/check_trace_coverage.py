#!/usr/bin/env python3
"""追跡DBを検証し、未採用(UNUSED)の文章をレポートして未消化の仕様漏れを防ぐ"""

import argparse
import sqlite3
import sys
from pathlib import Path

def check_coverage(db_path: str, doc_name: str | None = None):
    if not Path(db_path).is_file():
        raise FileNotFoundError(f"trace database not found: {db_path}")
    conn = sqlite3.connect(db_path)
    try:
        cur = conn.cursor()

        where = " WHERE doc_name = ?" if doc_name else ""
        params = (doc_name,) if doc_name else ()
        cur.execute(f"SELECT COUNT(*) FROM legacy_traces{where}", params)
        total = cur.fetchone()[0]

        cur.execute(f"SELECT COUNT(*) FROM legacy_traces{where + ' AND' if where else ' WHERE'} status = 'USED'", params)
        used = cur.fetchone()[0]

        cur.execute(f"SELECT COUNT(*) FROM legacy_traces{where + ' AND' if where else ' WHERE'} status = 'DISCARDED'", params)
        discarded = cur.fetchone()[0]

        cur.execute(
            f"SELECT p_id, section, text FROM legacy_traces"
            f"{where + ' AND' if where else ' WHERE'} status = 'UNUSED' ORDER BY p_id",
            params,
        )
        unused_rows = cur.fetchall()
    finally:
        conn.close()

    print(f"=== トレース網羅率レポート ===")
    if doc_name:
        print(f"対象原本: {doc_name}")
    print(f"原本総段落数: {total}")
    print(f"採用済み(USED): {used}")
    print(f"明示的除外(DISCARDED): {discarded}")
    print(f"未消化(UNUSED): {len(unused_rows)}")

    if unused_rows:
        print("\n【警告】以下の仕様文章が採用も除外もされていません（抜け漏れの恐れあり）:")
        for r in unused_rows[:10]:
            print(f"- [{r[0]}] ({r[1]}): {r[2][:40]}...")
        if len(unused_rows) > 10:
            print(f"... 他 {len(unused_rows) - 10} 件")
        return 1
    return 0

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Report unused source paragraphs")
    parser.add_argument("db", nargs="?", default="docs/extraction_trace/trace_db.sqlite")
    parser.add_argument("--doc-name", help="Limit the report to one imported source document")
    args = parser.parse_args()
    try:
        raise SystemExit(check_coverage(args.db, args.doc_name))
    except (OSError, sqlite3.Error) as error:
        print(f"Trace coverage check failed: {error}", file=sys.stderr)
        raise SystemExit(2)