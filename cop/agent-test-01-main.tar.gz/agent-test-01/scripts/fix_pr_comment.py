#!/usr/bin/env python3
"""Apply a supplied PR comment only to explicitly allowed files, then validate and push."""

import argparse
import subprocess
import sys
from pathlib import Path

from agent_protocol import run_agent


ROOT = Path(__file__).resolve().parents[1]


def command(args: list[str], check: bool = True):
    result = subprocess.run(args, cwd=ROOT, capture_output=True, text=True, check=False)
    if result.stdout:
        print(result.stdout, end="")
    if result.returncode and result.stderr:
        print(result.stderr, file=sys.stderr, end="")
    if check and result.returncode:
        raise RuntimeError(f"command failed with exit code {result.returncode}: {args[0]}")
    return result


def changed_paths() -> set[str]:
    result = command(["git", "status", "--porcelain=v1", "-z", "--untracked-files=all"])
    paths = set()
    for record in result.stdout.split("\0"):
        if record:
            paths.add(record[3:])
    return paths


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pr", type=int, required=True, help="Gitea PR number")
    parser.add_argument("--comment", help="Review comment text")
    parser.add_argument("--comment-file", help="UTF-8 file containing the review comment")
    parser.add_argument(
        "--file",
        action="append",
        required=True,
        dest="allowed_files",
        help="Repository-relative file the agent is permitted to change (repeatable)",
    )
    args = parser.parse_args()
    if args.pr <= 0 or bool(args.comment) == bool(args.comment_file):
        parser.error("provide a positive --pr and exactly one of --comment or --comment-file")

    try:
        comment = args.comment if args.comment is not None else Path(args.comment_file).read_text(encoding="utf-8")
        allowed = set()
        for value in args.allowed_files:
            path = (ROOT / value).resolve()
            if path == ROOT or ROOT not in path.parents:
                raise ValueError(f"allowed path must be inside the repository: {value}")
            relative = path.relative_to(ROOT).as_posix()
            tracked = command(["git", "ls-files", "--error-unmatch", "--", relative], check=False)
            if tracked.returncode:
                raise ValueError(f"allowed path is not a tracked repository file: {value}")
            allowed.add(relative)
        if not comment.strip():
            raise ValueError("review comment must not be empty")
        if changed_paths():
            raise RuntimeError("refusing to run with a dirty worktree; preserve or commit existing changes first")

        payload = {
            "task": "fix_pr_comment",
            "pr": args.pr,
            "comment": comment,
            "allowed_files": sorted(allowed),
            "skills": [".coder/skills/05_pr_diff_fixer/SKILL.md"],
        }
        run_agent(payload, cwd=ROOT)

        changed = changed_paths()
        outside = changed - allowed
        if outside:
            raise RuntimeError(
                "agent modified files outside the allowed set; no commit or push was performed: "
                + ", ".join(sorted(outside))
            )
        if not changed:
            raise RuntimeError("agent completed without modifying any allowed file")

        command(["git", "diff", "--check"])
        command([
            "python3", "scripts/validate_spec_yaml.py",
            "--schemas", "schemas", "--design-dir", "docs/design",
            "--trace-db", "docs/extraction_trace/trace_db.sqlite",
        ])
        command(["python3", "scripts/lint_plantuml.py", "docs/design"])
        coverage = command(
            ["python3", "scripts/check_trace_coverage.py", "docs/extraction_trace/trace_db.sqlite"],
            check=False,
        )
        if coverage.returncode not in (0, 1):
            raise RuntimeError("trace coverage check failed; refusing to commit or push")

        command(["git", "add", "--", *sorted(allowed)])
        command([
            "git", "commit", "-m",
            f"docs: address review feedback for PR #{args.pr}\n\n"
            "Co-authored-by: Copilot <223556219+Copilot@users.noreply.github.com>",
        ])
        command(["git", "push", "origin", "HEAD"])
        message = f"レビュー指摘に対応しました。変更ファイル: {', '.join(sorted(changed))}"
        if coverage.returncode:
            message += "\n\n原本トレースに未消化段落があります。確認してください。"
        command(["tea", "issue", "comment", str(args.pr), message])
    except (OSError, RuntimeError, ValueError) as error:
        print(f"PR feedback handling failed: {error}", file=sys.stderr)
        return 1
    print(f"Applied review feedback for PR #{args.pr}.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
