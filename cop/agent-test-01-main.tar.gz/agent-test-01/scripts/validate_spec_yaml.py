#!/usr/bin/env python3
"""Validate spec YAML fields against the repository's Table Spec Editor schema."""

import argparse
import re
import sqlite3
import sys
from pathlib import Path

import yaml


def is_scaffold_file(path: Path) -> bool:
    return "module_name" in path.parts and "feature_name" in path.parts


def validate_rows(rows, fields, path: str, errors: list[str]) -> None:
    if not isinstance(rows, list):
        errors.append(f"{path}: expected a list")
        return
    for index, row in enumerate(rows):
        row_path = f"{path}[{index}]"
        if not isinstance(row, dict):
            errors.append(f"{row_path}: expected a mapping")
            continue
        validate_mapping(row, fields, row_path, errors)


def validate_mapping(data, fields, path: str, errors: list[str]) -> None:
    if not isinstance(data, dict):
        errors.append(f"{path}: expected a mapping")
        return
    for field in fields:
        key = field["key"]
        value = data.get(key)
        if field.get("required") and (value is None or value == ""):
            errors.append(f"{path}.{key}: required value is missing")
            continue
        if value is None or value == "":
            continue
        field_type = field.get("type")
        if field_type in ("string", "multiline", "select") and not isinstance(value, str):
            errors.append(f"{path}.{key}: expected a string")
            continue
        pattern = field.get("pattern")
        if pattern and not re.fullmatch(pattern, str(value)):
            errors.append(f"{path}.{key}: {field.get('pattern_error', 'invalid format')}")
        options = field.get("options")
        if field.get("options_strict") and options and value not in options:
            errors.append(f"{path}.{key}: {value!r} is not one of {options!r}")


def validate_spec(data, schema, source: str, trace_ids: set[str] | None = None) -> list[str]:
    errors = []
    if not isinstance(data, dict):
        return [f"{source}: document root must be a mapping"]

    validate_mapping(data, schema.get("headers", []), source, errors)
    columns = schema.get("columns", [])
    if "items" not in data:
        errors.append(f"{source}.items: required list is missing")
    else:
        validate_rows(data["items"], columns, f"{source}.items", errors)
    if trace_ids is not None:
        for collection in ("items", *(table["data_key"] for table in schema.get("subtables", []))):
            rows = data.get(collection, [])
            if isinstance(rows, list):
                for index, row in enumerate(rows):
                    if isinstance(row, dict) and row.get("source_p_id") and row["source_p_id"] not in trace_ids:
                        errors.append(
                            f"{source}.{collection}[{index}].source_p_id: "
                            f"unknown trace ID {row['source_p_id']!r}"
                        )
    for subtable in schema.get("subtables", []):
        key = subtable["data_key"]
        validate_rows(data.get(key, []), subtable.get("columns", []), f"{source}.{key}", errors)
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    schema_group = parser.add_mutually_exclusive_group(required=True)
    schema_group.add_argument("--schema")
    schema_group.add_argument("--schemas", help="Directory containing *.schema.yaml files")
    parser.add_argument("--input", nargs="+")
    parser.add_argument("--design-dir", help="Validate all YAML specs under this directory")
    parser.add_argument("--trace-db", help="Also verify source_p_id values against this trace database")
    args = parser.parse_args()

    try:
        if args.input and args.design_dir:
            parser.error("--input and --design-dir cannot be used together")
        if not args.input and not args.design_dir:
            parser.error("either --input or --design-dir is required")
        if args.schema:
            schemas = [yaml.safe_load(Path(args.schema).read_text(encoding="utf-8"))]
        else:
            schemas = [
                yaml.safe_load(path.read_text(encoding="utf-8"))
                for path in sorted(Path(args.schemas).glob("*.schema.yaml"))
            ]
        if not schemas or any(not isinstance(schema, dict) for schema in schemas):
            raise ValueError("schema files must contain YAML mappings")
        schemas_by_id = {schema.get("schema_id"): schema for schema in schemas if schema.get("schema_id")}
        files = (
            [Path(file_name) for file_name in args.input]
            if args.input
            else sorted(
                path for path in Path(args.design_dir).rglob("*.yaml")
                if not is_scaffold_file(path)
            )
        )
        if not files:
            raise ValueError("no spec YAML files found")
        trace_ids = None
        if args.trace_db:
            if not Path(args.trace_db).is_file():
                raise ValueError(f"trace database not found: {args.trace_db}")
            with sqlite3.connect(args.trace_db) as conn:
                trace_ids = {row[0] for row in conn.execute("SELECT p_id FROM legacy_traces")}

        errors = []
        for path in files:
            data = yaml.safe_load(path.read_text(encoding="utf-8"))
            schema_id = data.get("schema") if isinstance(data, dict) else None
            if schema_id is None and isinstance(data, dict):
                schema_id = "usecase" if "uc_id" in data else "datamodel" if "model_id" in data else None
            schema = schemas_by_id.get(schema_id)
            if schema is None and args.schema:
                schema = schemas[0]
            if schema is None:
                errors.append(f"{path}: no matching schema found (schema={schema_id!r})")
            else:
                errors.extend(validate_spec(data, schema, str(path), trace_ids))
    except sqlite3.Error as exc:
        print(f"Trace database validation failed: {exc}", file=sys.stderr)
        return 1
    except (OSError, yaml.YAMLError, ValueError) as exc:
        print(f"YAML validation failed: {exc}", file=sys.stderr)
        return 1

    if errors:
        print("\n".join(errors), file=sys.stderr)
        return 1
    print(f"Validated {len(files)} spec YAML file(s).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
