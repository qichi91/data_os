#!/usr/bin/env python3
"""Word (.docx) paragraphs into the traceability database."""

import argparse
from pathlib import Path
import sqlite3

from docx import Document

def init_db(db_path: str):
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("""
    CREATE TABLE IF NOT EXISTS legacy_traces (
        p_id TEXT PRIMARY KEY,
        doc_name TEXT,
        section TEXT,
        text TEXT,
        status TEXT DEFAULT 'UNUSED',
        used_in_uc TEXT,
        discard_reason TEXT
    )
    """)
    conn.commit()
    return conn

def parse_docx(file_path: str, conn: sqlite3.Connection, section: str | None = None):
    doc = Document(file_path)
    doc_name = Path(file_path).name
    cur = conn.cursor()
    current_sec = "TOP"
    seq = 1

    for p in doc.paragraphs:
        txt = p.text.strip()
        if not txt:
            continue
        if p.style.name.startswith("Heading"):
            current_sec = txt
            continue

        p_id = f"{doc_name[:8]}-{current_sec[:6]}-{seq:04d}"
        seq += 1
        if section and section.casefold() not in current_sec.casefold():
            continue

        existing = cur.execute(
            "SELECT doc_name, text, status FROM legacy_traces WHERE p_id = ?",
            (p_id,),
        ).fetchone()
        if existing and existing[0] != doc_name:
            raise ValueError(
                f"source paragraph ID collision for {p_id}: {existing[0]!r} and {doc_name!r}"
            )
        if existing and existing[1] != txt:
            if existing[2] != "UNUSED":
                raise ValueError(
                    f"source paragraph {p_id} changed after being marked {existing[2]}; "
                    "review its trace assignment before re-importing"
                )
            cur.execute(
                "UPDATE legacy_traces SET section = ?, text = ? WHERE p_id = ?",
                (current_sec, txt, p_id),
            )
        elif not existing:
            cur.execute("""
            INSERT INTO legacy_traces (p_id, doc_name, section, text, status)
            VALUES (?, ?, ?, ?, 'UNUSED')
            """, (p_id, doc_name, current_sec, txt))

    conn.commit()

def main():
    parser = argparse.ArgumentParser(description="Import Word paragraphs into the trace database")
    parser.add_argument("--input", required=True, help="Path to a .docx file")
    parser.add_argument("--db", default="docs/extraction_trace/trace_db.sqlite")
    parser.add_argument("--section", help="Only import paragraphs under headings containing this text")
    args = parser.parse_args()

    input_path = Path(args.input)
    if input_path.suffix.lower() != ".docx":
        parser.error("only .docx input is supported; Excel import is not implemented")
    if not input_path.is_file():
        parser.error(f"input file not found: {input_path}")

    conn = init_db(args.db)
    try:
        parse_docx(str(input_path), conn, args.section)
    finally:
        conn.close()
    print(f"Parsed {input_path} into {args.db}")

if __name__ == "__main__":
    try:
        main()
    except (OSError, sqlite3.Error, ValueError) as error:
        raise SystemExit(f"Document import failed: {error}")