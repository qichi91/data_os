#!/usr/bin/env python3
"""Assign an imported source paragraph to a use case or explicitly discard it."""

import argparse
import re
import sqlite3
import sys
from pathlib import Path


def update_status(db_path: str, p_id: str, status: str, uc_id: str | None, reason: str | None) -> None:
    if status not in ("USED", "DISCARDED"):
        raise ValueError("status must be USED or DISCARDED")
    if status == "USED" and not uc_id:
        raise ValueError("--uc-id is required when status is USED")
    if status == "USED" and not re.fullmatch(r"UC-\d{3}", uc_id):
        raise ValueError("--uc-id must use the UC-001 format")
    if status == "DISCARDED" and not reason:
        raise ValueError("--reason is required when status is DISCARDED")
    if reason is not None and not reason.strip():
        raise ValueError("--reason must not be blank")
    if not Path(db_path).is_file():
        raise ValueError(f"trace database not found: {db_path}")

    with sqlite3.connect(db_path) as conn:
        cur = conn.execute("SELECT status FROM legacy_traces WHERE p_id = ?", (p_id,))
        row = cur.fetchone()
        if row is None:
            raise ValueError(f"unknown source paragraph ID: {p_id}")
        if row[0] not in ("UNUSED", status):
            raise ValueError(f"cannot change terminal status {row[0]} to {status} for {p_id}")

        conn.execute(
            """
            UPDATE legacy_traces
            SET status = ?, used_in_uc = ?, discard_reason = ?
            WHERE p_id = ?
            """,
            (status, uc_id if status == "USED" else None,
             reason if status == "DISCARDED" else None, p_id),
        )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", default="docs/extraction_trace/trace_db.sqlite")
    parser.add_argument("--p-id", required=True)
    parser.add_argument("--status", required=True, choices=("USED", "DISCARDED"))
    parser.add_argument("--uc-id", help="Use-case ID that consumes this paragraph")
    parser.add_argument("--reason", help="Reason for explicitly discarding this paragraph")
    args = parser.parse_args()

    try:
        update_status(args.db, args.p_id, args.status, args.uc_id, args.reason)
    except (sqlite3.Error, ValueError) as exc:
        print(f"Trace update failed: {exc}", file=sys.stderr)
        return 1
    print(f"Updated {args.p_id}: {args.status}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
