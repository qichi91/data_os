#!/usr/bin/env python3
"""PlantUMLファイルのICONIX構文チェック（バウンダリ・エンティティ直接接続禁止など）"""

import re
import shutil
import subprocess
import sys
from pathlib import Path

def lint_robustness(content: str) -> list[str]:
    errors = []
    # バウンダリ・エンティティ・コントローラの抽出
    boundaries = set(re.findall(r'boundary\s+["\']?([^"\'\n]+)["\']?\s+as\s+(\w+)', content))
    entities = set(re.findall(r'entity\s+["\']?([^"\'\n]+)["\']?\s+as\s+(\w+)', content))
    
    b_aliases = {b[1] for b in boundaries} | {b[0] for b in boundaries}
    e_aliases = {e[1] for e in entities} | {e[0] for e in entities}

    # 接続の検査 (A --> B, A ..> B 等)
    links = re.findall(r'(\w+)\s*(?:-->|--|\.\.>)\s*(\w+)', content)
    for src, dst in links:
        # Boundary同士の直接接続
        if src in b_aliases and dst in b_aliases:
            errors.append(f"ICONIX違反: バウンダリ同士が直接接続されています ({src} -> {dst})")
        # Entity同士の直接接続
        if src in e_aliases and dst in e_aliases:
            errors.append(f"ICONIX違反: エンティティ同士が直接接続されています ({src} -> {dst})")
        # BoundaryとEntityの直接接続
        if (src in b_aliases and dst in e_aliases) or (src in e_aliases and dst in b_aliases):
            errors.append(f"ICONIX違反: バウンダリとエンティティが直接接続されています ({src} <-> {dst})。コントローラを経由してください。")

    return errors

def lint_file(file_path: Path) -> list[str]:
    content = file_path.read_text(encoding="utf-8")
    if not (content.startswith("@startuml") and content.strip().endswith("@enduml")):
        return [f"{file_path}: @startuml または @enduml が存在しません"]
    
    if "robustness" in file_path.name:
        return [f"{file_path}: {err}" for err in lint_robustness(content)]
    return []

def is_scaffold_file(file_path: Path) -> bool:
    parts = file_path.parts
    return "module_name" in parts and "feature_name" in parts

def main():
    if len(sys.argv) < 2:
        print("Usage: python lint_plantuml.py <dir_or_file>")
        sys.exit(1)

    target = Path(sys.argv[1])
    files = list(target.glob("**/*.puml")) if target.is_dir() else [target]
    files = [path for path in files if not is_scaffold_file(path)]

    all_errors = []
    for f in files:
        all_errors.extend(lint_file(f))

    if not target.exists():
        all_errors.append(f"{target}: path does not exist")
    if not shutil.which("plantuml"):
        all_errors.append("PlantUML executable not found; install PlantUML to validate diagram syntax")
    elif files:
        result = subprocess.run(
            ["plantuml", "-checkonly", *[str(path) for path in files]],
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode:
            output = (result.stdout + result.stderr).strip()
            all_errors.append(output or f"PlantUML syntax check failed (exit {result.returncode})")

    if all_errors:
        print("\n".join(all_errors), file=sys.stderr)
        sys.exit(1)
    else:
        print("PlantUML Lint: All checks passed.")

if __name__ == "__main__":
    main()