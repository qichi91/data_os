#!/usr/bin/env python3
"""YAMLファイルとスキーマ（またはJinja2テンプレート）を読み込み、閲覧用Markdownを生成・同期する"""

import argparse
import re
import sys
from pathlib import Path
import yaml
from jinja2 import Environment, FileSystemLoader

def render_with_schema_template(schema_path: Path, data: dict) -> str:
    with open(schema_path, "r", encoding="utf-8") as f:
        schema = yaml.safe_load(f)

    template_str = schema.get("markdown_template", "")
    if not template_str:
        raise ValueError(f"Schema {schema_path} does not have 'markdown_template'")

    # mustache風のタグ {{#items}} ... {{/items}} を jinja2形式の {% for item in items %} ... {% endfor %} に簡易変換
    j2_str = re.sub(r'\{\{#(\w+)\}\}', r'{% for item in \1 %}', template_str)
    j2_str = re.sub(r'\{\{/(\w+)\}\}', r'{% endfor %}', j2_str)
    
    # プレースホルダーの置換: {{field}} -> {{item.field}} (itemsループ内想定対応)
    for col in schema.get("columns", []):
        k = col["key"]
        j2_str = j2_str.replace(f"{{{{{k}}}}}", f"{{{{item.{k}}}}}")

    # ヘッダーフィールドの置換
    for hdr in schema.get("headers", []):
        k = hdr["key"]
        j2_str = j2_str.replace(f"{{{{{k}}}}}", f"{{{{{k}}}}}")

    env = Environment()
    template = env.from_string(j2_str)
    return template.render(**data)

def main():
    parser = argparse.ArgumentParser(description="Convert Spec YAML to Markdown")
    parser.add_argument("--schema", required=False, help="Path to schema.yaml (if using schema markdown_template)")
    parser.add_argument("--template", required=False, help="Path to jinja2 template file")
    parser.add_argument("--input", required=True, help="Input YAML file")
    parser.add_argument("--output", required=True, help="Output Markdown file")
    args = parser.parse_args()

    input_path = Path(args.input)
    output_path = Path(args.output)

    with open(input_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    if args.template:
        tmpl_path = Path(args.template)
        env = Environment(loader=FileSystemLoader(str(tmpl_path.parent)))
        template = env.get_template(tmpl_path.name)
        rendered_md = template.render(**data)
    elif args.schema:
        rendered_md = render_with_schema_template(Path(args.schema), data)
    else:
        print("Error: Either --schema or --template must be specified", file=sys.stderr)
        sys.exit(1)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(rendered_md)

    print(f"Successfully generated Markdown: {output_path}")

if __name__ == "__main__":
    main()