#!/usr/bin/env python3
"""抽出された名詞とプロジェクト統合用語集(vocabulary.yaml)を突き合わせ、表記ゆれや新規候補を判定する"""

import argparse
import sys
from pathlib import Path
import yaml

def load_vocabulary(vocab_path: Path) -> dict:
    if not vocab_path.exists():
        raise FileNotFoundError(f"vocabulary file not found: {vocab_path}")
    with open(vocab_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    if not isinstance(data, dict) or not isinstance(data.get("items"), list):
        raise ValueError(f"{vocab_path} must contain an 'items' list")
    for index, entry in enumerate(data["items"]):
        if not isinstance(entry, dict) or not isinstance(entry.get("term"), str) or not entry["term"]:
            raise ValueError(f"{vocab_path}: items[{index}] must have a non-empty term")
    return data

def main() -> int:
    parser = argparse.ArgumentParser(description="Check domain vocabulary consistency and drift")
    parser.add_argument("--vocab", default="docs/glossary/vocabulary.yaml", help="Path to vocabulary.yaml")
    parser.add_argument("--terms", required=True, help="Comma-separated extracted terms to check")
    args = parser.parse_args()

    try:
        vocab_data = load_vocabulary(Path(args.vocab))
    except (OSError, yaml.YAMLError, ValueError) as error:
        print(f"Vocabulary check failed: {error}", file=sys.stderr)
        return 1
    items = vocab_data.get("items", [])

    term_to_entry = {entry["term"]: entry for entry in items}
    alias_to_term = {}
    for entry in items:
        aliases_str = entry.get("aliases", "")
        if not isinstance(aliases_str, str):
            print(f"Vocabulary check failed: aliases for {entry['term']!r} must be a string", file=sys.stderr)
            return 1
        if aliases_str:
            for alias in [a.strip() for a in aliases_str.split(",") if a.strip()]:
                alias_to_term[alias] = entry["term"]

    extracted_terms = [t.strip() for t in args.terms.split(",") if t.strip()]

    exact_matches = []
    alias_hits = []
    new_candidates = []

    for term in extracted_terms:
        if term in term_to_entry:
            exact_matches.append(term)
        elif term in alias_to_term:
            alias_hits.append((term, alias_to_term[term]))
        else:
            new_candidates.append(term)

    print("=== 用語集クロスチェック結果 ===")
    print(f"【承認済み用語に合致】: {len(exact_matches)} 件")
    for t in exact_matches:
        print(f"  - {t}")

    print(f"\n【表記ゆれ検知（正式用語へ要置換）】: {len(alias_hits)} 件")
    for old_term, canon_term in alias_hits:
        print(f"  - '{old_term}' -> 正本: '{canon_term}'")

    print(f"\n【新規用語候補（未登録・要確認）】: {len(new_candidates)} 件")
    for cand in new_candidates:
        print(f"  - {cand}")

    # 表記ゆれや新規用語がある場合は警告メッセージを出力
    if alias_hits:
        print("\n[INFO] 表記ゆれを正本用語へ置換し、仕様書に反映してください。")
    if new_candidates:
        print("\n[WARN] 新規用語は vocabulary.yaml に CANDIDATE として追加提案してください。")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())