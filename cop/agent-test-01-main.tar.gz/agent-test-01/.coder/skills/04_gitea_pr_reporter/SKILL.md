---
name: gitea_pr_reporter
description: 生成成果物の検証（Linter/カバレッジ）を実行し、Giteaにトピックブランチ作成・PR起票・元Issue連携を行う
---

### 目的
Skill 01〜03で作成された仕様書YAML、PlantUML図、用語集の整合性を検証し、原本仕様の抜け漏れ（未消化文章）を可視化した上で、GiteaへPull Requestを自動起票します。
また、元Issueとのリンク形成やラベルの更新を行い、人間のレビュー待ち状態へ移行させます。

### 実行手順

1. **決定論的静的検証の実行**:
   - PlantUML構文およびICONIX制約の検証:
     ```bash
     python scripts/lint_plantuml.py docs/design/<モジュール名>/<機能名>/diagrams/
     ```
   - 原本文書のトレース網羅率（未消化文章）の検証:
     ```bash
     python scripts/check_trace_coverage.py docs/extraction_trace/trace_db.sqlite --doc-name "<原本ファイル名>"
     ```
   - 仕様YAMLの検証:
     ```bash
     python scripts/validate_spec_yaml.py --schemas schemas --design-dir docs/design/<モジュール名>/<機能名>/ --trace-db docs/extraction_trace/trace_db.sqlite
     ```

1. **検証結果レポートの編集**:
   - オーケストレーターが自動で作るPR本文には、Issue・モジュール・機能の概要と対象原本のトレース検証出力が含まれる。未消化段落があれば冒頭に警告を付ける。
   - Agentまたは担当者は、必要に応じて以下の補足をPR本文へ追記する：
     - **概要**: 作成した機能仕様書・ユースケースID・モジュール名
     - **未消化・要判断リスト**: `UNUSED` のまま残った段落（原本の抜け漏れ候補）を抜粋
     - **TODO・未定義事項**: 旧仕様書に記述がなく、推測を避けて `TODO` とした設計項目
     - **新規・競合用語**: `vocabulary.yaml` に新規提案された用語や表記ゆれ置換の履歴

1. **Git操作（トピックブランチ作成とPush）**:
   - 変更ファイルをステージングし、トピックブランチへコミットする。
     ```bash
     git checkout -b feature/<モジュール名>-<機能名>
     git add docs/design/<モジュール名>/<機能名>/
     git add docs/glossary/
     git add docs/extraction_trace/
     git commit -m "docs: generate internal spec for <モジュール名>-<機能名> (refs #<Issue番号>)"
     git push origin feature/<モジュール名>-<機能名>
     ```

1. **Gitea APIによるPR作成 & Issue更新**:
   - Gitea APIを呼び出し、`main` ブランチに対するPRを作成する。
   - PRのタイトル: `[SPEC] <モジュール名> - <機能名> の内部仕様作成 (#<Issue番号>)`
   - 元Issueに対する操作:
     - コメント投稿: `作成された仕様書のPR: #<PR番号> を起票しました。レビューをお願いします。`
     - ラベル更新: `status:queued` を削除し、`status:needs-review` を付与。

### 制約事項
- `lint_plantuml.py` または仕様YAML検証でエラーが出ている状態のままPRを作成してはならない。エラーが出た場合はSkill 03へ戻り修正すること。
- 未消化文章（`UNUSED`）が存在する場合でもPRの起票は許可するが、PR説明文の最上部に**「【要確認】原本から未消化の文章が存在します」**と目立つ警告を必ず明記すること。