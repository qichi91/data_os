---
name: doc_trace_extract
description: 旧Word/Excel仕様書から章節・段落を抽出して追跡DBに登録し、機能対象文を特定する
---

### 目的
指定されたWord (`.docx`) 原本を解析し、段落IDを採番して追跡DBに登録します。Excel (`.xlsx`) の取込は未対応です。

### 実行手順
1. 指定されたWordファイルパスを引数にして、以下のスクリプトを実行する。必要に応じて見出しに含まれる文字列で対象セクションを限定する。
  ```bash
  python3 scripts/parse_legacy_docs.py --input "<原本ファイルパス>" --db docs/extraction_trace/trace_db.sqlite --section "<抽出セクション>"
  ```
   `--section` を指定しない場合は全セクションを取り込みます。SQLiteの `legacy_traces` テーブルが正本です。
1. 対象機能に関係する段落IDを確認し、ユースケースの各ステップ・代替コースに `source_p_id` として記録する。
1. 採用した段落をユースケースに紐付ける。
   ```bash
   python3 scripts/update_trace_status.py --p-id "<段落ID>" --status USED --uc-id UC-001
   ```
1. 対象外と判断した段落は、理由を付けて明示的に除外する。
   ```bash
   python3 scripts/update_trace_status.py --p-id "<段落ID>" --status DISCARDED --reason "<除外理由>"
   ```
   `USED` / `DISCARDED` から別状態への直接変更はできません。原本変更後の再取込で、割当済み段落の本文が変わっている場合も取込を停止して人間の確認を求めます。
