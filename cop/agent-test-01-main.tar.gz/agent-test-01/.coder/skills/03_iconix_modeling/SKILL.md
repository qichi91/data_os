---
name: iconix_modeling
description: 抽出された要求・用語からICONIXの4図および仕様書YAML・PlantUMLを生成する
---

### 厳格な制約（妄想・ハルシネーションの禁止）
1. **旧仕様書に記述されていない挙動・リトライ回数・通信タイムアウト値・独自エラーコードを勝手に創作（補完）してはならない。**
1. 仕様書に記載のない動作が必要と判断した場合は、推測で埋めず必ず `TODO(要確認: <未定義の理由>)` と記述すること。
1. 各ユースケースの全ステップおよび代替コースには、必ず `source_p_id`（原本段落ID）を紐付けること。

### 成果物の出力規則
1. ユースケース仕様書を `docs/design/<モジュール>/<機能>/UC-XXX.spec.yaml` に出力する。
1. ロバストネス図を `docs/design/<モジュール>/<機能>/diagrams/robustness.puml` に出力する。
   - 境界ルール: Boundary - Control - Entity の接続のみ許可。Boundary同士、Entity同士の直接結合は禁止。
1. シーケンス図を `docs/design/<モジュール>/<機能>/diagrams/sequence.puml` に出力する。
1. 状態管理が必要なエンティティが存在する場合、ステートマシン図を `docs/design/<モジュール>/<機能>/diagrams/state.puml` に出力する。
1. 以下の検証スクリプトを実行してエラーがないことを確認する。
   ```bash
   python scripts/lint_plantuml.py docs/design/<モジュール>/<機能>/diagrams/
   python scripts/validate_spec_yaml.py --schemas schemas --design-dir docs/design/<モジュール>/<機能>/ --trace-db docs/extraction_trace/trace_db.sqlite
   ```
1. 各ユースケースステップ・代替コースの `source_p_id` に基づき、対応する段落を `USED` として追跡DBに記録する。対象外段落は理由を添えて `DISCARDED` にする。検証コマンドは段落IDの有効性も確認するため、先に取込済み原本を参照すること。
