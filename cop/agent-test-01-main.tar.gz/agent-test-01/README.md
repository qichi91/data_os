# ICONIX 内部仕様書駆動開発リポジトリ (Gitea ✕ Coder Agent)

旧システム仕様書をインプットとして、新アーキテクチャ向けの内部仕様書（ユースケース、ICONIX図、メッセージ/テーブル定義、状態遷移）をAIエージェントで生成し、GiteaのPR（プルリクエスト）ベースで人間がレビュー・修正するためのリポジトリです。現時点で原本取込スクリプトが対応する形式はWord (`.docx`) のみです。

---

## 1. 全体アーキテクチャと運用フロー

本リポジトリは **Issue駆動 ➔ Agent自動生成 ➔ 人間によるPRレビュー** のGitOpsサイクルで運用します。

```text
[Gitea Issue起票]
  (原本パス指定・チェックON)
         │
         ▼
[k8s CronJob / 手動キック]
  (夜間または即時実行)
         │
         ▼
[親エージェント (scripts/orchestrate_spec_issue.py)]
  ├─ 1. Word原本分解・段落ID採番 (parse_legacy_docs.py)
  ├─ 2. ICONIXモデル & YAML出力 (SPEC_AGENT_COMMANDで設定したCoder Agentアダプター)
  ├─ 3. スキーマ・PlantUML・トレース検証
  │     (validate_spec_yaml.py, lint_plantuml.py, check_trace_coverage.py)
  └─ 4. トピックブランチ作成 ＆ PR自動起票
         │
         ▼
[人間によるPRレビュー]
  ├─ 指摘あり ──► PRコメントで指示 ──► エージェントが局所Diff修正
  └─ 承認 ──────► mainブランチにマージ (status:completed)

```

---

## 2. ディレクトリ構成

```text
├── .coder/skills/               # Coder Agent用サブエージェントスキル定義
│   ├── 01_doc_trace_extract/    # Word原本分解・追跡DB登録
│   ├── 02_domain_vocabulary/    # ユビキタス言語抽出・用語集同期
│   ├── 03_iconix_modeling/      # ユースケース・ロバストネス・シーケンス生成
│   ├── 04_gitea_pr_reporter/    # 検証・レポート生成・PR起票
│   └── 05_pr_diff_fixer/        # PR指摘時の局所Diff修正（先祖返り防止）
├── .gitea/                      # Issue / PR テンプレート
├── schemas/                     # Table Spec Editor用 YAMLスキーマ
│   ├── usecase.schema.yaml      # ユースケース記述スキーマ
│   ├── datamodel.schema.yaml    # メッセージ・テーブル定義スキーマ
│   └── vocabulary.schema.yaml   # 統合用語集スキーマ
├── docs/
│   ├── original/                # 旧仕様書原本（Word / Excel）
│   ├── extraction_trace/        # 原本段落分解・トレース追跡DB (trace_db.sqlite)
│   ├── glossary/                # プロジェクト統合用語集 (正本: vocabulary.yaml)
│   └── design/                  # 新システム内部仕様書 (モジュール/機能ごと)
│       └── <モジュール>/<機能>/
│           ├── UC-XXX.spec.yaml # ユースケース正本 (Table Spec Editorで編集可能)
│           ├── UC-XXX.spec.md   # 自動生成Markdown
│           └── diagrams/        # PlantUML (robustness, sequence, state)
├── scripts/                     # 決定論的Pythonスクリプト群
├── templates/                   # Markdown展開用 Jinja2テンプレート
├── taskfile.yaml / Makefile     # 静的チェック・ビルド用タスクランナー
└── Dockerfile.agent             # Coder Workspace / 実行用コンテナ定義

```

---

## 3. 開発・実行環境のセットアップ

### 前提条件

* Docker / Docker Compose または Kubernetes (Coder Workspace)
* Python >= 3.11 (`uv` 推奨)
* PlantUML (Java, Graphviz)
* Gitea CLI (`tea`) の認証設定
* Coder Agentアダプター（下記の標準入出力契約に対応するコマンド）

### ローカルセットアップ

```bash
# 依存関係のインストール
uv pip install -e .

# CronJob/API連携で必要な場合の設定例。orchestrate_spec_issue.pyはteaの認証設定を使用します。
export GITEA_URL="http://localhost:3000"
export GITEA_TOKEN="your_personal_access_token"
export GITEA_REPO_OWNER="org"
export GITEA_REPO_NAME="my-migration-spec"

```

`scripts/orchestrate_spec_issue.py` は特定のCoder Agent SDKに直接依存しません。Agent呼出しに使うアダプターを `SPEC_AGENT_COMMAND` に設定してください。アダプターは標準入力から1つのUTF-8 JSONリクエストを読み、生成または局所修正を完了した場合のみ終了コード0を返す必要があります。非0終了ならオーケストレーターは失敗扱いにし、PR作成へ進みません。

```bash
export SPEC_AGENT_COMMAND="/path/to/coder-agent-adapter"
```

生成要求には `task: generate_spec`、Issue情報、入力Wordパス、出力先、追跡DB、使用するSKILL.mdのパスが含まれます。指摘対応では `task: fix_pr_comment` とコメント本文・変更許可ファイル一覧が渡されます。Agentへの接続が設定されていない場合は処理を明示的に失敗させます。

**原本抽出の現状範囲:** `parse_legacy_docs.py` はWord `.docx` の段落を追跡DBに取り込みます。Excel `.xlsx` の取込は未対応で、IssueにExcelパスがあっても処理しません。

---

## 4. 運用手順

### 4.0 開発環境と実運用環境の差分確認

このリポジトリには開発用のスクリプト・設定例が含まれます。実運用環境のURL、認証情報、Coderの実行方法、配置パスは環境ごとに異なるため、以下を運用環境の値に置き換えてから実行してください。認証情報はREADME、Issue、PR、ログへ記載せず、実運用環境のSecret管理機能で渡してください。

| 確認項目 | 実運用で確認・設定すること |
| --- | --- |
| リポジトリ | 対象のGitea Owner/Repository、Issueテンプレート、`main` ブランチ名が実運用と一致すること。現行オーケストレーターは `origin main` を使用します。 |
| Gitea認証 | 実行ユーザーの `tea` CLIが対象Giteaにログイン済みで、Issue参照・コメント・ラベル更新・PR作成ができること。GitのPush認証も別途確認します。`GITEA_TOKEN` 等の環境変数を設定しただけでは、`tea` のログイン設定にはなりません。 |
| Agent起動 | `SPEC_AGENT_COMMAND` に実運用環境で利用できるアダプターを設定し、標準入力JSONの受取り、`generate_spec` / `fix_pr_comment` の処理、終了コードの扱いを確認すること。 |
| 実行場所 | オーケストレーターをリポジトリのルートで実行できること。Git、Python依存関係、PlantUML/Java、`tea` が利用可能で、原本ファイルと `.coder/skills/` が同じ作業領域から参照できること。 |
| 作業領域・DB | 作業ツリーがクリーンであること。`docs/extraction_trace/trace_db.sqlite` の更新が対象ブランチに含まれること。ジョブごとに使い捨てのWorkspaceを使う場合は、実行中に同じ作業領域で生成・コミット・Pushまで完了させること。 |
| CronJob | [cronjob.yaml](./cronjob.yaml) は現状、`status:queued` のopen Issueから先頭の1件を選び `coder-agent run --issue ...` を呼ぶ例です。Issueの「実行準備完了」チェックは確認せず、オーケストレーターや `SPEC_AGENT_COMMAND` との接続も定義されていません。実運用へ適用する前に、CronJobから実際のオーケストレーターを起動する経路、Workspace認証、Secret、対象Owner/Repository、準備完了確認を含むIssue選択条件を環境担当者と合わせてください。接続確認が終わるまでは本番CronJobを有効化しないでください。 |

#### 実運用への初回導入チェックリスト

1. 実運用用のリポジトリをチェックアウトし、必要なブランチが `main` であることを確認します。処理中に `main` へ切替えてPullするため、作業ツリーはクリーンにしてください。
2. 実運用の `tea` 認証とGit Push認証を設定し、対象Issueを参照できることを確認します。テストIssueまたは担当者が指定したIssueで、Issue参照・ラベル変更・コメント・PR作成の権限を確認してください。
3. Agentアダプターを配置・設定し、ダミー入力でJSON受取り、成果物出力先、終了コード、ログ出力を確認します。アダプターが未設定・失敗した場合、仕様作成は中断されPRは作成されません。
4. Word原本をリポジトリ内に置き、実行ユーザーが読み取れることを確認します。Issueの原本パスはリポジトリルート相対で指定します。
5. `python3 scripts/lint_plantuml.py docs/design`、`python3 scripts/validate_spec_yaml.py --schemas schemas --design-dir docs/design` を実行して、PlantUMLと既存仕様を確認します。トレース検証は原本取込後に実行してください。
6. CronJobを使う場合は、まず本番スケジュールを止めた状態で手動起動相当の接続試験を行い、実運用のIssueが1件だけ処理され、PRまで作成されることを確認します。二重起動防止と失敗時の再実行担当も決めてからスケジュールを有効にします。

#### Issue実行時のチェックリスト

1. Issue本文にモジュール名、機能名、ユースケースID、Word原本パス、必要なら抽出セクションを記入します。テンプレートのチェックボックス **「エージェント実行準備完了」** をONにします。Excelは未対応です。
2. 実行担当者は、実運用用のリポジトリ・認証・Agent設定を使っていること、対象Issue番号が正しいこと、作業ツリーがクリーンであることを確認します。処理は同名ブランチを作成するため、同名ブランチが既にある場合は上書きせず停止します。
3. 運用環境で合意した手段（手動起動または動作確認済みCronJob）で実行します。手動実行ではリポジトリルートから次を実行します。
   ```bash
   python3 scripts/orchestrate_spec_issue.py --issue <Issue番号>
   ```
4. 終了後、Issueラベルが `status:needs-review` になっていること、featureブランチがPushされPRが作成されていることを確認します。PRのYAML/PlantUML検証結果と未消化段落レポートを確認します。未消化段落は警告付きでPRになりますが、仕様YAMLまたはPlantUML検証エラーがあればPRは作成されません。
5. 失敗時は、Issueの `status:error`、実行ログ、`git status`、現在のブランチ、Agentアダプターの終了状態を確認します。部分生成や途中ブランチを確認せずに同じIssueを再実行しないでください。既存ブランチ・作業変更をどう扱うかを担当者が判断し、作業ツリーを安全に整理してから再実行します。トークンなどの秘密情報がログに含まれていないことも確認してください。

### 4.1 新しい機能の仕様書を作成する場合 (新規Issue)

1. Gitea上で **「機能内部仕様書作成タスク」** テンプレートからIssueを作成します。
2. 対象モジュール名、機能名、参照するWord (`.docx`) 原本パスを記載します。Excelパスは今回の運用では処理されません。
3. `エージェント実行準備完了` のチェックボックスをONにします。
4. 手動で即時実行する場合:
```bash
python3 scripts/orchestrate_spec_issue.py --issue <Issue番号>

```

Issue本文の必須項目（モジュール名、機能名、Word原本パス）とUC IDを埋め、`エージェント実行準備完了` にチェックを入れてください。モジュール名・機能名は文字・数字・`_`・`-` を使用できます（空白やパス区切りは不可）。実行前提や失敗後の確認は「[開発環境と実運用環境の差分確認](#40-開発環境と実運用環境の差分確認)」を参照してください。

原本段落の採否は `scripts/update_trace_status.py` で記録します。採用時は `USED` とユースケースID、除外時は `DISCARDED` と理由が必須です。未消化段落はPR起票を止めず、PR本文の先頭に要確認警告を付けます。一方、YAML・PlantUML検証エラーはPR起票を止めます。



### 4.2 PRレビューと指摘対応 (局所Diff修正)

1. エージェントが自動で `feature/<モジュール>-<機能>` ブランチを切り、PRを起票します。
2. 人間はPRの差分（MarkdownやPlantUML）を確認します。
* **未消化文章（UNUSED）の確認**: PR説明文の未消化レポートを見て、漏れがないか確認します。
* **妄想（推測）の排除**: 原本にない動作は `TODO(...)` として出力されるため、チームで合意して確定させます。


3. 修正が必要な場合、PRのコメント欄に具体的に指摘します。
4. レビューコメントをテキストファイルに保存し、コメント本文とAgentが変更可能なファイルを明示して実行します。
```bash
python3 scripts/fix_pr_comment.py --pr <PR番号> \
  --comment-file /path/to/review-comment.txt \
  --file docs/design/<モジュール>/<機能>/UC-001.spec.yaml
```
   このコマンドはコメントを自動取得しません。作業ツリーがクリーンであることを要求し、許可していないファイルが変更された場合はコミット・Pushを行いません。許可ファイルが検証を通過した場合にコミット・Pushし、PRへ返信します。
5. レビューOKとなったら、PRを `main` へマージします。

---

## 5. コマンドリファレンス (Taskfile)

Task (go-task) または Make を使用して、いつでも決定論的チェックを実行できます。

| コマンド | 説明 |
| --- | --- |
| `task lint:uml` | PlantUML構文およびICONIX制約（Boundary-Entity直結禁止等）の静的検証 |
| `task check:trace` | 原本仕様書の採用網羅率・未消化段落（UNUSED）の検出 |
| `task check:vocab TERMS="〇〇"` | 指定用語が正本用語集と整合しているか検査 |
| `task validate:spec` | 設計YAMLのスキーマ項目と原本段落IDを検証 |
| `task validate:vocabulary` | 統合用語集をスキーマ検証 |
| `task sync:vocab-md` | `vocabulary.yaml` から閲覧用 `vocabulary.md` を再生成 |
| `task verify:all` | PlantUML、仕様YAML、追跡網羅性、用語集Markdownを検証・同期 |
| `task test:unit` | Python標準ライブラリのユニットテストを実行 |

Makefileにも対応ターゲット（`make lint-uml`、`make validate-spec`、`make verify-all` など）があります。いずれの総合検証も、原本が未取込、段落IDが不明、または未消化段落がある場合は失敗します。

---

## 6. 仕様記述の絶対ルール（AI・人間共通）

1. **原本にない動作を推測で埋めない**: 記述がないロジックやタイムアウト値は必ず `TODO(要確認: ...)` と記述すること。
2. **ICONIX結合ルール**: バウンダリ同士、エンティティ同士の接続は禁止。必ずコントローラを経由すること。
3. **2段落ルールの遵守**: ユースケースは基本コース（晴れの日）と代替コース（雨の日/例外系）をセットで定義すること。
4. **正本用語（ユビキタス言語）の統一**: `docs/glossary/vocabulary.yaml` に定義された語彙を使用し、表記ゆれ（旧システムの物理フラグ名など）を持ち込まないこと。
