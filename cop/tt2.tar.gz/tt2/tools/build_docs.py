import re
import yaml
from pathlib import Path

def load_order(dir_path: Path) -> list:
    order_file = dir_path / "order.yaml"
    if order_file.exists():
        with open(order_file, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
            return (data or {}).get("order", [])
    return []

def get_sorted_subdirs(parent_dir: Path) -> list:
    if not parent_dir.exists():
        return []
    configured_order = load_order(parent_dir)
    actual_subdirs = [d.name for d in parent_dir.iterdir() if d.is_dir()]
    
    sorted_names = [name for name in configured_order if name in actual_subdirs]
    remaining = sorted([name for name in actual_subdirs if name not in sorted_names])
    return [parent_dir / name for name in (sorted_names + remaining)]

def strip_frontmatter(content: str) -> str:
    """Markdownファイルの先頭にあるYAMLフロントマター（---で囲まれた部分）を除去する"""
    pattern = r'^---\s*\n.*?\n---\s*\n'
    cleaned = re.sub(pattern, '', content, flags=re.DOTALL)
    return cleaned.strip()

def build():
    root = Path(".")
    config_dir = root / "00_config"
    output_dir = root / "03_output"
    output_dir.mkdir(exist_ok=True)
    
    # 1. グローバル設定の読み込み
    global_config = {}
    global_yaml_path = config_dir / "global_layout.yaml"
    if global_yaml_path.exists():
        with open(global_yaml_path, "r", encoding="utf-8") as f:
            global_config = yaml.safe_load(f)

    combined_lines = []

    # 全体のヘッダー情報（必要に応じて）
    combined_lines.append(f"# {global_config.get('metadata', {}).get('system_name', 'システム')} 仕様書\n")
    combined_lines.append(f"Version: {global_config.get('version', '1.0.0')}\n")
    combined_lines.append("---\n")

    # 2. 機能仕様 (func_spec.md)
    func_spec_path = root / "func_spec.md"
    if func_spec_path.exists():
        raw_content = func_spec_path.read_text(encoding="utf-8")
        combined_lines.append(strip_frontmatter(raw_content))
        combined_lines.append("\n\n---\n")

    # 3. 02_features 配下の再帰的探索と結合
    features_dir = root / "02_features"
    if features_dir.exists():
        combined_lines.append("# 機能仕様\n")
        
        # カテゴリ
        for cat_dir in get_sorted_subdirs(features_dir):
            combined_lines.append(f"## カテゴリ: {cat_dir.name}\n")
            
            # 機能名
            for func_dir in get_sorted_subdirs(cat_dir):
                combined_lines.append(f"### 機能: {func_dir.name}\n")
                
                # 機能ブロック名
                for block_dir in get_sorted_subdirs(func_dir):
                    combined_lines.append(f"#### ブロック: {block_dir.name}\n")
                    
                    # 処理名
                    for proc_dir in get_sorted_subdirs(block_dir):
                        if proc_dir.is_dir():
                            combined_lines.append(f"##### 処理: {proc_dir.name}\n")
                            # 配下のmdファイル（overview.md, usecase.mdなど）を結合
                            for md_file in sorted(proc_dir.glob("*.md")):
                                raw_content = md_file.read_text(encoding="utf-8")
                                clean_content = strip_frontmatter(raw_content)
                                if clean_content:
                                    combined_lines.append(clean_content)
                                    combined_lines.append("\n")

    # 4. ファイル仕様 (file_spec.md)
    file_spec_path = root / "file_spec.md"
    if file_spec_path.exists():
        combined_lines.append("\n---\n")
        combined_lines.append("# ファイル仕様\n")
        raw_content = file_spec_path.read_text(encoding="utf-8")
        combined_lines.append(strip_frontmatter(raw_content))
        combined_lines.append("\n")

    # 5. 出力
    out_file = output_dir / "combined_features.md"
    out_file.write_text("\n".join(combined_lines), encoding="utf-8")
    print(f"Successfully generated clean Markdown: {out_file}")

if __name__ == "__main__":
    build()