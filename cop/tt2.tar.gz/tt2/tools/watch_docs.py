import time
from pathlib import Path
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from build_docs import build

class DocChangeHandler(FileSystemEventHandler):
    def on_modified(self, event):
        if event.is_directory:
            return
        if event.src_path.endswith(('.md', '.yaml', '.j2')):
            print(f"Detected change in {event.src_path}. Rebuilding...")
            try:
                build()
            except Exception as e:
                print(f"Build error: {e}")

if __name__ == "__main__":
    path = "."
    event_handler = DocChangeHandler()
    observer = Observer()
    observer.schedule(event_handler, path=path, recursive=True)
    
    print(f"Starting specification watcher on {path}...")
    observer.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()