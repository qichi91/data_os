import os
from pathlib import Path

def create_file(path: Path, content: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    print(f"Created: {path}")

def main():
    root = Path(".")

    # 1. 00_config
    create_file(root / "00_config" / "global_layout.yaml", """version: "1.0.0"
document_type: "feature_specification"
metadata:
  company: "Example Corp"
  system_name: "サンプルシステム"
""")

    create_file(root / "00_config" / "template.j2", """<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>{{ title }}</title>
    <style>
        body { font-family: sans-serif; line-height: 1.6; color: #333; margin: 40px; }
        h1, h2, h3, h4 { border-bottom: 1px solid #eee; padding-bottom: 0.3em; }
        .toc { background: #f9f9f9; padding: 15px; border: 1px solid #ddd; margin-bottom: 30px; }
        .toc ul { list-style-type: none; padding-left: 20px; }
        table { border-collapse: collapse; width: 100%; margin-bottom: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <header style="text-align: center; margin-bottom: 40px;">
        <h1>{{ global.metadata.system_name }} 仕様書</h1>
        <p>Version: {{ global.version }}</p>
        <hr>
    </header>

    <nav class="toc">
        <h2>目次</h2>
        {{ toc_html | safe }}
    </nav>

    <main>
        {{ content_html | safe }}
    </main>
</body>
</html>
""")

    # 2. ルート仕様書
    create_file(root / "func_spec.md", """---
title: 全体機能仕様概要
---
本ドキュメントは、サンプルシステムの全体的な機能要件および設計方針を定義するものです。
""")

    create_file(root / "file_spec.md", """---
title: ファイル仕様書
---
本セクションでは、システム内で扱う入出力ファイルおよびデータ構造の仕様を定義します。

| 項目名 | 型 | 必須 | 説明 |
| :--- | :--- | :--- | :--- |
| id | string | ○ | 一意の識別子 |
| name | string | ○ | 名称 |
""")

    # 3. 02_features (カテゴリ-A)
    create_file(root / "02_features" / "order.yaml", "order:\n  - カテゴリ-A\n")
    
    create_file(root / "02_features" / "カテゴリ-A" / "order.yaml", "order:\n  - 機能名-A\n")
    
    create_file(root / "02_features" / "カテゴリ-A" / "機能名-A" / "order.yaml", "order:\n  - 機能ブロック名-A\n")
    
    create_file(root / "02_features" / "カテゴリ-A" / "機能名-A" / "機能ブロック名-A" / "order.yaml", """order:
  - 処理名-00A
  - 処理名-00B
""")

    # 処理名-00A
    create_file(
        root / "02_features" / "カテゴリ-A" / "機能名-A" / "機能ブロック名-A" / "処理名-00A" / "overview.md",
        "---\ntitle: 処理名-00A 概要\n---\n処理名-00Aの概要説明です。ユーザーからの入力を受け付け、バリデーションを実行します。\n"
    )
    create_file(
        root / "02_features" / "カテゴリ-A" / "機能名-A" / "機能ブロック名-A" / "処理名-00A" / "usecase.md",
        "---\ntitle: ユースケース\n---\n1. ユーザーが画面からデータを入力する。\n2. システムがデータを検証する。\n"
    )

    # 処理名-00B
    create_file(
        root / "02_features" / "カテゴリ-A" / "機能名-A" / "機能ブロック名-A" / "処理名-00B" / "overview.md",
        "---\ntitle: 処理名-00B 概要\n---\n処理名-00Bの概要説明です。検証済みデータをデータベースへ永続化します。\n"
    )

    print("\nサンプルファイル群の生成が完了しました！")

if __name__ == "__main__":
    main()