#!/usr/bin/env bash
set -euo pipefail

REPO_DIR="agent-system-repo"

echo "=== エージェント実行基盤リポジトリ [${REPO_DIR}] の作成を開始します ==="

# 1. リポジトリディレクトリの作成と初期化
mkdir -p "${REPO_DIR}"
cd "${REPO_DIR}"

if [ ! -d ".git" ]; then
    git init
    echo "Initialized empty Git repository in $(pwd)/.git"
fi

# 2. ディレクトリ構造の作成
mkdir -p src/parsers
mkdir -p src/clients
mkdir -p src/graph
mkdir -p src/prompts
mkdir -p src/cli
mkdir -p docker
mkdir -p .cache

echo "Directories created successfully."

# 3. .gitignore の作成
cat << 'EOF' > .gitignore
# Python
__pycache__/
*.py[cod]
*$py.class
.venv/
venv/
ENV/

# Environment & Secrets
.env

# Cache & Storage
.cache/
*.sqlite3
*.sqlite3-journal

# Editor
.vscode/
.idea/
.DS_Store
Thumbs.db
EOF

# 4. .env.example の作成
cat << 'EOF' > .env.example
# specs-repo へのパス (ホスト実行時は相対パス、コンテナ実行時はマウント先パス)
SPECS_REPO_PATH=../specs-repo

# SGLang / vLLM 推論サーバー設定 (OpenAI互換エンドポイント)
LLM_API_BASE_URL=http://localhost:30000/v1
LLM_MODEL_NAME=Qwen/Qwen2.5-14B-Instruct
LLM_TEMPERATURE=0.1
LLM_MAX_TOKENS=4096

# PlantUML Server 設定 (HTTP API)
PLANTUML_SERVER_URL=http://localhost:8080

# Gitea / tea CLI 設定
GITEA_HOST=http://localhost:3000
GITEA_TOKEN=your_personal_access_token_here
GITEA_REPO_OWNER=architect
GITEA_REPO_NAME=specs-repo
EOF

cp .env.example .env

# 5. requirements.txt の作成
cat << 'EOF' > requirements.txt
langgraph>=0.2.0
langchain-core>=0.3.0
pydantic>=2.7.0
pydantic-settings>=2.2.0
pyyaml>=6.0.1
jinja2>=3.1.3
jsonschema>=4.21.1
python-docx>=1.1.0
httpx>=0.27.0
requests>=2.31.0
python-dotenv>=1.0.1
EOF

# 6. Dockerfile の作成 (K8s, Coder, Docker VM 汎用対応)
cat << 'EOF' > docker/Dockerfile
# Python 3.11 Slim をベースに採用
FROM python:3.11-slim-bookworm

# 環境変数設定 (オフライン・テレメトリ遮断)
ENV PYTHONUNBUFFERED=1 \
    DEBIAN_FRONTEND=noninteractive \
    HF_HUB_OFFLINE=1 \
    TRANSFORMERS_OFFLINE=1 \
    DO_NOT_TRACK=1

# 必要なOSパッケージのインストール
# - git, curl: 基本運用・tea取得
# - libreoffice-nogui: WMF/EMFメタファイルのヘッドレス変換
# - graphviz: PlantUML依存および構造可視化
RUN apt-get update && apt-get install -y --no-install-recommends \
    git \
    curl \
    ca-certificates \
    libreoffice-nogui \
    graphviz \
    default-jre-headless \
    && rm -rf /var/lib/apt/lists/*

# Gitea 公式CLI 'tea' のインストール
RUN ARCH=$(uname -m) && \
    if [ "$ARCH" = "x86_64" ]; then TEA_ARCH="amd64"; elif [ "$ARCH" = "aarch64" ]; then TEA_ARCH="arm64"; else TEA_ARCH="amd64"; fi && \
    curl -sSLo /usr/local/bin/tea "https://gitea.com/gitea/tea/releases/download/v0.9.2/tea-0.9.2-linux-${TEA_ARCH}" && \
    chmod +x /usr/local/bin/tea

WORKDIR /workspace/agent-system

# Python依存関係のインストール
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# アプリケーションコードの配置
COPY . .

# 実行ユーザーの作成 (Coder / K8s での非root実行を考慮し UID 1000 を設定)
RUN useradd -u 1000 -m appuser && \
    mkdir -p /workspace/agent-system/.cache && \
    chown -R appuser:appuser /workspace
USER appuser

ENTRYPOINT ["python3", "main.py"]
CMD ["--help"]
EOF

# 7. docker-compose.yml の作成
cat << 'EOF' > docker-compose.yml
version: '3.8'

services:
  agent-runner:
    build:
      context: .
      dockerfile: docker/Dockerfile
    container_name: spec-agent-runner
    environment:
      - SPECS_REPO_PATH=/workspace/specs-repo
      - LLM_API_BASE_URL=http://host.docker.internal:30000/v1
      - LLM_MODEL_NAME=Qwen/Qwen2.5-14B-Instruct
      - PLANTUML_SERVER_URL=http://host.docker.internal:8080
      - GITEA_HOST=http://host.docker.internal:3000
    volumes:
      - .:/workspace/agent-system
      - ../specs-repo:/workspace/specs-repo
    extra_hosts:
      - "host.docker.internal:host-gateway"
    command: ["--help"]
EOF

# 8. 設定モジュール (src/config.py)
cat << 'EOF' > src/config.py
from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

class AppConfig(BaseSettings):
    SPECS_REPO_PATH: Path = Path("../specs-repo")
    LLM_API_BASE_URL: str = "http://localhost:30000/v1"
    LLM_MODEL_NAME: str = "Qwen/Qwen2.5-14B-Instruct"
    LLM_TEMPERATURE: float = 0.1
    LLM_MAX_TOKENS: int = 4096
    PLANTUML_SERVER_URL: str = "http://localhost:8080"
    GITEA_HOST: str = "http://localhost:3000"
    GITEA_TOKEN: str = ""
    GITEA_REPO_OWNER: str = "architect"
    GITEA_REPO_NAME: str = "specs-repo"

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )

config = AppConfig()
EOF

# 9. Wordアトマイザー (src/parsers/atomizer.py)
# 描画要素・テキストボックス・テーブルの抽出とJSONL出力を担当
cat << 'EOF' > src/parsers/atomizer.py
import sys
import json
from pathlib import Path
from docx import Document
from docx.oxml.ns import qn

def parse_docx_to_atoms(docx_path: Path, output_jsonl_path: Path):
    """
    Word仕様書を解析し、段落、テーブル、テキストボックスを不可分なアトムに分解する。
    """
    if not docx_path.exists():
        raise FileNotFoundError(f"DOCX file not found: {docx_path}")

    doc = Document(docx_path)
    atoms = []
    atom_seq = 1
    current_headings = []

    # 1. 段落と描画テキストの走査
    for p in doc.paragraphs:
        text = p.text.strip()
        
        # 見出し判定 (スタイル名またはフォントによる簡易階層化)
        if p.style and p.style.name.startswith("Heading"):
            try:
                level = int(p.style.name.replace("Heading", "").strip())
                # 階層の調整
                current_headings = current_headings[:level-1]
                current_headings.append(text)
            except ValueError:
                current_headings = [text]
            continue

        # テキストボックス (w:txbxContent) の検知
        txbx_elements = p._element.xpath('.//w:txbxContent')
        has_drawing = len(txbx_elements) > 0
        drawing_texts = []
        for txbx in txbx_elements:
            t_nodes = txbx.xpath('.//w:t')
            t_content = "".join([n.text for n in t_nodes if n.text])
            if t_content.strip():
                drawing_texts.append(t_content.strip())

        # 本文アトムの登録
        if text:
            atoms.append({
                "atom_id": f"ATOM_RAW_{atom_seq:05d}",
                "source_doc": docx_path.name,
                "heading_hierarchy": list(current_headings),
                "content_type": "text",
                "text_content": text,
                "has_unextracted_shapes": False,
                "raw_attributes": {},
                "status": "Unmapped",
                "mapped_usecase": None
            })
            atom_seq += 1

        # 描画テキストアトムの登録
        for d_text in drawing_texts:
            atoms.append({
                "atom_id": f"ATOM_RAW_{atom_seq:05d}",
                "source_doc": docx_path.name,
                "heading_hierarchy": list(current_headings),
                "content_type": "drawing_text",
                "text_content": f"[描画/図形内テキスト] {d_text}",
                "has_unextracted_shapes": True,
                "raw_attributes": {"source_tag": "w:txbxContent"},
                "status": "Unmapped",
                "mapped_usecase": None
            })
            atom_seq += 1

    # 2. 表 (Table) の走査
    for t_idx, table in enumerate(doc.tables):
        rows_data = []
        for row in table.rows:
            rows_data.append([cell.text.strip().replace("\n", " ") for cell in row.cells])
        
        table_summary = " | ".join(["[" + ", ".join(r) + "]" for r in rows_data[:3]])
        atoms.append({
            "atom_id": f"ATOM_RAW_{atom_seq:05d}",
            "source_doc": docx_path.name,
            "heading_hierarchy": list(current_headings),
            "content_type": "table",
            "text_content": f"[仕様表 #{t_idx+1}] {table_summary}",
            "has_unextracted_shapes": False,
            "raw_attributes": {
                "total_rows": len(table.rows),
                "total_cols": len(table.columns),
                "rows_sample": rows_data
            },
            "status": "Unmapped",
            "mapped_usecase": None
        })
        atom_seq += 1

    # JSONL 出力
    output_jsonl_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_jsonl_path, "w", encoding="utf-8") as f:
        for atom in atoms:
            f.write(json.dumps(atom, ensure_ascii=False) + "\n")

    print(f"[ATOMIZER] Extracted {len(atoms)} atoms to {output_jsonl_path}")
    return atoms

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python -m src.parsers.atomizer <input.docx> <output.jsonl>")
        sys.exit(1)
    parse_docx_to_atoms(Path(sys.argv[1]), Path(sys.argv[2]))
EOF

# 10. HTTP クライアント群 (src/clients/)
# 10.1 LLM Client (src/clients/llm_client.py)
cat << 'EOF' > src/clients/llm_client.py
import json
import httpx
from src.config import config

class LocalLLMClient:
    def __init__(self):
        self.endpoint = f"{config.LLM_API_BASE_URL}/chat/completions"
        self.model = config.LLM_MODEL_NAME

    def generate_json(self, system_prompt: str, user_prompt: str) -> dict:
        """
        SGLang / vLLM の構造化出力APIを呼び出し、JSONを返却する。
        """
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            "temperature": config.LLM_TEMPERATURE,
            "max_tokens": config.LLM_MAX_TOKENS,
            "response_format": {"type": "json_object"}
        }

        with httpx.Client(timeout=120.0) as client:
            response = client.post(self.endpoint, json=payload)
            response.raise_for_status()
            data = response.json()
            content = data["choices"][0]["message"]["content"]
            return json.loads(content)
EOF

# 10.2 PlantUML Server Client (src/clients/plantuml_client.py)
cat << 'EOF' > src/clients/plantuml_client.py
import httpx
from src.config import config

class PlantUMLValidator:
    def __init__(self):
        self.server_url = config.PLANTUML_SERVER_URL.rstrip("/")

    def validate_puml(self, puml_code: str) -> dict:
        """
        PlantUML Serverの /svg/ エンドポイントへコードをPOSTし構文エラーを検証する。
        """
        url = f"{self.server_url}/svg/"
        try:
            with httpx.Client(timeout=15.0) as client:
                resp = client.post(
                    url,
                    content=puml_code.encode("utf-8"),
                    headers={"Content-Type": "text/plain; charset=utf-8"}
                )
                if resp.status_code != 200:
                    return {
                        "is_valid": False,
                        "error_message": f"Server error: HTTP {resp.status_code}"
                    }

                body = resp.text
                if "Syntax Error?" in body or "[Syntax Error]" in body:
                    return {
                        "is_valid": False,
                        "error_message": "PlantUML Syntax Error: 構文エラーが検出されました。"
                    }
                return {"is_valid": True, "error_message": ""}
        except Exception as e:
            return {
                "is_valid": False,
                "error_message": f"Failed to connect to PlantUML server: {str(e)}"
            }
EOF

# 11. プロンプトテンプレート (src/prompts/)
# 11.1 ユースケース起票プロンプト (src/prompts/draft_usecase.j2)
cat << 'EOF' > src/prompts/draft_usecase.j2
あなたはICONIXプロセスおよびクリーンアーキテクチャに精通した要求分析エージェントです。
提示された「新機能仕様」「対象コンテキストの用語集」「旧仕様書の要件アトム」に基づき、ユースケース定義とロバストネスモデルを策定してください。

【対象新機能】
{{ feature_line }}

【モジュール・境界づけられたコンテキスト】
{{ module_name }}

【利用可能なドメイン用語一覧】
{% for v in vocabulary %}
- {{ v.term }} (コード: {{ v.code }}): {{ v.definition }}
{% endfor %}

【旧仕様書の該当アトム群】
{% for atom in atoms %}
- [{{ atom.atom_id }}] ({{ atom.content_type }}): {{ atom.text_content }}
{% endfor %}

【厳格な設計ルール】
1. システムユースケースの粒度: 1アクターが1回のセッションで目的を完了する範囲（基本コースは2〜5ステップ）。
2. 能動態・現在形で記述すること（「アクターは〜を入力する」「システムは〜を検証する」）。
3. 各ステップおよび例外には、根拠となったアトムID（source_atom_ref）を必ず割り当てること。
4. ロバストネス図ルール:
   - Boundary: 画面UI、または外部ゲートウェイ電文通信部。
   - Control: 検証、計算、トランザクション制御などの処理。
   - Entity: 永続化・参照されるドメインデータ。
   - BoundaryとEntityを直接接続してはならない（必ずControlが仲介する）。

【出力フォーマット】
以下のJSONフォーマットのみを出力してください。
{
  "id": "UC_MOD01_001",
  "title": "...",
  "actor": "...",
  "source_atoms": ["ATOM_RAW_00001", "..."],
  "pre_conditions": ["..."],
  "post_conditions": ["..."],
  "basic_flow": [
    {"step": 1, "actor_action": "...", "system_response": "...", "source_atom_ref": "ATOM_RAW_00001"}
  ],
  "alternative_flows": [
    {"id": "1a", "resume_step": 1, "condition": "...", "handling": "...", "source_atom_ref": "ATOM_RAW_00002"}
  ],
  "robustness_model": {
    "boundaries": [{"name": "...", "alias": "UI"}],
    "controls": [{"name": "...", "alias": "Ctrl"}],
    "entities": [{"name": "...", "alias": "Entity"}],
    "relations": [
      {"from": "Actor", "to": "UI", "label": "..."},
      {"from": "UI", "to": "Ctrl", "label": "..."}
    ]
  },
  "architectural_hints": {
    "geode_regions": ["/..."],
    "gateway_destinations": ["GW.DEST...."]
  }
}
EOF

# 11.2 PlantUML構文自己修復プロンプト (src/prompts/repair_puml.j2)
cat << 'EOF' > src/prompts/repair_puml.j2
あなたはPlantUML構文の修正スペシャリストです。
以下のPlantUMLコードで構文エラーまたは描画エラーが発生しました。
エラーメッセージを参照し、正しくレンダリング可能なコードに修正してください。

【発生したエラー】
{{ error_message }}

【現在のPlantUMLコード】
{{ puml_code }}

【出力フォーマット】
以下のJSONフォーマットのみを出力してください。
{
  "repaired_puml": "@startuml\n...\n@enduml"
}
EOF

# 12. LangGraph ステートとワークフロー (src/graph/)
# 12.1 State定義 (src/graph/state.py)
cat << 'EOF' > src/graph/state.py
from typing import TypedDict, List, Dict, Any, Optional

class AgentState(TypedDict):
    feature_id: str
    feature_line: str
    docx_filename: str
    module_name: str
    atoms: List[Dict[str, Any]]
    vocabulary: List[Dict[str, Any]]
    draft_data: Dict[str, Any]
    puml_code: str
    linter_error: str
    retry_count: int
    status: str
    error_message: Optional[str]
EOF

# 12.2 Workflow定義 (src/graph/workflow.py)
cat << 'EOF' > src/graph/workflow.py
import json
import yaml
from pathlib import Path
from jinja2 import Environment, FileSystemLoader
from langgraph.graph import StateGraph, END
from src.graph.state import AgentState
from src.clients.llm_client import LocalLLMClient
from src.clients.plantuml_client import PlantUMLValidator
from src.config import config

prompts_dir = Path(__file__).resolve().parent.parent / "prompts"
jinja_env = Environment(loader=FileSystemLoader(str(prompts_dir)), trim_blocks=True, lstrip_blocks=True)

llm_client = LocalLLMClient()
puml_validator = PlantUMLValidator()

def generate_puml_from_model(actor: str, model: dict) -> str:
    lines = ["@startuml", "skinparam monochrome true", f'actor "{actor}" as Actor']
    lines.append('package "Boundary" {')
    for b in model.get("boundaries", []):
        lines.append(f'  boundary "{b["name"]}" as {b["alias"]}')
    lines.append('}')
    lines.append('package "Control" {')
    for c in model.get("controls", []):
        lines.append(f'  control "{c["name"]}" as {c["alias"]}')
    lines.append('}')
    lines.append('package "Entity" {')
    for e in model.get("entities", []):
        lines.append(f'  entity "{e["name"]}" as {e["alias"]}')
    lines.append('}')
    lines.append("' 接続関係")
    for r in model.get("relations", []):
        lines.append(f'{r["from"]} --> {r["to"]} : {r["label"]}')
    lines.append("@enduml")
    return "\n".join(lines)

# --- Nodes ---

def draft_usecase_node(state: AgentState) -> dict:
    print(f"-> [Node: DraftUseCase] Generating initial specification for {state['feature_id']}...")
    template = jinja_env.get_template("draft_usecase.j2")
    user_prompt = template.render(
        feature_line=state["feature_line"],
        module_name=state["module_name"],
        vocabulary=state["vocabulary"],
        atoms=state["atoms"]
    )
    
    result = llm_client.generate_json(
        system_prompt="You are an expert system modeling assistant. Output valid JSON.",
        user_prompt=user_prompt
    )
    
    puml = generate_puml_from_model(result.get("actor", "Actor"), result.get("robustness_model", {}))
    return {
        "draft_data": result,
        "puml_code": puml,
        "retry_count": 0,
        "linter_error": ""
    }

def validate_puml_node(state: AgentState) -> dict:
    print("-> [Node: ValidatePUML] Validating PlantUML code with PlantUML Server...")
    check = puml_validator.validate_puml(state["puml_code"])
    if check["is_valid"]:
        print("   [PASS] PlantUML syntax is clean.")
        return {"linter_error": "", "status": "valid"}
    else:
        print(f"   [FAIL] PlantUML error: {check['error_message']}")
        return {
            "linter_error": check["error_message"],
            "retry_count": state["retry_count"] + 1,
            "status": "invalid"
        }

def repair_puml_node(state: AgentState) -> dict:
    print(f"-> [Node: RepairPUML] Auto-fixing syntax error (Attempt {state['retry_count']}/3)...")
    template = jinja_env.get_template("repair_puml.j2")
    user_prompt = template.render(
        error_message=state["linter_error"],
        puml_code=state["puml_code"]
    )
    res = llm_client.generate_json(
        system_prompt="You are a PlantUML repair expert. Return JSON with repaired_puml.",
        user_prompt=user_prompt
    )
    return {"puml_code": res.get("repaired_puml", state["puml_code"])}

def escalate_human_node(state: AgentState) -> dict:
    print("-> [Node: Escalate] Max retry count reached. Escalating to human...")
    return {
        "status": "agent-error",
        "error_message": f"Syntax repair exceeded 3 attempts: {state['linter_error']}"
    }

def save_artifacts_node(state: AgentState) -> dict:
    print("-> [Node: SaveArtifacts] Saving YAML specification to specs-repo...")
    specs_root = config.SPECS_REPO_PATH
    out_dir = specs_root / "03_usecases" / state["module_name"]
    out_dir.mkdir(parents=True, exist_ok=True)
    
    uc_id = state["draft_data"].get("id", "UC_DRAFT_001")
    yaml_file = out_dir / f"{uc_id}.yaml"
    
    full_yaml_data = {
        "id": uc_id,
        "title": state["draft_data"].get("title", ""),
        "module": state["module_name"],
        "source_requirements": [state["docx_filename"]],
        "source_atoms": state["draft_data"].get("source_atoms", []),
        "actor": state["draft_data"].get("actor", "Actor"),
        "pre_conditions": state["draft_data"].get("pre_conditions", []),
        "post_conditions": state["draft_data"].get("post_conditions", []),
        "basic_flow": state["draft_data"].get("basic_flow", []),
        "alternative_flows": state["draft_data"].get("alternative_flows", []),
        "robustness_model": state["draft_data"].get("robustness_model", {}),
        "architectural_hints": state["draft_data"].get("architectural_hints", {})
    }
    
    with open(yaml_file, "w", encoding="utf-8") as f:
        yaml.dump(full_yaml_data, f, allow_unicode=True, sort_keys=False)
        
    print(f"   [SAVED] {yaml_file}")
    return {"status": "success"}

# --- Graph Assembly ---

def router(state: AgentState) -> str:
    if state["status"] == "valid":
        return "save"
    if state["retry_count"] >= 3:
        return "escalate"
    return "retry"

def build_agent_graph():
    graph = StateGraph(AgentState)
    graph.add_node("draft_usecase", draft_usecase_node)
    graph.add_node("validate_puml", validate_puml_node)
    graph.add_node("repair_puml", repair_puml_node)
    graph.add_node("escalate_human", escalate_human_node)
    graph.add_node("save_artifacts", save_artifacts_node)

    graph.set_entry_point("draft_usecase")
    graph.add_edge("draft_usecase", "validate_puml")

    graph.add_conditional_edges(
        "validate_puml",
        router,
        {
            "save": "save_artifacts",
            "retry": "repair_puml",
            "escalate": "escalate_human"
        }
    )
    graph.add_edge("repair_puml", "validate_puml")
    graph.add_edge("save_artifacts", END)
    graph.add_edge("escalate_human", END)

    return graph.compile()
EOF

# 13. エントリーポイント CLI (main.py)
cat << 'EOF' > main.py
import argparse
import sys
import json
import yaml
from pathlib import Path
from src.config import config
from src.parsers.atomizer import parse_docx_to_atoms
from src.graph.workflow import build_agent_graph

def run_pipeline(feature_line: str, docx_path: Path, module_name: str):
    print("=== Starting Autonomous Specification Pipeline ===")
    specs_root = config.SPECS_REPO_PATH
    
    # 1. Wordアトマイザーの実行
    atoms_file = specs_root / "00_traceability" / "atoms" / f"{docx_path.stem}.jsonl"
    print(f"Step 1: Parsing Word Document: {docx_path.name}")
    atoms = parse_docx_to_atoms(docx_path, atoms_file)
    
    # 2. 用語集の読み込み (対象モジュールのもののみフィルタ)
    vocab_file = specs_root / "01_architecture" / "domain_vocabulary.yaml"
    vocabulary = []
    if vocab_file.exists():
        with open(vocab_file, "r", encoding="utf-8") as f:
            v_data = yaml.safe_load(f) or {}
            vocabulary = [item for item in v_data.get("vocabulary", []) if item.get("module") == module_name]

    # 3. LangGraph の実行
    print("Step 2: Executing LangGraph Multi-Agent Orchestration")
    app = build_agent_graph()
    
    initial_state = {
        "feature_id": feature_line.split("\t")[3] if "\t" in feature_line else "F_ORD_001",
        "feature_line": feature_line,
        "docx_filename": docx_path.name,
        "module_name": module_name,
        "atoms": atoms[:15], # コンテキストスライシング: 先頭関連アトム
        "vocabulary": vocabulary,
        "draft_data": {},
        "puml_code": "",
        "linter_error": "",
        "retry_count": 0,
        "status": "init",
        "error_message": None
    }
    
    final_state = app.invoke(initial_state)
    
    if final_state["status"] == "success":
        print("=== Pipeline Completed Successfully. Artifacts generated. ===")
        sys.exit(0)
    else:
        print(f"=== Pipeline Ended with Warning/Error: {final_state.get('error_message')} ===")
        sys.exit(2)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Autonomous Specification Agent CLI")
    parser.add_argument("--feature", required=True, help="TSV line of the target feature")
    parser.add_argument("--docx", required=True, help="Path to the legacy Word docx")
    parser.add_argument("--module", default="MOD01_Order", help="Target module name")
    
    args = parser.parse_args()
    run_pipeline(args.feature, Path(args.docx), args.module)
EOF
chmod +x main.py

# 14. README.md の作成
cat << 'EOF' > README.md
# agent-system-repo: 自律仕様再構築マルチエージェント基盤

本リポジトリは、旧Word仕様書を解析し、ICONIX分析に基づくユースケース・ロバストネス図を自律生成するLangGraphマルチエージェント実行環境です。

## 主な機能
- **Word Atomizer (`src/parsers/atomizer.py`)**:
  - 段落、テーブル、およびテキストボックス（オートシェイプ）を漏れなく一意ID付きのJSON Linesアトムに分解。
- **LangGraph オーケストレーション (`src/graph/`)**:
  - ユースケース生成、PlantUML Server静的検証、最大3回の自律修復ループ、および人間エスカレーション制御。
- **完全環境ポータビリティ**:
  - Docker Compose、Kubernetes、Coder、スタンドアロンVMで同一コンテナイメージを実行可能。

## 実行方法

### 1. ローカル実行 (Python 3.11 環境)
```bash
pip install -r requirements.txt
cp .env.example .env
# .env のエンドポイント設定を確認
python main.py \
  --feature "受注管理	注文受付	新規登録	F_ORD_001	新規受注登録" \
  --docx "../specs-repo/inputs/raw_docs/sample.docx" \
  --module "MOD01_Order"

```

### 2. Docker / Compose での実行

```bash
docker compose build
docker compose run --rm agent-runner \
  --feature "受注管理	注文受付	新規登録	F_ORD_001	新規受注登録" \
  --docx "/workspace/specs-repo/inputs/raw_docs/sample.docx" \
  --module "MOD01_Order"

```

EOF

# 15. Git初期コミット

git add .
git commit -m "chore: initial commit for agent-system-repo execution environment"

echo "=== agent-system-repo の初期化が完全に完了しました ==="
echo "Path: $(pwd)"

