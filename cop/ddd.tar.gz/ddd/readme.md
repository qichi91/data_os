完全閉域網（Air-gap環境）において、ローカルLLMを用いた自律仕様再構築システムを本番稼働させるための包括的な導入手順書です。

本手順は、インターネット接続が可能なステージング環境（作業端末）**で全コンテナイメージ、モデルウェイト、ツールバイナリをパッケージングし、物理メディア等を介して**本番閉域網環境（ターゲット環境）へ移送・展開する運用を前提としています。

---

## 1. 閉域網対応に向けた変更箇所と環境変数一覧

閉域網では外部DNS解決やNATルーターが存在しないため、初期設定のまま起動すると「外部リポジトリへの照会」「利用統計（テレメトリ）送信」「モデルの最新版チェック」によってソケットタイムアウトやクラッシュが発生します。事前に以下の設定・環境変数を適用します。

### (1) 必須環境変数（テレメトリ・外部通信の完全遮断）

| 対象 | 環境変数名 | 設定値 | 目的・効果 |
| --- | --- | --- | --- |
| **Python / Hugging Face** | `HF_HUB_OFFLINE` | `1` | Hugging Face Hubへのネットワーク照会を遮断

 |
| **Python / Hugging Face** | `TRANSFORMERS_OFFLINE` | `1` | ローカルキャッシュのみを参照し、外部通信を抑止

 |
| **Python共通** | `DO_NOT_TRACK` | `1` | 各種ライブラリの利用状況テレメトリを無効化 |
| **vLLM (推論サーバー)** | `VLLM_NO_USAGE_STATS` | `1` | vLLM起動時および定期的なテレメトリpingを完全停止

 |
| **Docling (解析ツール)** | `DOCLING_ARTIFACTS_PATH` | `/models/docling` | レイアウト・表構造モデルの読み込み先をローカル配置パスへ固定

 |
| **Gitea Actions** | `DEFAULT_ACTIONS_URL` | `self` / `offline` | GitHub Marketplaceへのアクション取得通信を遮断

 |

### (2) `agent-system-repo` 内の変更箇所

1. **`docker/Dockerfile` の事前アセット化:**
* 初期作成したDockerfile内の `curl` による `tea` CLIダウンロードを、「事前にダウンロードしたバイナリを `COPY` する方式」に変更します（閉域網内での再ビルドを可能にするため）。


2. **`.env` のホスト名解決:**
* ホスト名 `localhost` や `host.docker.internal` を、閉域網内の**プライベートIPアドレス**または**内部DNS名**（例: `[http://llm-server.internal:30000/v1](http://llm-server.internal:30000/v1)`）へ書き換えます。




3. **推論サーバーマウントパスの固定:**
* 推論エンジンコンテナに対し、外部ダウンロードではなく、閉域網内の共有ストレージ（またはローカルディスク）に配置したモデルウェイトの絶対パスをマウントします。





---

## 2. ステージング環境での事前準備手順（インターネット接続環境）

インターネットに接続できる作業端末で、必要なアセットをすべて収集・ビルドし、アーカイブ（tar）化します。

### Step 1: 外部バイナリの事前取得

`agent-system-repo` の `docker/` ディレクトリ配下に、`tea` CLIバイナリを事前ダウンロードしておきます。

```bash
cd agent-system-repo/docker

# tea CLI (Linux x86_64 / arm64) をダウンロード
curl -sSLo tea "https://gitea.com/gitea/tea/releases/download/v0.9.2/tea-0.9.2-linux-amd64"
chmod +x tea

```

これに伴い、`agent-system-repo/docker/Dockerfile` の該当箇所を以下のように修正します。

```dockerfile
# (修正前) RUN curl -sSLo /usr/local/bin/tea ...
# (修正後) 事前配置したバイナリをコピー
COPY docker/tea /usr/local/bin/tea
RUN chmod +x /usr/local/bin/tea

```

### Step 2: Dockerイメージのビルドと取得

システムを構成する全コンテナイメージを用意します。

```bash
# 1. agent-runner イメージのビルド
cd agent-system-repo
docker build -t private-registry.internal/architect/agent-runner:v1.0.0 -f docker/Dockerfile .

# 2. PlantUML Server イメージの取得
docker pull plantuml/plantuml-server:jetty
docker tag plantuml/plantuml-server:jetty private-registry.internal/architect/plantuml-server:jetty

# 3. 推論サーバー (SGLang または vLLM) イメージの取得
# (例: vLLM を採用する場合)
docker pull vllm/vllm-openai:latest
docker tag vllm/vllm-openai:latest private-registry.internal/architect/vllm-openai:latest

# (例: SGLang を採用する場合)
# docker pull lmsysorg/sglang:latest
# docker tag lmsysorg/sglang:latest private-registry.internal/architect/sglang:latest

# 4. Gitea イメージの取得
docker pull gitea/gitea:latest
docker tag gitea/gitea:latest private-registry.internal/architect/gitea:latest

```

### Step 3: コンテナイメージの tar 保存

取得した全イメージを単一（または分割）の tar アーカイブへ出力します。

```bash
mkdir -p ./transfer_pack/images

docker save \
  private-registry.internal/architect/agent-runner:v1.0.0 \
  private-registry.internal/architect/plantuml-server:jetty \
  private-registry.internal/architect/vllm-openai:latest \
  private-registry.internal/architect/gitea:latest \
  -o ./transfer_pack/images/system_images.tar

```

### Step 4: モデルウェイトとDoclingアーティファクトの取得

モデルファイルおよびWord解析に必要な小型モデル群をローカルディレクトリへダウンロードします。

```bash
mkdir -p ./transfer_pack/models/llm
mkdir -p ./transfer_pack/models/docling

# 1. LLMモデル (Qwen2.5-14B-Instruct) のクローン
# (Git LFS を用いて safetensors を含む全ファイルをローカルに保存)
git clone https://huggingface.co/Qwen/Qwen2.5-14B-Instruct-AWQ ./transfer_pack/models/llm/Qwen2.5-14B-Instruct-AWQ

# 2. Docling用レイアウト・表構造モデルの事前キャッシュダウンロード
pip install docling
docling-tools models download -o ./transfer_pack/models/docling

```

### Step 5: 移送パッケージの構成確認

`transfer_pack/` ディレクトリ配下が以下の状態になっていることを確認し、組織のセキュリティ規定（ウイルススキャン等）に沿って物理暗号化メディアに格納します。

transfer_pack/
├── images/
│   └── system_images.tar           # Dockerイメージ一式
├── models/
│   ├── llm/
│   │   └── Qwen2.5-14B-Instruct-AWQ/ # LLM重みファイル群
│   └── docling/                    # Docling解析モデル群
└── repos/
├── specs-repo.bundle           # git bundle で出力した初期リポジトリ
└── agent-system-repo.bundle

---

## 3. 本番閉域網環境での展開・起動手順

持ち込んだアーカイブを閉域網サーバーに展開し、サービスを立ち上げます。

### Step 1: Dockerイメージのロードとプライベートレジストリ（Harbor等）への登録

閉域網内にプライベートレジストリ（Harborなど）がある場合はロードしてプッシュします（スタンドアロン運用の場合はロードのみで可）。

```bash
# イメージのロード
docker load -i ./transfer_pack/images/system_images.tar

# (プライベートレジストリへ push する場合)
# docker login private-registry.internal
# docker push private-registry.internal/architect/agent-runner:v1.0.0
# docker push private-registry.internal/architect/plantuml-server:jetty
# docker push private-registry.internal/architect/vllm-openai:latest
# docker push private-registry.internal/architect/gitea:latest

```

### Step 2: モデルファイルの配置

ホスト側の固定パスにモデルを配置し、アクセス権限を付与します。

```bash
sudo mkdir -p /opt/models/llm
sudo mkdir -p /opt/models/docling

sudo cp -r ./transfer_pack/models/llm/* /opt/models/llm/
sudo cp -r ./transfer_pack/models/docling/* /opt/models/docling/
sudo chmod -R 755 /opt/models

```

### Step 3: 推論サーバー（vLLM）のオフライン起動

テレメトリ無効化および完全オフライン環境変数を指定し、ローカルに配置したモデルを指定してコンテナを起動します。

```bash
docker run -d \
  --name llm-server \
  --gpus all \
  --restart always \
  -p 30000:8000 \
  -e HF_HUB_OFFLINE=1 \
  -e TRANSFORMERS_OFFLINE=1 \
  -e VLLM_NO_USAGE_STATS=1 \
  -v /opt/models/llm/Qwen2.5-14B-Instruct-AWQ:/model \
  private-registry.internal/architect/vllm-openai:latest \
  --model /model \
  --max-model-len 8192 \
  --gpu-memory-utilization 0.90 \
  --quantization awq

```

### Step 4: PlantUML Server の起動

HTTP API用のPlantUML Serverコンテナを起動します。

```bash
docker run -d \
  --name plantuml-server \
  --restart always \
  -p 8080:8080 \
  plantuml/plantuml-server:jetty

```

### Step 5: `agent-system-repo` の閉域網向け設定 (`.env`)

`agent-system-repo/.env` を本番閉域網のネットワーク構成に合わせて更新します。

```ini
# specs-repo の配置パス
SPECS_REPO_PATH=/workspace/specs-repo

# 閉域網内LLMサーバー (ホストIPまたはコンテナネットワーク名)
LLM_API_BASE_URL=http://192.168.10.50:30000/v1
LLM_MODEL_NAME=/model
LLM_TEMPERATURE=0.1
LLM_MAX_TOKENS=4096

# 閉域網内PlantUML Server
PLANTUML_SERVER_URL=http://192.168.10.50:8080

# 閉域網内Gitea
GITEA_HOST=http://192.168.10.50:3000
GITEA_TOKEN=YOUR_AIRGAP_USER_PAT
GITEA_REPO_OWNER=architect
GITEA_REPO_NAME=specs-repo

# Doclingローカルモデルパス
DOCLING_ARTIFACTS_PATH=/models/docling

```

### Step 6: 閉域網用 `docker-compose.yml` によるエージェント起動

ホストのモデルパスや設定をマウントして実行します。

```yaml
version: '3.8'

services:
  agent-runner:
    image: private-registry.internal/architect/agent-runner:v1.0.0
    container_name: spec-agent-runner
    env_file:
      - .env
    environment:
      - HF_HUB_OFFLINE=1
      - TRANSFORMERS_OFFLINE=1
      - DO_NOT_TRACK=1
      - DOCLING_ARTIFACTS_PATH=/models/docling
    volumes:
      - .:/workspace/agent-system
      - /path/to/specs-repo:/workspace/specs-repo
      - /opt/models/docling:/models/docling:ro
    entrypoint: ["python3", "main.py"]

```

---

## 4. 閉域網環境での疎通確認（スモークテスト）

すべてのコンテナが立ち上がった後、外部通信が遮断された状態で正常動作するか検証します。

1. **推論サーバー疎通確認:**
```bash
curl http://192.168.10.50:30000/v1/models

```


モデル名（`/model` など）がJSON形式で返却されれば成功です。
2. **PlantUML Server疎通確認:**
```bash
curl -X POST -H "Content-Type: text/plain" --data "@startuml\nclass Test\n@enduml" http://192.168.10.50:8080/svg/

```


SVGのXMLデータが返却されれば正常稼働しています。
3. **エージェントパイプラインのテスト実行:**
```bash
docker compose run --rm agent-runner \
  --feature "受注管理	注文受付	新規登録	F_ORD_001	新規受注登録" \
  --docx "/workspace/specs-repo/inputs/raw_docs/sample.docx" \
  --module "MOD01_Order"

```


外部ネットワーク未接続でも、アトム抽出からYAML生成、PlantUML構文チェック、Markdownレンダリングまでが停止することなく完了することを確認してください。