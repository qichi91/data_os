import sys
import json
from pathlib import Path
from docx import Document
from docx.oxml.ns import qn

def parse_docx_to_atoms(docx_path: Path, output_jsonl_path: Path):
    """
    Word仕様書を解析し、段落、テーブル、テキストボックスを不可分なアトムに分解する。
    """
    if not docx_path.exists():
        raise FileNotFoundError(f"DOCX file not found: {docx_path}")

    doc = Document(docx_path)
    atoms = []
    atom_seq = 1
    current_headings = []

    # 1. 段落と描画テキストの走査
    for p in doc.paragraphs:
        text = p.text.strip()
        
        # 見出し判定 (スタイル名またはフォントによる簡易階層化)
        if p.style and p.style.name.startswith("Heading"):
            try:
                level = int(p.style.name.replace("Heading", "").strip())
                # 階層の調整
                current_headings = current_headings[:level-1]
                current_headings.append(text)
            except ValueError:
                current_headings = [text]
            continue

        # テキストボックス (w:txbxContent) の検知
        txbx_elements = p._element.xpath('.//w:txbxContent')
        has_drawing = len(txbx_elements) > 0
        drawing_texts = []
        for txbx in txbx_elements:
            t_nodes = txbx.xpath('.//w:t')
            t_content = "".join([n.text for n in t_nodes if n.text])
            if t_content.strip():
                drawing_texts.append(t_content.strip())

        # 本文アトムの登録
        if text:
            atoms.append({
                "atom_id": f"ATOM_RAW_{atom_seq:05d}",
                "source_doc": docx_path.name,
                "heading_hierarchy": list(current_headings),
                "content_type": "text",
                "text_content": text,
                "has_unextracted_shapes": False,
                "raw_attributes": {},
                "status": "Unmapped",
                "mapped_usecase": None
            })
            atom_seq += 1

        # 描画テキストアトムの登録
        for d_text in drawing_texts:
            atoms.append({
                "atom_id": f"ATOM_RAW_{atom_seq:05d}",
                "source_doc": docx_path.name,
                "heading_hierarchy": list(current_headings),
                "content_type": "drawing_text",
                "text_content": f"[描画/図形内テキスト] {d_text}",
                "has_unextracted_shapes": True,
                "raw_attributes": {"source_tag": "w:txbxContent"},
                "status": "Unmapped",
                "mapped_usecase": None
            })
            atom_seq += 1

    # 2. 表 (Table) の走査
    for t_idx, table in enumerate(doc.tables):
        rows_data = []
        for row in table.rows:
            rows_data.append([cell.text.strip().replace("\n", " ") for cell in row.cells])
        
        table_summary = " | ".join(["[" + ", ".join(r) + "]" for r in rows_data[:3]])
        atoms.append({
            "atom_id": f"ATOM_RAW_{atom_seq:05d}",
            "source_doc": docx_path.name,
            "heading_hierarchy": list(current_headings),
            "content_type": "table",
            "text_content": f"[仕様表 #{t_idx+1}] {table_summary}",
            "has_unextracted_shapes": False,
            "raw_attributes": {
                "total_rows": len(table.rows),
                "total_cols": len(table.columns),
                "rows_sample": rows_data
            },
            "status": "Unmapped",
            "mapped_usecase": None
        })
        atom_seq += 1

    # JSONL 出力
    output_jsonl_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_jsonl_path, "w", encoding="utf-8") as f:
        for atom in atoms:
            f.write(json.dumps(atom, ensure_ascii=False) + "\n")

    print(f"[ATOMIZER] Extracted {len(atoms)} atoms to {output_jsonl_path}")
    return atoms

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python -m src.parsers.atomizer <input.docx> <output.jsonl>")
        sys.exit(1)
    parse_docx_to_atoms(Path(sys.argv[1]), Path(sys.argv[2]))
