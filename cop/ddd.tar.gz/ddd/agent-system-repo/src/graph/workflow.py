import json
import yaml
from pathlib import Path
from jinja2 import Environment, FileSystemLoader
from langgraph.graph import StateGraph, END
from src.graph.state import AgentState
from src.clients.llm_client import LocalLLMClient
from src.clients.plantuml_client import PlantUMLValidator
from src.config import config

prompts_dir = Path(__file__).resolve().parent.parent / "prompts"
jinja_env = Environment(loader=FileSystemLoader(str(prompts_dir)), trim_blocks=True, lstrip_blocks=True)

llm_client = LocalLLMClient()
puml_validator = PlantUMLValidator()

def generate_puml_from_model(actor: str, model: dict) -> str:
    lines = ["@startuml", "skinparam monochrome true", f'actor "{actor}" as Actor']
    lines.append('package "Boundary" {')
    for b in model.get("boundaries", []):
        lines.append(f'  boundary "{b["name"]}" as {b["alias"]}')
    lines.append('}')
    lines.append('package "Control" {')
    for c in model.get("controls", []):
        lines.append(f'  control "{c["name"]}" as {c["alias"]}')
    lines.append('}')
    lines.append('package "Entity" {')
    for e in model.get("entities", []):
        lines.append(f'  entity "{e["name"]}" as {e["alias"]}')
    lines.append('}')
    lines.append("' 接続関係")
    for r in model.get("relations", []):
        lines.append(f'{r["from"]} --> {r["to"]} : {r["label"]}')
    lines.append("@enduml")
    return "\n".join(lines)

# --- Nodes ---

def draft_usecase_node(state: AgentState) -> dict:
    print(f"-> [Node: DraftUseCase] Generating initial specification for {state['feature_id']}...")
    template = jinja_env.get_template("draft_usecase.j2")
    user_prompt = template.render(
        feature_line=state["feature_line"],
        module_name=state["module_name"],
        vocabulary=state["vocabulary"],
        atoms=state["atoms"]
    )
    
    result = llm_client.generate_json(
        system_prompt="You are an expert system modeling assistant. Output valid JSON.",
        user_prompt=user_prompt
    )
    
    puml = generate_puml_from_model(result.get("actor", "Actor"), result.get("robustness_model", {}))
    return {
        "draft_data": result,
        "puml_code": puml,
        "retry_count": 0,
        "linter_error": ""
    }

def validate_puml_node(state: AgentState) -> dict:
    print("-> [Node: ValidatePUML] Validating PlantUML code with PlantUML Server...")
    check = puml_validator.validate_puml(state["puml_code"])
    if check["is_valid"]:
        print("   [PASS] PlantUML syntax is clean.")
        return {"linter_error": "", "status": "valid"}
    else:
        print(f"   [FAIL] PlantUML error: {check['error_message']}")
        return {
            "linter_error": check["error_message"],
            "retry_count": state["retry_count"] + 1,
            "status": "invalid"
        }

def repair_puml_node(state: AgentState) -> dict:
    print(f"-> [Node: RepairPUML] Auto-fixing syntax error (Attempt {state['retry_count']}/3)...")
    template = jinja_env.get_template("repair_puml.j2")
    user_prompt = template.render(
        error_message=state["linter_error"],
        puml_code=state["puml_code"]
    )
    res = llm_client.generate_json(
        system_prompt="You are a PlantUML repair expert. Return JSON with repaired_puml.",
        user_prompt=user_prompt
    )
    return {"puml_code": res.get("repaired_puml", state["puml_code"])}

def escalate_human_node(state: AgentState) -> dict:
    print("-> [Node: Escalate] Max retry count reached. Escalating to human...")
    return {
        "status": "agent-error",
        "error_message": f"Syntax repair exceeded 3 attempts: {state['linter_error']}"
    }

def save_artifacts_node(state: AgentState) -> dict:
    print("-> [Node: SaveArtifacts] Saving YAML specification to specs-repo...")
    specs_root = config.SPECS_REPO_PATH
    out_dir = specs_root / "03_usecases" / state["module_name"]
    out_dir.mkdir(parents=True, exist_ok=True)
    
    uc_id = state["draft_data"].get("id", "UC_DRAFT_001")
    yaml_file = out_dir / f"{uc_id}.yaml"
    
    full_yaml_data = {
        "id": uc_id,
        "title": state["draft_data"].get("title", ""),
        "module": state["module_name"],
        "source_requirements": [state["docx_filename"]],
        "source_atoms": state["draft_data"].get("source_atoms", []),
        "actor": state["draft_data"].get("actor", "Actor"),
        "pre_conditions": state["draft_data"].get("pre_conditions", []),
        "post_conditions": state["draft_data"].get("post_conditions", []),
        "basic_flow": state["draft_data"].get("basic_flow", []),
        "alternative_flows": state["draft_data"].get("alternative_flows", []),
        "robustness_model": state["draft_data"].get("robustness_model", {}),
        "architectural_hints": state["draft_data"].get("architectural_hints", {})
    }
    
    with open(yaml_file, "w", encoding="utf-8") as f:
        yaml.dump(full_yaml_data, f, allow_unicode=True, sort_keys=False)
        
    print(f"   [SAVED] {yaml_file}")
    return {"status": "success"}

# --- Graph Assembly ---

def router(state: AgentState) -> str:
    if state["status"] == "valid":
        return "save"
    if state["retry_count"] >= 3:
        return "escalate"
    return "retry"

def build_agent_graph():
    graph = StateGraph(AgentState)
    graph.add_node("draft_usecase", draft_usecase_node)
    graph.add_node("validate_puml", validate_puml_node)
    graph.add_node("repair_puml", repair_puml_node)
    graph.add_node("escalate_human", escalate_human_node)
    graph.add_node("save_artifacts", save_artifacts_node)

    graph.set_entry_point("draft_usecase")
    graph.add_edge("draft_usecase", "validate_puml")

    graph.add_conditional_edges(
        "validate_puml",
        router,
        {
            "save": "save_artifacts",
            "retry": "repair_puml",
            "escalate": "escalate_human"
        }
    )
    graph.add_edge("repair_puml", "validate_puml")
    graph.add_edge("save_artifacts", END)
    graph.add_edge("escalate_human", END)

    return graph.compile()
