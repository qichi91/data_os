from typing import TypedDict, List, Dict, Any, Optional

class AgentState(TypedDict):
    feature_id: str
    feature_line: str
    docx_filename: str
    module_name: str
    atoms: List[Dict[str, Any]]
    vocabulary: List[Dict[str, Any]]
    draft_data: Dict[str, Any]
    puml_code: str
    linter_error: str
    retry_count: int
    status: str
    error_message: Optional[str]
