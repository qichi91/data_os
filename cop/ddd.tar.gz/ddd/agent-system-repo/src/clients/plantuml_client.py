import httpx
from src.config import config

class PlantUMLValidator:
    def __init__(self):
        self.server_url = config.PLANTUML_SERVER_URL.rstrip("/")

    def validate_puml(self, puml_code: str) -> dict:
        """
        PlantUML Serverの /svg/ エンドポイントへコードをPOSTし構文エラーを検証する。
        """
        url = f"{self.server_url}/svg/"
        try:
            with httpx.Client(timeout=15.0) as client:
                resp = client.post(
                    url,
                    content=puml_code.encode("utf-8"),
                    headers={"Content-Type": "text/plain; charset=utf-8"}
                )
                if resp.status_code != 200:
                    return {
                        "is_valid": False,
                        "error_message": f"Server error: HTTP {resp.status_code}"
                    }

                body = resp.text
                if "Syntax Error?" in body or "[Syntax Error]" in body:
                    return {
                        "is_valid": False,
                        "error_message": "PlantUML Syntax Error: 構文エラーが検出されました。"
                    }
                return {"is_valid": True, "error_message": ""}
        except Exception as e:
            return {
                "is_valid": False,
                "error_message": f"Failed to connect to PlantUML server: {str(e)}"
            }
