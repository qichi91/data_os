import json
import httpx
from src.config import config

class LocalLLMClient:
    def __init__(self):
        self.endpoint = f"{config.LLM_API_BASE_URL}/chat/completions"
        self.model = config.LLM_MODEL_NAME

    def generate_json(self, system_prompt: str, user_prompt: str) -> dict:
        """
        SGLang / vLLM の構造化出力APIを呼び出し、JSONを返却する。
        """
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            "temperature": config.LLM_TEMPERATURE,
            "max_tokens": config.LLM_MAX_TOKENS,
            "response_format": {"type": "json_object"}
        }

        with httpx.Client(timeout=120.0) as client:
            response = client.post(self.endpoint, json=payload)
            response.raise_for_status()
            data = response.json()
            content = data["choices"][0]["message"]["content"]
            return json.loads(content)
