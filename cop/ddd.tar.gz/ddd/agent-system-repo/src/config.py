from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

class AppConfig(BaseSettings):
    SPECS_REPO_PATH: Path = Path("../specs-repo")
    LLM_API_BASE_URL: str = "http://localhost:30000/v1"
    LLM_MODEL_NAME: str = "Qwen/Qwen2.5-14B-Instruct"
    LLM_TEMPERATURE: float = 0.1
    LLM_MAX_TOKENS: int = 4096
    PLANTUML_SERVER_URL: str = "http://localhost:8080"
    GITEA_HOST: str = "http://localhost:3000"
    GITEA_TOKEN: str = ""
    GITEA_REPO_OWNER: str = "architect"
    GITEA_REPO_NAME: str = "specs-repo"

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )

config = AppConfig()
