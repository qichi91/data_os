# agent-system-repo: 自律仕様再構築マルチエージェント基盤

本リポジトリは、旧Word仕様書を解析し、ICONIX分析に基づくユースケース・ロバストネス図を自律生成するLangGraphマルチエージェント実行環境です。

## 主な機能
- **Word Atomizer (`src/parsers/atomizer.py`)**:
  - 段落、テーブル、およびテキストボックス（オートシェイプ）を漏れなく一意ID付きのJSON Linesアトムに分解。
- **LangGraph オーケストレーション (`src/graph/`)**:
  - ユースケース生成、PlantUML Server静的検証、最大3回の自律修復ループ、および人間エスカレーション制御。
- **完全環境ポータビリティ**:
  - Docker Compose、Kubernetes、Coder、スタンドアロンVMで同一コンテナイメージを実行可能。

## 実行方法

### 1. ローカル実行 (Python 3.11 環境)
```bash
pip install -r requirements.txt
cp .env.example .env
# .env のエンドポイント設定を確認
python main.py \
  --feature "受注管理	注文受付	新規登録	F_ORD_001	新規受注登録" \
  --docx "../specs-repo/inputs/raw_docs/sample.docx" \
  --module "MOD01_Order"

```

### 2. Docker / Compose での実行

```bash
docker compose build
docker compose run --rm agent-runner \
  --feature "受注管理	注文受付	新規登録	F_ORD_001	新規受注登録" \
  --docx "/workspace/specs-repo/inputs/raw_docs/sample.docx" \
  --module "MOD01_Order"

```

