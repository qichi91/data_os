import argparse
import sys
import csv
from pathlib import Path
import yaml
from src.config import config
from src.parsers.atomizer import parse_docx_to_atoms
from src.graph.workflow import build_agent_graph

def find_feature_in_tsv(tsv_path: Path, feature_id: str) -> dict:
    """TSVファイルから指定された機能IDの行を検索する"""
    if not tsv_path.exists():
        raise FileNotFoundError(f"TSV file not found: {tsv_path}")
        
    with open(tsv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f, delimiter="\t")
        for row in reader:
            if row.get("feature_id") == feature_id:
                return row
    raise ValueError(f"Feature ID '{feature_id}' not found in {tsv_path}")

def run_pipeline(feature_id: str, docx_paths: list[Path], tsv_path: Path):
    print("=== Starting Autonomous Specification Pipeline ===")
    specs_root = config.SPECS_REPO_PATH
    
    # 1. TSVから機能情報をロード
    print(f"Step 1: Loading Feature Definition [{feature_id}] from TSV...")
    feature_info = find_feature_in_tsv(tsv_path, feature_id)
    feature_line = f"{feature_info['large_name']}\t{feature_info['mid_name']}\t{feature_info['small_name']}\t{feature_id}\t{feature_info['description']}"
    module_name = f"MOD{feature_info['large_id']}_{feature_info['large_name']}"
    
    # 2. 指定されたすべてのWord仕様書をパースしてアトムプールに統合
    print(f"Step 2: Parsing {len(docx_paths)} Word Document(s)...")
    all_atoms = []
    docx_filenames = []
    for docx_path in docx_paths:
        if not docx_path.exists():
            print(f"ERROR: Specified DOCX not found: {docx_path}")
            sys.exit(1)
            
        atoms_file = specs_root / "00_traceability" / "atoms" / f"{docx_path.stem}.jsonl"
        atoms = parse_docx_to_atoms(docx_path, atoms_file)
        all_atoms.extend(atoms)
        docx_filenames.append(docx_path.name)
        
    print(f"   -> Total extracted atoms from all docs: {len(all_atoms)}")

    # 3. 用語集の読み込み (対象モジュールのもののみフィルタ)
    vocab_file = specs_root / "01_architecture" / "domain_vocabulary.yaml"
    vocabulary = []
    if vocab_file.exists():
        with open(vocab_file, "r", encoding="utf-8") as f:
            v_data = yaml.safe_load(f) or {}
            vocabulary = [item for item in v_data.get("vocabulary", []) if item.get("module") == module_name]

    # 4. LangGraph マルチエージェントの実行
    print("Step 3: Executing LangGraph Multi-Agent Orchestration...")
    app = build_agent_graph()
    
    initial_state = {
        "feature_id": feature_id,
        "feature_line": feature_line,
        "docx_filename": ", ".join(docx_filenames),
        "module_name": module_name,
        "atoms": all_atoms[:25], # 複数文書から抽出された上位アトムを注入
        "vocabulary": vocabulary,
        "draft_data": {},
        "puml_code": "",
        "linter_error": "",
        "retry_count": 0,
        "status": "init",
        "error_message": None
    }
    
    final_state = app.invoke(initial_state)
    
    if final_state["status"] == "success":
        print(f"=== Pipeline Completed Successfully for {feature_id}. ===")
        sys.exit(0)
    else:
        print(f"=== Pipeline Ended with Warning/Error: {final_state.get('error_message')} ===")
        sys.exit(2)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Autonomous Specification Agent CLI")
    parser.add_argument("--feature-id", required=True, help="Target feature ID in TSV (e.g. F-01-01-01)")
    parser.add_argument("--docx", nargs="+", required=True, help="One or more paths to legacy Word files")
    parser.add_argument("--tsv", default=None, help="Path to features.tsv (default: specs-repo/inputs/features.tsv)")
    
    args = parser.parse_args()
    
    tsv_file = Path(args.tsv) if args.tsv else config.SPECS_REPO_PATH / "inputs" / "features.tsv"
    docx_file_list = [Path(p) for p in args.docx]
    
    run_pipeline(args.feature_id, docx_file_list, tsv_file)