#!/usr/bin/env bash
set -euo pipefail

REPO_DIR="specs-repo"

echo "=== 概要設計成果物リポジトリ [${REPO_DIR}] の作成を開始します ==="

# 1. リポジトリディレクトリの作成と初期化
mkdir -p "${REPO_DIR}"
cd "${REPO_DIR}"

if [ ! -d ".git" ]; then
    git init
    echo "Initialized empty Git repository in $(pwd)/.git"
fi

# 2. ディレクトリ構造の作成
mkdir -p .schemas
mkdir -p .gitea/workflows
mkdir -p templates
mkdir -p inputs/raw_docs
mkdir -p 00_traceability
mkdir -p 01_architecture
mkdir -p 02_domains/MOD01_Order
mkdir -p 03_usecases/MOD01_Order
mkdir -p scripts
mkdir -p assets/diagrams

echo "Directories created successfully."

# 3. .gitignore の作成
cat << 'EOF' > .gitignore
# Python
__pycache__/
*.py[cod]
*$py.class
.venv/
venv/
ENV/

# OS / Editor
.DS_Store
Thumbs.db
.vscode/
.idea/

# Local cache & intermediate data
*.sqlite3
*.sqlite3-journal
.cache/
EOF

# 4. README.md の作成
cat << 'EOF' > README.md
# specs-repo (概要設計・内部仕様リポジトリ)

本リポジトリは、旧仕様書の再構築、ICONIXプロセスに基づくユースケース分析、およびC++クリーンアーキテクチャ（モジュラーモノリス）実装に向けた概要設計成果物を管理するリポジトリです。

## 運用方針
1. **スキーマ駆動管理**: 人間および自律エージェントは、Markdownを直接手編集せず、`.schemas/` で定義されたYAMLファイルを直接編集します。
2. **自動Markdown生成**: 仕様ドキュメント（MarkdownおよびPlantUML）は、`scripts/render_docs.py` によりYAMLから決定論的に生成されます。
3. **ICONIX粒度ポリシー**:
   - **システムユースケース**: 1アクターが1セッションで完結する業務目的。基本コース2〜5ステップ、代替コース2〜5個程度を目安とする。
   - **能動態記述**: 「アクターは〜を入力する」「システムは〜を検証する」という主客を明確にした記述を徹底する。
   - **UI非依存**: ボタンの色や配置は記述せず、論理的なデータ送受信と業務ルールに集中する。

## ディレクトリ構成
- `inputs/`: 新機能一覧TSVおよび解析対象の旧仕様書ファイル
- `.schemas/`: YAML Editorおよびバリデータが参照するJSON/YAMLスキーマ
- `templates/`: MarkdownおよびPlantUML変換用のJinja2テンプレート
- `00_traceability/`: 旧仕様書の要件網羅性と廃止理由を追跡するマトリクス
- `01_architecture/`: モジュール境界定義およびゲートウェイ電文共通仕様
- `02_domains/`: ドメインモデルおよびGeode Key-Value Region定義
- `03_usecases/`: ユースケース別YAML定義および自動生成Markdown
- `scripts/`: スキーマ検証およびドキュメント自動生成スクリプト
EOF

# 5. 入力サンプル (inputs/features.tsv) の作成
cat << 'EOF' > inputs/features.tsv
大区分	中区分	小区分	機能ID	機能名	概要
受注管理	注文受付	新規登録	F_ORD_001	新規受注登録	クライアントUIからの注文入力受付と与信確認および登録処理
受注管理	注文受付	注文取消	F_ORD_002	受注取消	確定前または出荷手配前の注文キャンセル処理
受注管理	配送指示	電文送信	F_ORD_003	配送依頼電文送信	外部配送ゲートウェイに対する配送要求電文の生成と送信キュー登録
在庫管理	引当処理	在庫引当	F_STK_001	リアルタイム在庫引当	受注発生時のGeode在庫データ即時減算および引当保留
EOF

touch inputs/raw_docs/.gitkeep

# 6. スキーマ定義 (.schemas/usecase.schema.yaml) の作成
cat << 'EOF' > .schemas/usecase.schema.yaml
$schema: "http://json-schema.org/draft-07/schema#"
title: "IconixUseCaseSchema"
description: "ICONIXプロセスおよびC++クリーンアーキテクチャ設計に最適化されたユースケース定義スキーマ"
type: object
required:
  - id
  - title
  - module
  - actor
  - pre_conditions
  - post_conditions
  - basic_flow
properties:
  id:
    type: string
    description: "ユースケース識別子"
    pattern: "^UC_[A-Z0-9]+_[0-9]{3}$"
  title:
    type: string
    description: "ユースケース名 (動詞 + 目的語)"
  module:
    type: string
    description: "所属モジュール (モジュラーモノリス境界)"
  source_requirements:
    type: array
    description: "旧仕様書の該当セクションまたは要件ID"
    items:
      type: string
  actor:
    type: string
    description: "主アクター (クライアントUI、オペレーター等)"
  pre_conditions:
    type: array
    description: "前提条件一覧"
    items:
      type: string
    minItems: 1
  post_conditions:
    type: array
    description: "事後条件一覧"
    items:
      type: string
    minItems: 1
  basic_flow:
    type: array
    description: "基本コース (能動態のステップリスト)"
    minItems: 2
    items:
      type: object
      required:
        - step
        - actor_action
        - system_response
      properties:
        step:
          type: integer
        actor_action:
          type: string
        system_response:
          type: string
  alternative_flows:
    type: array
    description: "代替コース (例外・エラー)"
    items:
      type: object
      required:
        - id
        - resume_step
        - condition
        - handling
      properties:
        id:
          type: string
        resume_step:
          type: integer
        condition:
          type: string
        handling:
          type: string
  robustness_model:
    type: object
    description: "ICONIXロバストネス図要素定義"
    required:
      - boundaries
      - controls
      - entities
      - relations
    properties:
      boundaries:
        type: array
        items:
          type: object
          required: [name, alias]
          properties:
            name: { type: string }
            alias: { type: string }
      controls:
        type: array
        items:
          type: object
          required: [name, alias]
          properties:
            name: { type: string }
            alias: { type: string }
      entities:
        type: array
        items:
          type: object
          required: [name, alias]
          properties:
            name: { type: string }
            alias: { type: string }
      relations:
        type: array
        items:
          type: object
          required: [from, to, label]
          properties:
            from: { type: string }
            to: { type: string }
            label: { type: string }
  architectural_hints:
    type: object
    description: "アーキテクチャ境界定義"
    properties:
      geode_regions:
        type: array
        items: { type: string }
      gateway_destinations:
        type: array
        items: { type: string }
EOF

# 7. スキーマ定義 (.schemas/domain.schema.yaml) の作成
cat << 'EOF' > .schemas/domain.schema.yaml
$schema: "http://json-schema.org/draft-07/schema#"
title: "GeodeDomainSchema"
description: "Apache Geode Key-Value Regionおよびドメインモデル定義スキーマ"
type: object
required:
  - module
  - regions
properties:
  module:
    type: string
  regions:
    type: array
    items:
      type: object
      required:
        - region_name
        - region_type
        - key_spec
        - value_spec
      properties:
        region_name:
          type: string
        region_type:
          type: string
          enum: ["PARTITION", "REPLICATE", "LOCAL"]
        key_spec:
          type: object
          required: [field_name, data_type, format_rule]
          properties:
            field_name: { type: string }
            data_type: { type: string }
            format_rule: { type: string }
        value_spec:
          type: object
          required: [entity_name, fields]
          properties:
            entity_name: { type: string }
            fields:
              type: array
              items:
                type: object
                required: [name, type, nullable]
                properties:
                  name: { type: string }
                  type: { type: string }
                  nullable: { type: boolean }
                  description: { type: string }
EOF

# 8. スキーマ定義 (.schemas/traceability.schema.yaml) の作成
cat << 'EOF' > .schemas/traceability.schema.yaml
$schema: "http://json-schema.org/draft-07/schema#"
title: "TraceabilitySchema"
description: "旧仕様書網羅性・廃止機能追跡マトリクススキーマ"
type: object
required:
  - requirements
properties:
  requirements:
    type: array
    items:
      type: object
      required:
        - old_id
        - source_title
        - source_doc
        - status
      properties:
        old_id:
          type: string
        source_title:
          type: string
        source_doc:
          type: string
        status:
          type: string
          enum: ["Active", "Deprecated", "UnderReview"]
        reason_for_status:
          type: string
        mapped_module:
          type: string
        mapped_usecase:
          type: [string, "null"]
        validation_status:
          type: string
          enum: ["Unverified", "Verified", "Conflict"]
EOF

# 9. Markdown変換用 Jinja2テンプレート (templates/usecase.md.j2) の作成
cat << 'EOF' > templates/usecase.md.j2
<!-- AUTO-GENERATED FROM {{ id }}.yaml. DO NOT EDIT DIRECTLY. -->
# {{ id }}: {{ title }}

## 1. 概要
- **モジュール**: `{{ module }}`
- **主アクター**: {{ actor }}
- **旧仕様追跡**: {% if source_requirements %}{{ source_requirements | join(', ') }}{% else %}新規追加{% endif %}

### 事前条件
{% for pre in pre_conditions %}
- {{ pre }}
{% endfor %}

### 事後条件
{% for post in post_conditions %}
- {{ post }}
{% endfor %}

---

## 2. ロバストネス分析 (ICONIX)
```plantuml
@startuml
skinparam monochrome true
skinparam packageStyle rectangle

actor "{{ actor }}" as Actor

{% if robustness_model %}
package "Boundary" {
{% for b in robustness_model.boundaries %}
    boundary "{{ b.name }}" as {{ b.alias }}
{% endfor %}
}

package "Control" {
{% for c in robustness_model.controls %}
    control "{{ c.name }}" as {{ c.alias }}
{% endfor %}
}

package "Entity" {
{% for e in robustness_model.entities %}
    entity "{{ e.name }}" as {{ e.alias }}
{% endfor %}
}

' --- 接続定義 ---
{% for rel in robustness_model.relations %}
{{ rel.from }} --> {{ rel.to }} : {{ rel.label }}
{% endfor %}
{% endif %}
@enduml

```

---

## 3. 基本コース (Happy Path)

| ステップ | アクターの操作 | システムの応答・処理 |
| --- | --- | --- |
| {% for step in basic_flow %} |  |  |
| {{ step.step }} | {{ step.actor_action }} | {{ step.system_response }} |
| {% endfor %} |  |  |

---

## 4. 代替コース (Exceptions & Alternatives)

{% if alternative_flows %}
{% for alt in alternative_flows %}

### {{ alt.id }}. 分岐元ステップ {{ alt.resume_step }}

* **発生条件**: {{ alt.condition }}
* **システムの処理**: {{ alt.handling }}
{% endfor %}
{% else %}
*特記事項なし*
{% endif %}

---

## 5. アーキテクチャ連携仕様

{% if architectural_hints %}

### Geode Region 候補

{% for reg in architectural_hints.geode_regions %}

* `{{ reg }}`
{% endfor %}

### 外部ゲートウェイ宛先

{% for gw in architectural_hints.gateway_destinations %}

* `{{ gw }}`
{% endfor %}
{% else %}
*特記事項なし*
{% endif %}
EOF

# 10. ドメインモデル変換用 Jinja2テンプレート (templates/domain.md.j2) の作成

cat << 'EOF' > templates/domain.md.j2

# ドメインモデル & Geode KV 仕様: {{ module }}

## 1. Geode Region 定義一覧

| Region名 | 種別 | Keyデータ型 | Key採番規則 | 対象Entity |
| --- | --- | --- | --- | --- |
| {% for r in regions %} |  |  |  |  |
| `{{ r.region_name }}` | {{ r.region_type }} | `{{ r.key_spec.data_type }}` | `{{ r.key_spec.format_rule }}` | `{{ r.value_spec.entity_name }}` |
| {% endfor %} |  |  |  |  |

## 2. Entity 属性詳細 (Value 仕様)

{% for r in regions %}

### {{ r.value_spec.entity_name }} (Region: `{{ r.region_name }}`)

| フィールド物理名 | C++型 | Null許容 | 説明 |
| --- | --- | --- | --- |
| {% for f in r.value_spec.fields %} |  |  |  |
| `{{ f.name }}` | `{{ f.type }}` | {% if f.nullable %}Yes{% else %}No{% endif %} | {{ f.description }} |
| {% endfor %} |  |  |  |
| {% endfor %} |  |  |  |
| EOF |  |  |  |

# 11. トレーサビリティ初期データ (00_traceability/requirement_matrix.yaml) の作成

cat << 'EOF' > 00_traceability/requirement_matrix.yaml
requirements:

* old_id: "OLD-SEC-04-02"
source_title: "4.2 手動配送指示機能"
source_doc: "旧仕様書_販売管理_v1.0.docx"
status: "Deprecated"
reason_for_status: "次期システムでは自動配送依頼電文送信に統合されるため手動指示画面は廃止"
mapped_module: "OrderManagement"
mapped_usecase: null
validation_status: "Verified"
* old_id: "OLD-SEC-04-03"
source_title: "4.3 注文確定および電文通知"
source_doc: "旧仕様書_販売管理_v1.0.docx"
status: "Active"
reason_for_status: "基幹業務のためそのまま引き継ぎ"
mapped_module: "OrderManagement"
mapped_usecase: "UC_MOD01_001"
validation_status: "Verified"
EOF

# 12. アーキテクチャ共通仕様 (01_architecture/) の作成

cat << 'EOF' > 01_architecture/modular_boundaries.md

# モジュラーモノリス境界設計と依存性ルール

本システムは、将来的かつ段階的な疎結合化を見据えたモジュラーモノリスを採用し、各モジュール内はクリーンアーキテクチャの原則に厳格に従います。

## 1. モジュール一覧と責務

* `MOD01_Order` (OrderManagement): 受注登録、注文変更、受注ステータス管理。
* `MOD02_Stock` (StockManagement): Geodeを用いたリアルタイム在庫引当、在庫増減。
* `MOD03_Gateway` (MessageGateway): 多種多様な外部プロトコルとの電文送受信アダプタ。

## 2. 依存関係の禁止事項

1. **モジュール間直接DBアクセスの禁止**: 他モジュールのGeode Regionを直接参照・更新してはならない。必ずモジュール公開インターフェースを経由すること。
2. **クリーンアーキテクチャ内層への逆依存禁止**:
* `Domain` 層は他の一切の層に依存しない。
* `UseCase` 層は `Domain` 層のみに依存し、`Infrastructure` 層（Geode実体やソケット通信）には直接依存しない（DIPの適用）。
EOF



cat << 'EOF' > 01_architecture/common_messaging_spec.md

# 外部ゲートウェイ電文共通仕様（枠組み）

外部システムとの多種多様なプロトコル差分は外部ゲートウェイ側で吸収されます。アプリケーションプロセスからは、統一された抽象電文枠組み（ヘッダー＋ペイロード）を用いて非同期に通信を行います。

## 1. 共通電文構造

```text
+-------------------------------------------------------------+

| 共通電文ヘッダー (Common Message Header) |
| - trace_id       : トランザクション追跡用UUID (string) |
| - destination    : 論理宛先システムID (string) |
| - message_type   : 電文種別コード (string) |
| - timestamp      : 送信エポックミリ秒 (int64_t) |
+-------------------------------------------------------------+

| メッセージペイロード (Message Payload) |
| - 各ユースケース固有のデータ構造 (JSON / 構造体シリアライズ) |
+-------------------------------------------------------------+

```

## 2. 通信方式

* **通常送信**: Application -> MQ -> Gateway -> 外部プロトコル
* **エラー処理**: GWからの応答タイムアウト時は、ユースケース定義の代替コースに従い再送またはステータスロールバックを実行する。
EOF

# 13. ドメイン定義サンプル (02_domains/MOD01_Order/domain_entities.yaml) の作成

cat << 'EOF' > 02_domains/MOD01_Order/domain_entities.yaml
module: "OrderManagement"
regions:

* region_name: "/Orders"
region_type: "PARTITION"
key_spec:
field_name: "order_id"
data_type: "std::string"
format_rule: "ORD-{YYYYMMDD}-{SEQ8}"
value_spec:
entity_name: "OrderEntity"
fields:
- name: "order_id"
type: "std::string"
nullable: false
description: "受注一意識別子 (主キー)"
- name: "customer_id"
type: "std::string"
nullable: false
description: "発注元顧客ID"
- name: "total_amount"
type: "int64_t"
nullable: false
description: "注文合計金額 (税込)"
- name: "order_status"
type: "std::string"
nullable: false
description: "ステータス (Confirmed, PendingApproval, DeliveryFailed, Cancelled)"
- name: "created_at"
type: "int64_t"
nullable: false
description: "作成日時 (UNIXエポックミリ秒)"
EOF

# 14. ユースケース定義サンプル (03_usecases/MOD01_Order/UC_MOD01_001.yaml) の作成

cat << 'EOF' > 03_usecases/MOD01_Order/UC_MOD01_001.yaml
id: "UC_MOD01_001"
title: "新規受注を登録する"
module: "OrderManagement"
source_requirements:

* "OLD-SEC-04-03"
actor: "クライアントUI (オペレーター)"

pre_conditions:

* "オペレーターがログイン認証済みであること"
* "対象顧客がGeode上に存在すること"

post_conditions:

* "受注EntityがGeodeの /Orders にConfirmedステータスで保存されていること"
* "配送依頼電文が外部GW向け送信キューに登録されていること"

basic_flow:

* step: 1
actor_action: "顧客IDおよび注文明細リストを入力し、登録要求を送信する"
system_response: "入力項目の必須チェックおよび注文数量が正の整数であることを検証する"
* step: 2
actor_action: "（システム自動処理）"
system_response: "顧客の与信状態をGeodeから取得し、限度額内であることを確認する"
* step: 3
actor_action: "（システム自動処理）"
system_response: "新規受注Entityを作成し、ConfirmedステータスでGeodeの /Orders に保存する"
* step: 4
actor_action: "（システム自動処理）"
system_response: "配送依頼電文を作成し、外部GW向けキューへ送信する"
* step: 5
actor_action: "登録完了通知を受け取る"
system_response: "採番された受注IDおよび処理完了メッセージを画面に返却する"

alternative_flows:

* id: "1a"
resume_step: 1
condition: "必須項目が欠落しているか、数量が0以下の場合"
handling: "入力検証エラーメッセージを画面に返却し、処理を終了する"
* id: "2a"
resume_step: 2
condition: "顧客の与信限度額を超過している場合"
handling: "受注ステータスをPendingApprovalとして保存し、承認待ち通知を返却して電文送信を保留する"
* id: "4a"
resume_step: 4
condition: "外部GW向けキューへの登録に失敗またはタイムアウトした場合"
handling: "受注ステータスをDeliveryFailedに更新し、警告ログを出力して画面にその旨を通知する"

robustness_model:
boundaries:
- name: "受注登録画面"
alias: "UI"
- name: "外部配送GWクライアント"
alias: "DeliveryGW"
controls:
- name: "受注登録コントローラー"
alias: "OrderCtrl"
- name: "与信確認コントローラー"
alias: "CreditCtrl"
- name: "電文送信コントローラー"
alias: "MsgCtrl"
entities:
- name: "顧客情報 (Geode)"
alias: "CustomerEntity"
- name: "受注データ (Geode)"
alias: "OrderEntity"
- name: "配送依頼電文"
alias: "DeliveryMessage"
relations:
- from: "Actor"
to: "UI"
label: "注文情報を入力・登録"
- from: "UI"
to: "OrderCtrl"
label: "登録コマンド送信"
- from: "OrderCtrl"
to: "CreditCtrl"
label: "与信チェック要求"
- from: "CreditCtrl"
to: "CustomerEntity"
label: "与信枠照会"
- from: "OrderCtrl"
to: "OrderEntity"
label: "受注インスタンス生成・保存"
- from: "OrderCtrl"
to: "MsgCtrl"
label: "電文作成依頼"
- from: "MsgCtrl"
to: "DeliveryMessage"
label: "ペイロード構築"
- from: "MsgCtrl"
to: "DeliveryGW"
label: "送信要求"
- from: "DeliveryGW"
to: "DeliveryMessage"
label: "外部キューへ転送"
- from: "OrderCtrl"
to: "UI"
label: "完了結果表示"

architectural_hints:
geode_regions:
- "/Orders"
- "/Customers"
gateway_destinations:
- "GW.DEST.LOGISTICS_SYSTEM"
EOF

# 15. スクリプト (scripts/validate_schemas.py) の作成

cat << 'EOF' > scripts/validate_schemas.py
#!/usr/bin/env python3
"""
リポジトリ内のすべてのYAMLファイルが .schemas/ の定義に準拠しているか検証するスクリプト
"""
import sys
from pathlib import Path
import yaml
try:
import jsonschema
except ImportError:
print("WARNING: jsonschema package not installed. Skipping deep schema validation.")
sys.exit(0)

def load_yaml(path: Path):
with open(path, "r", encoding="utf-8") as f:
return yaml.safe_load(f)

def validate():
root = Path(**file**).resolve().parent.parent
schemas_dir = root / ".schemas"

```
uc_schema = load_yaml(schemas_dir / "usecase.schema.yaml")
domain_schema = load_yaml(schemas_dir / "domain.schema.yaml")
trace_schema = load_yaml(schemas_dir / "traceability.schema.yaml")

errors = 0

# 1. ユースケースYAML検証
for yml in (root / "03_usecases").glob("**/*.yaml"):
    data = load_yaml(yml)
    try:
        jsonschema.validate(instance=data, schema=uc_schema)
        print(f"[PASS] {yml.relative_to(root)}")
    except jsonschema.ValidationError as e:
        print(f"[FAIL] {yml.relative_to(root)}: {e.message}")
        errors += 1
        
# 2. ドメインYAML検証
for yml in (root / "02_domains").glob("**/*.yaml"):
    data = load_yaml(yml)
    try:
        jsonschema.validate(instance=data, schema=domain_schema)
        print(f"[PASS] {yml.relative_to(root)}")
    except jsonschema.ValidationError as e:
        print(f"[FAIL] {yml.relative_to(root)}: {e.message}")
        errors += 1

# 3. トレーサビリティ検証
trace_file = root / "00_traceability" / "requirement_matrix.yaml"
if trace_file.exists():
    data = load_yaml(trace_file)
    try:
        jsonschema.validate(instance=data, schema=trace_schema)
        print(f"[PASS] {trace_file.relative_to(root)}")
    except jsonschema.ValidationError as e:
        print(f"[FAIL] {trace_file.relative_to(root)}: {e.message}")
        errors += 1
        
if errors > 0:
    print(f"\nTotal Validation Errors: {errors}")
    sys.exit(1)
else:
    print("\nAll YAML files strictly match the schema definitions.")

```

if **name** == "**main**":
validate()
EOF
chmod +x scripts/validate_schemas.py

# 16. スクリプト (scripts/render_docs.py) の作成

cat << 'EOF' > scripts/render_docs.py
#!/usr/bin/env python3
"""
YAMLファイルからJinja2テンプレートを用いてMarkdownドキュメントを一括生成するスクリプト
"""
import sys
from pathlib import Path
import yaml
try:
from jinja2 import Environment, FileSystemLoader
except ImportError:
print("ERROR: jinja2 is required. Please install via: pip install jinja2")
sys.exit(1)

def render_all():
root = Path(**file**).resolve().parent.parent
templates_dir = root / "templates"
env = Environment(loader=FileSystemLoader(str(templates_dir)), trim_blocks=True, lstrip_blocks=True)

```
uc_template = env.get_template("usecase.md.j2")
domain_template = env.get_template("domain.md.j2")

# 1. ユースケースMarkdownの生成
for yml_path in (root / "03_usecases").glob("**/*.yaml"):
    with open(yml_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
        
    md_content = uc_template.render(data)
    out_path = yml_path.with_suffix(".md")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(md_content)
    print(f"[RENDERED] {out_path.relative_to(root)}")
    
# 2. ドメインモデルMarkdownの生成
for yml_path in (root / "02_domains").glob("**/*.yaml"):
    with open(yml_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
        
    md_content = domain_template.render(data)
    out_path = yml_path.with_suffix(".md")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(md_content)
    print(f"[RENDERED] {out_path.relative_to(root)}")

```

if **name** == "**main**":
render_all()
EOF
chmod +x scripts/render_docs.py

# 17. Gitea Actions ワークフロー定義の作成

cat << 'EOF' > .gitea/workflows/render_and_validate.yaml
name: Validate Schemas and Render Markdown

on:
push:
paths:
- '**.yaml'
- 'templates/**'
pull_request:
paths:
- '.yaml'

jobs:
build:
runs-on: ubuntu-latest
steps:
- name: Checkout Code
uses: actions/checkout@v3

```
  - name: Set up Python
    uses: actions/setup-python@v4
    with:
      python-version: '3.11'

  - name: Install Dependencies
    run: |
      pip install pyyaml jinja2 jsonschema

  - name: Validate YAML Schemas
    run: |
      python scripts/validate_schemas.py

  - name: Render Markdown Documents
    run: |
      python scripts/render_docs.py

  - name: Check for Uncommitted Markdown Changes
    run: |
      if [ -n "$(git status --porcelain '*.md')" ]; then
        echo "ERROR: Markdown files are out of sync with YAML source. Run scripts/render_docs.py and commit."
        git diff
        exit 1
      fi

```

EOF

# 18. 初回ドキュメントレンダリングの実行（PythonとJinja2が利用可能な場合）

if command -v python3 >/dev/null 2>&1 && python3 -c "import jinja2, yaml" >/dev/null 2>&1; then
echo "Running initial document rendering..."
python3 scripts/render_docs.py
else
echo "Python3 with jinja2/yaml not found. Skipping initial render (can be run later)."
fi

# 19. Git への全追加と初期コミット

git add .
git commit -m "chore: initial commit for specs-repo structure and schemas"

echo "=== リポジトリの初期化が完全に完了しました ==="
echo "Path: $(pwd)"
