
# specs-repo: 概要設計・ICONIX分析 運用マニュアル (SOP)

本リポジトリは、旧仕様書から新アーキテクチャ（C++モジュラーモノリス）へ移行するための概要設計成果物、および要件トレーサビリティを管理します。

---

## 1. 運用原則 (Core Policies)

1. **Single Source of Truth (SSoT)**:
* 正本データはすべて `.schemas/` に準拠した **YAML** および **JSON Lines** です。
* MarkdownおよびPlantUMLは `scripts/render_docs.py` により機械生成される閲覧用成果物であり、直接編集は禁止です。


2. **完全トレーサビリティ保証**:
* 旧仕様書の全記述は `00_traceability/atoms/*.jsonl` にアトム単位で登録されます。
* すべてのアトムは、「ユースケースの根拠として採用される」か「`00_traceability/deprecated_features.yaml` に廃止理由を明記する」かのいずれかでなければならず、カバレッジ100%をCIで検証します。


3. **ICONIX粒度ポリシー**:
* **システムユースケース**: 1アクターが1回の対話セッションで達成する目的。基本コース2〜5ステップ、代替コース2〜5個程度を目安とする。
* **能動態記述**: 「アクターは〜を入力する」「システムは〜を検証する」という主客を明確にした記述を徹底する。
* **UI非依存**: ボタンの色や配置は記述せず、論理的なデータ送受信と業務ルールに集中する。



---

## 2. 状態遷移とラベル運用 (Gitea Issue駆動)

エージェントと人間の協働作業は、Gitea Issueのラベル状態遷移によって制御されます。

| ラベル名 | 状態 | 担当 | アクション |
| --- | --- | --- | --- |
| `status:ready-for-agent` | 処理待ち | 人間 | TSV機能IDと旧Wordファイルを指定してIssueに付与。 |
| `status:processing` | 処理中 | エージェント | `tea` 経由で検知し、ブランチ作成とドラフト生成を実行。 |
| `status:review-required` | レビュー待ち | 人間 | エージェントがPRを起票後に付与。人間がYAMLをレビュー。 |
| `status:agent-error` | 要エスカレーション | 人間 | 構文エラー修復上限（3回）超過時。人間が介入して修正。 |
| `status:done` | 完了 | - | PRがmainブランチへマージされた状態。 |

---

## 3. 人間とエージェントの作業手順

### ステップ1: 旧仕様書と新機能のインプット登録

1. `inputs/features.tsv` に大中小の機能一覧を配置する。
2. `inputs/raw_docs/` に解析対象の旧仕様書Wordファイルを配置する。
3. Issueを作成し、`status:ready-for-agent` ラベルを付与する。

### ステップ2: エージェントによるドラフト生成

1. エージェントがWordをアトム化し、`00_traceability/atoms/*.jsonl` に保存。
2. 対象モジュールの用語集（`01_architecture/domain_vocabulary.yaml`）を参照し、`UC_*.yaml` を生成。
3. PlantUML Serverによる構文検証、スキーマ検証、ドキュメントレンダリングを実行。
4. PRを自動起票し、ラベルを `status:review-required` に更新。

### ステップ3: 人間によるレビューと修正

1. PR上のMarkdownおよびPlantUMLプレビューを確認。
2. 修正が必要な場合は、VSCodeの `yaml_editor` 拡張を用いて対象の `UC_*.yaml` または `domain_vocabulary.yaml` を直接編集してコミット。
3. 不要となった旧仕様記述は `00_traceability/deprecated_features.yaml` に理由を記載して追加。
4. `python scripts/check_coverage.py` を実行し、カバレッジが100%であることを確認してマージ。

---

## 4. ディレクトリ構成

* `inputs/`: 新機能TSVおよび旧Word仕様書
* `.schemas/`: 各種YAML/JSONLが準拠すべきJSON Schema
* `templates/`: Jinja2変換テンプレート
* `00_traceability/`: 要件アトム、廃止台帳、カバレッジレポート
* `01_architecture/`: モジュール境界定義、ゲートウェイ共通電文、共通用語集
* `02_domains/`: Geode Regionおよびドメインモデル定義
* `03_usecases/`: ユースケース別YAML定義および自動生成Markdown
* `assets/inspections/`: 未抽出オートシェイプや要目視確認用データの退避先
* `scripts/`: 検証・生成・CI用スクリプト
