#!/usr/bin/env python3
"""
YAMLファイルからJinja2テンプレートを用いてMarkdownドキュメントを一括生成するスクリプト
"""
import sys
from pathlib import Path
import yaml
try:
from jinja2 import Environment, FileSystemLoader
except ImportError:
print("ERROR: jinja2 is required. Please install via: pip install jinja2")
sys.exit(1)

def render_all():
root = Path(**file**).resolve().parent.parent
templates_dir = root / "templates"
env = Environment(loader=FileSystemLoader(str(templates_dir)), trim_blocks=True, lstrip_blocks=True)

```
uc_template = env.get_template("usecase.md.j2")
domain_template = env.get_template("domain.md.j2")
vocab_template = env.get_template("vocabulary.md.j2")

# 1. ユースケースMarkdownの生成
for yml_path in (root / "03_usecases").glob("**/*.yaml"):
    with open(yml_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
        
    md_content = uc_template.render(data)
    out_path = yml_path.with_suffix(".md")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(md_content)
    print(f"[RENDERED] {out_path.relative_to(root)}")
    
# 2. ドメインモデルMarkdownの生成
for yml_path in (root / "02_domains").glob("**/*.yaml"):
    with open(yml_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
        
    md_content = domain_template.render(data)
    out_path = yml_path.with_suffix(".md")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(md_content)
    print(f"[RENDERED] {out_path.relative_to(root)}")

# 3. 用語集Markdownの生成
vocab_file = root / "01_architecture" / "domain_vocabulary.yaml"
if vocab_file.exists():
    with open(vocab_file, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    md_content = vocab_template.render(data)
    out_path = vocab_file.with_suffix(".md")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(md_content)
    print(f"[RENDERED] {out_path.relative_to(root)}")

```

if **name** == "**main**":
render_all()
