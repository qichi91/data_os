#!/usr/bin/env bash
set -euo pipefail

ISSUE_INDEX="${1:-}"
if [ -z "${ISSUE_INDEX}" ]; then
    echo "Usage: $0 <issue-index>"
    exit 1
fi

echo "=== Fetching Issue #${ISSUE_INDEX} via tea ==="
ISSUE_JSON=$(tea issue show "${ISSUE_INDEX}" --output json)

# 1. Issue本文から feature_id と docx_paths を抽出 (簡易grep/sedまたはjq等で取得)
# ここでは Issue フォームの入力項目を抽出
FEATURE_ID=$(echo "${ISSUE_JSON}" | grep -A 1 "対象機能ID" | tail -n 1 | tr -d '\r ' || true)
if [ -z "${FEATURE_ID}" ]; then
    # タイトルから [Draft]: F-01-01-01 のように拾うフォールバック
    FEATURE_ID=$(echo "${ISSUE_JSON}" | grep -oE "F-[0-9]{2}-[0-9]{2}-[0-9]{2}" | head -n 1)
fi

# 2. 状態を processing に更新
tea issue edit "${ISSUE_INDEX}" --remove-labels "status:ready-for-agent" --add-labels "status:processing"

BRANCH_NAME="draft/issue-${ISSUE_INDEX}-${FEATURE_ID}"
git checkout -b "${BRANCH_NAME}"

# 3. エージェントパイプラインを実行 (Wordファイル群は raw_docs 配下を探索)
# 例: raw_docs 配下の指定ファイル、またはディレクトリ内の該当ファイルを渡す
python3 /workspace/agent-system/main.py \
  --feature-id "${FEATURE_ID}" \
  --docx /workspace/specs-repo/inputs/raw_docs/*.docx

# 4. ドキュメントレンダリングとカバレッジ更新
python3 scripts/validate_schemas.py
python3 scripts/render_docs.py
python3 scripts/check_coverage.py

# 5. Git コミット & Push & PR作成
git add specs/ 00_traceability/
git commit -m "feat(spec): auto-draft for ${FEATURE_ID} (Issue #${ISSUE_INDEX}) [skip ci]"
git push -u origin "${BRANCH_NAME}"

PR_URL=$(tea pr create \
    --title "Draft: ${FEATURE_ID} ユースケース・ICONIX分析ドラフト" \
    --description "Issue #${ISSUE_INDEX} に基づき生成されました。YAML定義をレビューしてください。\n\nRefs #${ISSUE_INDEX}" \
    --source-branch "${BRANCH_NAME}" \
    --target-branch "main")

tea issue comment "${ISSUE_INDEX}" "エージェントのドラフト生成が完了しました。PRを確認してください: ${PR_URL}"
tea issue edit "${ISSUE_INDEX}" --remove-labels "status:processing" --add-labels "status:review-required"

echo "=== Completed Issue #${ISSUE_INDEX} ==="