#!/usr/bin/env python3
"""
リポジトリ内の全YAMLファイルおよびJSONLアトムが定義に準拠しているか検証するスクリプト
"""
import sys
import json
from pathlib import Path
import yaml
try:
import jsonschema
except ImportError:
print("WARNING: jsonschema not installed. Skipping deep schema validation.")
sys.exit(0)

def load_yaml(path: Path):
with open(path, "r", encoding="utf-8") as f:
return yaml.safe_load(f)

def validate():
root = Path(**file**).resolve().parent.parent
schemas_dir = root / ".schemas"

```
uc_schema = load_yaml(schemas_dir / "usecase.schema.yaml")
domain_schema = load_yaml(schemas_dir / "domain.schema.yaml")
vocab_schema = load_yaml(schemas_dir / "vocabulary.schema.yaml")

errors = 0

# 1. ユースケースYAML検証
for yml in (root / "03_usecases").glob("**/*.yaml"):
    data = load_yaml(yml)
    try:
        jsonschema.validate(instance=data, schema=uc_schema)
        print(f"[PASS] {yml.relative_to(root)}")
    except jsonschema.ValidationError as e:
        print(f"[FAIL] {yml.relative_to(root)}: {e.message}")
        errors += 1
        
# 2. ドメインYAML検証
for yml in (root / "02_domains").glob("**/*.yaml"):
    data = load_yaml(yml)
    try:
        jsonschema.validate(instance=data, schema=domain_schema)
        print(f"[PASS] {yml.relative_to(root)}")
    except jsonschema.ValidationError as e:
        print(f"[FAIL] {yml.relative_to(root)}: {e.message}")
        errors += 1

# 3. 用語集YAML検証
vocab_file = root / "01_architecture" / "domain_vocabulary.yaml"
if vocab_file.exists():
    data = load_yaml(vocab_file)
    try:
        jsonschema.validate(instance=data, schema=vocab_schema)
        print(f"[PASS] {vocab_file.relative_to(root)}")
    except jsonschema.ValidationError as e:
        print(f"[FAIL] {vocab_file.relative_to(root)}: {e.message}")
        errors += 1

# 4. JSONL アトムフォーマットの基本検証
for jsonl_file in (root / "00_traceability" / "atoms").glob("*.jsonl"):
    with open(jsonl_file, "r", encoding="utf-8") as f:
        line_no = 0
        for line in f:
            line_no += 1
            if not line.strip():
                continue
            try:
                atom = json.loads(line)
                assert "atom_id" in atom and "text_content" in atom
            except Exception as e:
                print(f"[FAIL] {jsonl_file.relative_to(root)} Line {line_no}: {str(e)}")
                errors += 1
    print(f"[PASS] {jsonl_file.relative_to(root)}")
        
if errors > 0:
    print(f"\nTotal Validation Errors: {errors}")
    sys.exit(1)
else:
    print("\nAll YAML and JSONL files strictly match the schema definitions.")

```

if **name** == "**main**":
validate()
