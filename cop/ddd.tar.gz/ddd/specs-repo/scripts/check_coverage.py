#!/usr/bin/env python3
"""
要件アトムのカバレッジを検証し、未移行かつ未廃止のアトムを検出するスクリプト
"""
import sys
import json
from pathlib import Path
import yaml

def check_coverage():
root = Path(**file**).resolve().parent.parent
atoms_dir = root / "00_traceability" / "atoms"
dep_file = root / "00_traceability" / "deprecated_features.yaml"
usecases_dir = root / "03_usecases"
report_file = root / "00_traceability" / "coverage_report.md"

```
# 1. 全アトムの読み込み
all_atoms = {}
for jsonl_file in atoms_dir.glob("*.jsonl"):
    with open(jsonl_file, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                item = json.loads(line)
                all_atoms[item["atom_id"]] = item

if not all_atoms:
    print("[INFO] No requirement atoms found in 00_traceability/atoms/")
    sys.exit(0)

# 2. 廃止アトムの読み込み
deprecated_atom_ids = set()
if dep_file.exists():
    with open(dep_file, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
        for item in data.get("deprecated_features", []):
            deprecated_atom_ids.add(item["atom_id"])

# 3. ユースケースで採用されたアトムの読み込み
covered_atom_ids = set()
for uc_file in usecases_dir.glob("**/*.yaml"):
    with open(uc_file, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
        for atom_id in data.get("source_atoms", []):
            covered_atom_ids.add(atom_id)

# 4. カバレッジ計算
total = len(all_atoms)
covered = len(covered_atom_ids)
deprecated = len(deprecated_atom_ids)
accounted_for = covered_atom_ids.union(deprecated_atom_ids)
unaccounted = set(all_atoms.keys()) - accounted_for

# 未抽出図形フラグの検出
uninspected_shapes = [a for a in all_atoms.values() if a.get("has_unextracted_shapes", False)]

# 5. レポートMarkdownの生成
report_content = f"""# 要件アトム トレーサビリティ・カバレッジレポート

```

## 1. カバレッジ統計

* **総要件アトム数**: {total} 件
* **ユースケース移行済み**: {covered} 件 ({covered / total * 100:.1f}%)
* **廃止 (Deprecated)**: {deprecated} 件 ({deprecated / total * 100:.1f}%)
* **未処理 (Unaccounted)**: {len(unaccounted)} 件 ({(len(unaccounted)) / total * 100:.1f}%)

"""
if unaccounted:
report_content += "## ⚠️ 未処理アトム一覧 (要アクション)\n"
report_content += "| アトムID | 出典仕様書 | セクション | 内容 |\n| :--- | :--- | :--- | :--- |\n"
for atom_id in sorted(unaccounted):
atom = all_atoms[atom_id]
sec = " > ".join(atom.get("heading_hierarchy", []))
report_content += f"| `{atom_id}` | {atom.get('source_doc')} | {sec} | {atom.get('text_content')} |\n"
report_content += "\n"
else:
report_content += "## ✅ すべての旧要件アトムが追跡されています (Coverage: 100%)\n\n"

```
if uninspected_shapes:
    report_content += f"## 🔍 未抽出図形・オートシェイプ検知リスト ({len(uninspected_shapes)} 件)\n"
    report_content += "| アトムID | 出典仕様書 | 抽出XML | 内容テキスト |\n| :--- | :--- | :--- | :--- |\n"
    for atom in uninspected_shapes:
        shape_xml = atom.get("raw_attributes", {}).get("shape_file", "None")
        report_content += f"| `{atom['atom_id']}` | {atom.get('source_doc')} | `{shape_xml}` | {atom.get('text_content')} |\n"

with open(report_file, "w", encoding="utf-8") as f:
    f.write(report_content)

print(f"[COVERAGE REPORT] Generated at {report_file.relative_to(root)}")
print(f"  Total: {total}, Covered: {covered}, Deprecated: {deprecated}, Unaccounted: {len(unaccounted)}")

if unaccounted:
    print(f"[ERROR] {len(unaccounted)} atoms are unaccounted for. CI failed.")
    sys.exit(1)
else:
    print("[SUCCESS] 100% Traceability Coverage achieved.")

```

if **name** == "**main**":
check_coverage()
