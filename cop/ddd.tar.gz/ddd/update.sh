#!/usr/bin/env bash
set -euo pipefail

# specs-repo 内で実行されたか、親ディレクトリで実行されたかを判定
if [ -d "specs-repo" ]; then
    cd "specs-repo"
fi

if [ ! -d ".git" ]; then
    echo "ERROR: .git ディレクトリが見つかりません。specs-repo のルートで実行してください。"
    exit 1
fi

echo "=== specs-repo への機能追加・拡張スクリプトを開始します ==="

# 1. 新規ディレクトリの作成
mkdir -p 00_traceability/atoms
mkdir -p assets/inspections/raw_shapes
mkdir -p assets/inspections/reports

echo "Directories created."

# 2. フラットな用語集スキーマ (.schemas/vocabulary.schema.yaml) の作成
cat << 'EOF' > .schemas/vocabulary.schema.yaml
$schema: "http://json-schema.org/draft-07/schema#"
title: "DomainVocabularySchema"
description: "モジュラーモノリスの境界づけられたコンテキスト対応の用語集スキーマ（yaml_editor対応フラットリスト）"
type: object
required:
  - vocabulary
properties:
  vocabulary:
    type: array
    description: "用語一覧リスト"
    items:
      type: object
      required:
        - module
        - term
        - code
        - definition
      properties:
        module:
          type: string
          description: "所属モジュール・コンテキスト（例: OrderManagement, LogisticsGateway）"
        term:
          type: string
          description: "業務用語名（日本語）"
        code:
          type: string
          description: "システム用コード / 英語名（PascalCase推奨）"
          pattern: "^[A-Za-z0-9_]+$"
        definition:
          type: string
          description: "このモジュールにおける用語の意味・役割"
        note:
          type: string
          description: "他モジュールとの違い、同名異義語の補足、注意事項（任意）"
EOF

# 3. ユースケーススキーマの改訂 (.schemas/usecase.schema.yaml)
# アトム単位のトレーサビリティ (source_atoms) を追加
cat << 'EOF' > .schemas/usecase.schema.yaml
$schema: "http://json-schema.org/draft-07/schema#"
title: "IconixUseCaseSchema"
description: "ICONIXプロセスおよびアトム単位トレーサビリティに最適化されたユースケース定義スキーマ"
type: object
required:
  - id
  - title
  - module
  - actor
  - pre_conditions
  - post_conditions
  - basic_flow
properties:
  id:
    type: string
    description: "ユースケース識別子"
    pattern: "^UC_[A-Z0-9]+_[0-9]{3}$"
  title:
    type: string
    description: "ユースケース名 (動詞 + 目的語)"
  module:
    type: string
    description: "所属モジュール (モジュラーモノリス境界)"
  source_requirements:
    type: array
    description: "旧仕様書の該当章・セクション識別子一覧"
    items:
      type: string
  source_atoms:
    type: array
    description: "本ユースケースを構成する根拠となった要件アトムID一覧"
    items:
      type: string
  actor:
    type: string
    description: "主アクター (クライアントUI、オペレーター等)"
  pre_conditions:
    type: array
    description: "前提条件一覧"
    items:
      type: string
    minItems: 1
  post_conditions:
    type: array
    description: "事後条件一覧"
    items:
      type: string
    minItems: 1
  basic_flow:
    type: array
    description: "基本コース (能動態のステップリスト)"
    minItems: 2
    items:
      type: object
      required:
        - step
        - actor_action
        - system_response
      properties:
        step:
          type: integer
        actor_action:
          type: string
        system_response:
          type: string
        source_atom_ref:
          type: string
          description: "本ステップの根拠となる要件アトムID（任意）"
  alternative_flows:
    type: array
    description: "代替コース (例外・エラー)"
    items:
      type: object
      required:
        - id
        - resume_step
        - condition
        - handling
      properties:
        id:
          type: string
        resume_step:
          type: integer
        condition:
          type: string
        handling:
          type: string
        source_atom_ref:
          type: string
          description: "本例外の根拠となる要件アトムID（任意）"
  robustness_model:
    type: object
    description: "ICONIXロバストネス図要素定義"
    required:
      - boundaries
      - controls
      - entities
      - relations
    properties:
      boundaries:
        type: array
        items:
          type: object
          required: [name, alias]
          properties:
            name: { type: string }
            alias: { type: string }
      controls:
        type: array
        items:
          type: object
          required: [name, alias]
          properties:
            name: { type: string }
            alias: { type: string }
      entities:
        type: array
        items:
          type: object
          required: [name, alias]
          properties:
            name: { type: string }
            alias: { type: string }
      relations:
        type: array
        items:
          type: object
          required: [from, to, label]
          properties:
            from: { type: string }
            to: { type: string }
            label: { type: string }
  architectural_hints:
    type: object
    description: "アーキテクチャ境界定義"
    properties:
      geode_regions:
        type: array
        items: { type: string }
      gateway_destinations:
        type: array
        items: { type: string }
EOF

# 4. ドメイン用語集初期データ (01_architecture/domain_vocabulary.yaml) の作成
cat << 'EOF' > 01_architecture/domain_vocabulary.yaml
vocabulary:
  - module: "OrderManagement"
    term: "注文"
    code: "Order"
    definition: "顧客からの購入申し込み。商品明細、合計金額、与信確認状態を持つ集約。"
    note: "出荷側の荷物単位の注文と混同しないこと。金額情報を管理する唯一のコンテキスト。"

  - module: "OrderManagement"
    term: "与信枠"
    code: "CreditLimit"
    definition: "顧客が一度に未決済で注文可能な上限金額。Geodeの顧客キャッシュから照会する。"
    note: ""

  - module: "LogisticsGateway"
    term: "注文"
    code: "DeliveryOrder"
    definition: "外部配送システムへ電文連携するための荷物単位のデータ。"
    note: "受注側の注文から金額情報を除き、配送先住所と個口数を付与したもの。"

  - module: "LogisticsGateway"
    term: "配送ステータス"
    code: "DeliveryStatus"
    definition: "外部GWから電文で非同期通知される配送状況（未発送、輸送中、配達完了など）。"
    note: ""
EOF

# 5. 廃止機能台帳初期データ (00_traceability/deprecated_features.yaml) の作成
cat << 'EOF' > 00_traceability/deprecated_features.yaml
schema_version: "1.0"
deprecated_features:
  - atom_id: "ATOM_ORD_0004"
    source_doc: "旧仕様書_販売管理_v1.0.docx"
    section_title: "4.2 手動配送指示画面"
    reason: "次期システムでは外部GWへの自動電文送信に統合するため、画面機能としては廃止"
    approved_by: "アーキテクトレビュー"
    date: "2026-11-01"
EOF

# 6. 要件アトムのサンプル (00_traceability/atoms/sample_spec_atoms.jsonl) の作成
cat << 'EOF' > 00_traceability/atoms/sample_spec_atoms.jsonl
{"atom_id":"ATOM_ORD_0001","source_doc":"旧仕様書_販売管理_v1.0.docx","heading_hierarchy":["第4章 注文管理","4.1 新規登録"],"content_type":"text","text_content":"オペレーターは顧客コードと明細を入力して注文登録を行う。","has_unextracted_shapes":false,"raw_attributes":{},"status":"Mapped","mapped_usecase":"UC_MOD01_001"}
{"atom_id":"ATOM_ORD_0002","source_doc":"旧仕様書_販売管理_v1.0.docx","heading_hierarchy":["第4章 注文管理","4.1 新規登録"],"content_type":"text","text_content":"登録時、顧客の未決済残高と与信限度額をチェックし超過時は登録を保留する。","has_unextracted_shapes":false,"raw_attributes":{},"status":"Mapped","mapped_usecase":"UC_MOD01_001"}
{"atom_id":"ATOM_ORD_0003","source_doc":"旧仕様書_販売管理_v1.0.docx","heading_hierarchy":["第4章 注文管理","4.1 新規登録"],"content_type":"drawing_text","text_content":"[描画テキストボックス] 外部配送GWへの連携は注文確定後に自動でキューイングすること。","has_unextracted_shapes":true,"raw_attributes":{"shape_file":"assets/inspections/raw_shapes/shape_001.xml"},"status":"Mapped","mapped_usecase":"UC_MOD01_001"}
{"atom_id":"ATOM_ORD_0004","source_doc":"旧仕様書_販売管理_v1.0.docx","heading_hierarchy":["第4章 注文管理","4.2 手動配送指示画面"],"content_type":"text","text_content":"手動で配送指示ボタンを押下して外部連携を実行する画面を提供する。","has_unextracted_shapes":false,"raw_attributes":{},"status":"Deprecated","mapped_usecase":null}
EOF

# 7. 用語集 Markdown変換用 Jinja2テンプレート (templates/vocabulary.md.j2) の作成
cat << 'EOF' > templates/vocabulary.md.j2
<!-- AUTO-GENERATED FROM domain_vocabulary.yaml. DO NOT EDIT DIRECTLY. -->
# ドメイン共通用語集 (Bounded Contexts)

本ドキュメントはモジュラーモノリス内の境界づけられたコンテキストごとに定義されたドメイン用語集です。

| モジュール (Context) | 用語名 (日本語) | システムコード (英名) | 定義・役割 | 補足 / 同名異義語 |
| :--- | :--- | :--- | :--- | :--- |
{% for v in vocabulary %}
| `{{ v.module }}` | **{{ v.term }}** | `{{ v.code }}` | {{ v.definition }} | {{ v.note if v.note else '-' }} |
{% endfor %}
EOF

# 8. ユースケース Markdownテンプレート (templates/usecase.md.j2) の更新
cat << 'EOF' > templates/usecase.md.j2
<!-- AUTO-GENERATED FROM {{ id }}.yaml. DO NOT EDIT DIRECTLY. -->
# {{ id }}: {{ title }}

## 1. 概要
- **モジュール**: `{{ module }}`
- **主アクター**: {{ actor }}
- **旧仕様追跡**: {% if source_requirements %}{{ source_requirements | join(', ') }}{% else %}新規追加{% endif %}
- **根拠アトムID**: {% if source_atoms %}`{{ source_atoms | join('`, `') }}`{% else %}未紐付け{% endif %}

### 事前条件
{% for pre in pre_conditions %}
- {{ pre }}
{% endfor %}

### 事後条件
{% for post in post_conditions %}
- {{ post }}
{% endfor %}

---

## 2. ロバストネス分析 (ICONIX)
```plantuml
@startuml
skinparam monochrome true
skinparam packageStyle rectangle

actor "{{ actor }}" as Actor

{% if robustness_model %}
package "Boundary" {
{% for b in robustness_model.boundaries %}
    boundary "{{ b.name }}" as {{ b.alias }}
{% endfor %}
}

package "Control" {
{% for c in robustness_model.controls %}
    control "{{ c.name }}" as {{ c.alias }}
{% endfor %}
}

package "Entity" {
{% for e in robustness_model.entities %}
    entity "{{ e.name }}" as {{ e.alias }}
{% endfor %}
}

' --- 接続定義 ---
{% for rel in robustness_model.relations %}
{{ rel.from }} --> {{ rel.to }} : {{ rel.label }}
{% endfor %}
{% endif %}
@enduml

```

---

## 3. 基本コース (Happy Path)

| ステップ | アクターの操作 | システムの応答・処理 | 根拠アトム |
| --- | --- | --- | --- |
| {% for step in basic_flow %} |  |  |  |
| {{ step.step }} | {{ step.actor_action }} | {{ step.system_response }} | {{ step.source_atom_ref if step.source_atom_ref else '-' }} |
| {% endfor %} |  |  |  |

---

## 4. 代替コース (Exceptions & Alternatives)

{% if alternative_flows %}
{% for alt in alternative_flows %}

### {{ alt.id }}. 分岐元ステップ {{ alt.resume_step }}

* **発生条件**: {{ alt.condition }}
* **システムの処理**: {{ alt.handling }}
{% if alt.source_atom_ref %}- **根拠アトム**: `{{ alt.source_atom_ref }}`{% endif %}
{% endfor %}
{% else %}
*特記事項なし*
{% endif %}

---

## 5. アーキテクチャ連携仕様

{% if architectural_hints %}

### Geode Region 候補

{% for reg in architectural_hints.geode_regions %}

* `{{ reg }}`
{% endfor %}

### 外部ゲートウェイ宛先

{% for gw in architectural_hints.gateway_destinations %}

* `{{ gw }}`
{% endfor %}
{% else %}
*特記事項なし*
{% endif %}
EOF

# 9. ユースケース初期データサンプル (03_usecases/MOD01_Order/UC_MOD01_001.yaml) にアトムIDを反映

cat << 'EOF' > 03_usecases/MOD01_Order/UC_MOD01_001.yaml
id: "UC_MOD01_001"
title: "新規受注を登録する"
module: "OrderManagement"
source_requirements:

* "旧仕様書_販売管理_v1.0.docx 第4章 4.1"
source_atoms:
* "ATOM_ORD_0001"
* "ATOM_ORD_0002"
* "ATOM_ORD_0003"
actor: "クライアントUI (オペレーター)"

pre_conditions:

* "オペレーターがログイン認証済みであること"
* "対象顧客がGeode上に存在すること"

post_conditions:

* "受注EntityがGeodeの /Orders にConfirmedステータスで保存されていること"
* "配送依頼電文が外部GW向け送信キューに登録されていること"

basic_flow:

* step: 1
actor_action: "顧客IDおよび注文明細リストを入力し、登録要求を送信する"
system_response: "入力項目の必須チェックおよび注文数量が正の整数であることを検証する"
source_atom_ref: "ATOM_ORD_0001"
* step: 2
actor_action: "（システム自動処理）"
system_response: "顧客の与信状態をGeodeから取得し、限度額内であることを確認する"
source_atom_ref: "ATOM_ORD_0002"
* step: 3
actor_action: "（システム自動処理）"
system_response: "新規受注Entityを作成し、ConfirmedステータスでGeodeの /Orders に保存する"
source_atom_ref: "ATOM_ORD_0001"
* step: 4
actor_action: "（システム自動処理）"
system_response: "配送依頼電文を作成し、外部GW向けキューへ送信する"
source_atom_ref: "ATOM_ORD_0003"
* step: 5
actor_action: "登録完了通知を受け取る"
system_response: "採番された受注IDおよび処理完了メッセージを画面に返却する"

alternative_flows:

* id: "1a"
resume_step: 1
condition: "必須項目が欠落しているか、数量が0以下の場合"
handling: "入力検証エラーメッセージを画面に返却し、処理を終了する"
* id: "2a"
resume_step: 2
condition: "顧客の与信限度額を超過している場合"
handling: "受注ステータスをPendingApprovalとして保存し、承認待ち通知を返却して電文送信を保留する"
source_atom_ref: "ATOM_ORD_0002"
* id: "4a"
resume_step: 4
condition: "外部GW向けキューへの登録に失敗またはタイムアウトした場合"
handling: "受注ステータスをDeliveryFailedに更新し、警告ログを出力して画面にその旨を通知する"

robustness_model:
boundaries:
- name: "受注登録画面"
alias: "UI"
- name: "外部配送GWクライアント"
alias: "DeliveryGW"
controls:
- name: "受注登録コントローラー"
alias: "OrderCtrl"
- name: "与信確認コントローラー"
alias: "CreditCtrl"
- name: "電文送信コントローラー"
alias: "MsgCtrl"
entities:
- name: "顧客情報 (Geode)"
alias: "CustomerEntity"
- name: "受注データ (Geode)"
alias: "OrderEntity"
- name: "配送依頼電文"
alias: "DeliveryMessage"
relations:
- from: "Actor"
to: "UI"
label: "注文情報を入力・登録"
- from: "UI"
to: "OrderCtrl"
label: "登録コマンド送信"
- from: "OrderCtrl"
to: "CreditCtrl"
label: "与信チェック要求"
- from: "CreditCtrl"
to: "CustomerEntity"
label: "与信枠照会"
- from: "OrderCtrl"
to: "OrderEntity"
label: "受注インスタンス生成・保存"
- from: "OrderCtrl"
to: "MsgCtrl"
label: "電文作成依頼"
- from: "MsgCtrl"
to: "DeliveryMessage"
label: "ペイロード構築"
- from: "MsgCtrl"
to: "DeliveryGW"
label: "送信要求"
- from: "DeliveryGW"
to: "DeliveryMessage"
label: "外部キューへ転送"
- from: "OrderCtrl"
to: "UI"
label: "完了結果表示"

architectural_hints:
geode_regions:
- "/Orders"
- "/Customers"
gateway_destinations:
- "GW.DEST.LOGISTICS_SYSTEM"
EOF

# 10. カバレッジ検証スクリプト (scripts/check_coverage.py) の作成

cat << 'EOF' > scripts/check_coverage.py
#!/usr/bin/env python3
"""
要件アトムのカバレッジを検証し、未移行かつ未廃止のアトムを検出するスクリプト
"""
import sys
import json
from pathlib import Path
import yaml

def check_coverage():
root = Path(**file**).resolve().parent.parent
atoms_dir = root / "00_traceability" / "atoms"
dep_file = root / "00_traceability" / "deprecated_features.yaml"
usecases_dir = root / "03_usecases"
report_file = root / "00_traceability" / "coverage_report.md"

```
# 1. 全アトムの読み込み
all_atoms = {}
for jsonl_file in atoms_dir.glob("*.jsonl"):
    with open(jsonl_file, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                item = json.loads(line)
                all_atoms[item["atom_id"]] = item

if not all_atoms:
    print("[INFO] No requirement atoms found in 00_traceability/atoms/")
    sys.exit(0)

# 2. 廃止アトムの読み込み
deprecated_atom_ids = set()
if dep_file.exists():
    with open(dep_file, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
        for item in data.get("deprecated_features", []):
            deprecated_atom_ids.add(item["atom_id"])

# 3. ユースケースで採用されたアトムの読み込み
covered_atom_ids = set()
for uc_file in usecases_dir.glob("**/*.yaml"):
    with open(uc_file, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
        for atom_id in data.get("source_atoms", []):
            covered_atom_ids.add(atom_id)

# 4. カバレッジ計算
total = len(all_atoms)
covered = len(covered_atom_ids)
deprecated = len(deprecated_atom_ids)
accounted_for = covered_atom_ids.union(deprecated_atom_ids)
unaccounted = set(all_atoms.keys()) - accounted_for

# 未抽出図形フラグの検出
uninspected_shapes = [a for a in all_atoms.values() if a.get("has_unextracted_shapes", False)]

# 5. レポートMarkdownの生成
report_content = f"""# 要件アトム トレーサビリティ・カバレッジレポート

```

## 1. カバレッジ統計

* **総要件アトム数**: {total} 件
* **ユースケース移行済み**: {covered} 件 ({covered / total * 100:.1f}%)
* **廃止 (Deprecated)**: {deprecated} 件 ({deprecated / total * 100:.1f}%)
* **未処理 (Unaccounted)**: {len(unaccounted)} 件 ({(len(unaccounted)) / total * 100:.1f}%)

"""
if unaccounted:
report_content += "## ⚠️ 未処理アトム一覧 (要アクション)\n"
report_content += "| アトムID | 出典仕様書 | セクション | 内容 |\n| :--- | :--- | :--- | :--- |\n"
for atom_id in sorted(unaccounted):
atom = all_atoms[atom_id]
sec = " > ".join(atom.get("heading_hierarchy", []))
report_content += f"| `{atom_id}` | {atom.get('source_doc')} | {sec} | {atom.get('text_content')} |\n"
report_content += "\n"
else:
report_content += "## ✅ すべての旧要件アトムが追跡されています (Coverage: 100%)\n\n"

```
if uninspected_shapes:
    report_content += f"## 🔍 未抽出図形・オートシェイプ検知リスト ({len(uninspected_shapes)} 件)\n"
    report_content += "| アトムID | 出典仕様書 | 抽出XML | 内容テキスト |\n| :--- | :--- | :--- | :--- |\n"
    for atom in uninspected_shapes:
        shape_xml = atom.get("raw_attributes", {}).get("shape_file", "None")
        report_content += f"| `{atom['atom_id']}` | {atom.get('source_doc')} | `{shape_xml}` | {atom.get('text_content')} |\n"

with open(report_file, "w", encoding="utf-8") as f:
    f.write(report_content)

print(f"[COVERAGE REPORT] Generated at {report_file.relative_to(root)}")
print(f"  Total: {total}, Covered: {covered}, Deprecated: {deprecated}, Unaccounted: {len(unaccounted)}")

if unaccounted:
    print(f"[ERROR] {len(unaccounted)} atoms are unaccounted for. CI failed.")
    sys.exit(1)
else:
    print("[SUCCESS] 100% Traceability Coverage achieved.")

```

if **name** == "**main**":
check_coverage()
EOF
chmod +x scripts/check_coverage.py

# 11. スキーマ検証スクリプト (scripts/validate_schemas.py) の更新

cat << 'EOF' > scripts/validate_schemas.py
#!/usr/bin/env python3
"""
リポジトリ内の全YAMLファイルおよびJSONLアトムが定義に準拠しているか検証するスクリプト
"""
import sys
import json
from pathlib import Path
import yaml
try:
import jsonschema
except ImportError:
print("WARNING: jsonschema not installed. Skipping deep schema validation.")
sys.exit(0)

def load_yaml(path: Path):
with open(path, "r", encoding="utf-8") as f:
return yaml.safe_load(f)

def validate():
root = Path(**file**).resolve().parent.parent
schemas_dir = root / ".schemas"

```
uc_schema = load_yaml(schemas_dir / "usecase.schema.yaml")
domain_schema = load_yaml(schemas_dir / "domain.schema.yaml")
vocab_schema = load_yaml(schemas_dir / "vocabulary.schema.yaml")

errors = 0

# 1. ユースケースYAML検証
for yml in (root / "03_usecases").glob("**/*.yaml"):
    data = load_yaml(yml)
    try:
        jsonschema.validate(instance=data, schema=uc_schema)
        print(f"[PASS] {yml.relative_to(root)}")
    except jsonschema.ValidationError as e:
        print(f"[FAIL] {yml.relative_to(root)}: {e.message}")
        errors += 1
        
# 2. ドメインYAML検証
for yml in (root / "02_domains").glob("**/*.yaml"):
    data = load_yaml(yml)
    try:
        jsonschema.validate(instance=data, schema=domain_schema)
        print(f"[PASS] {yml.relative_to(root)}")
    except jsonschema.ValidationError as e:
        print(f"[FAIL] {yml.relative_to(root)}: {e.message}")
        errors += 1

# 3. 用語集YAML検証
vocab_file = root / "01_architecture" / "domain_vocabulary.yaml"
if vocab_file.exists():
    data = load_yaml(vocab_file)
    try:
        jsonschema.validate(instance=data, schema=vocab_schema)
        print(f"[PASS] {vocab_file.relative_to(root)}")
    except jsonschema.ValidationError as e:
        print(f"[FAIL] {vocab_file.relative_to(root)}: {e.message}")
        errors += 1

# 4. JSONL アトムフォーマットの基本検証
for jsonl_file in (root / "00_traceability" / "atoms").glob("*.jsonl"):
    with open(jsonl_file, "r", encoding="utf-8") as f:
        line_no = 0
        for line in f:
            line_no += 1
            if not line.strip():
                continue
            try:
                atom = json.loads(line)
                assert "atom_id" in atom and "text_content" in atom
            except Exception as e:
                print(f"[FAIL] {jsonl_file.relative_to(root)} Line {line_no}: {str(e)}")
                errors += 1
    print(f"[PASS] {jsonl_file.relative_to(root)}")
        
if errors > 0:
    print(f"\nTotal Validation Errors: {errors}")
    sys.exit(1)
else:
    print("\nAll YAML and JSONL files strictly match the schema definitions.")

```

if **name** == "**main**":
validate()
EOF
chmod +x scripts/validate_schemas.py

# 12. ドキュメントレンダリングスクリプト (scripts/render_docs.py) の更新

cat << 'EOF' > scripts/render_docs.py
#!/usr/bin/env python3
"""
YAMLファイルからJinja2テンプレートを用いてMarkdownドキュメントを一括生成するスクリプト
"""
import sys
from pathlib import Path
import yaml
try:
from jinja2 import Environment, FileSystemLoader
except ImportError:
print("ERROR: jinja2 is required. Please install via: pip install jinja2")
sys.exit(1)

def render_all():
root = Path(**file**).resolve().parent.parent
templates_dir = root / "templates"
env = Environment(loader=FileSystemLoader(str(templates_dir)), trim_blocks=True, lstrip_blocks=True)

```
uc_template = env.get_template("usecase.md.j2")
domain_template = env.get_template("domain.md.j2")
vocab_template = env.get_template("vocabulary.md.j2")

# 1. ユースケースMarkdownの生成
for yml_path in (root / "03_usecases").glob("**/*.yaml"):
    with open(yml_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
        
    md_content = uc_template.render(data)
    out_path = yml_path.with_suffix(".md")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(md_content)
    print(f"[RENDERED] {out_path.relative_to(root)}")
    
# 2. ドメインモデルMarkdownの生成
for yml_path in (root / "02_domains").glob("**/*.yaml"):
    with open(yml_path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
        
    md_content = domain_template.render(data)
    out_path = yml_path.with_suffix(".md")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(md_content)
    print(f"[RENDERED] {out_path.relative_to(root)}")

# 3. 用語集Markdownの生成
vocab_file = root / "01_architecture" / "domain_vocabulary.yaml"
if vocab_file.exists():
    with open(vocab_file, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    md_content = vocab_template.render(data)
    out_path = vocab_file.with_suffix(".md")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(md_content)
    print(f"[RENDERED] {out_path.relative_to(root)}")

```

if **name** == "**main**":
render_all()
EOF
chmod +x scripts/render_docs.py

# 13. Gitea tea CLI 連携ワーカースクリプト (scripts/tea_issue_worker.sh) の作成

cat << 'EOF' > scripts/tea_issue_worker.sh
#!/usr/bin/env bash
set -euo pipefail

# GiteaのIssueを監視し、status:ready-for-agent ラベルが付与されたものを処理するスクリプト

# 必要ツール: tea (Gitea CLI)

if ! command -v tea >/dev/null 2>&1; then
echo "ERROR: Gitea official CLI 'tea' is required."
exit 1
fi

ISSUE_INDEX="${1:-}"

if [ -z "${ISSUE_INDEX}" ]; then
echo "Usage: $0 "
echo "Example: $0 42"
exit 1
fi

echo "=== Processing Gitea Issue #${ISSUE_INDEX} ==="

# 1. 状態を processing に更新

tea issue edit "${ISSUE_INDEX}" --remove-labels "status:ready-for-agent" --add-labels "status:processing"

BRANCH_NAME="agent/issue-${ISSUE_INDEX}"
git checkout -b "${BRANCH_NAME}"

# 2. ドキュメントレンダリングとスキーマ検証の実行

python3 scripts/validate_schemas.py
python3 scripts/render_docs.py
python3 scripts/check_coverage.py

# 3. 差分をコミット＆プッシュ

git add .
if git diff --staged --quiet; then
echo "No changes to commit."
else
git commit -m "feat(spec): automated draft from issue #${ISSUE_INDEX} [skip ci]"
git push -u origin "${BRANCH_NAME}"

```
# 4. Pull Requestの起票
PR_URL=$(tea pr create \
    --title "Auto Draft: Issue #${ISSUE_INDEX} に基づくユースケース・ICONIX分析ドラフト" \
    --description "Issue #${ISSUE_INDEX} に基づき自動生成されました。YAMLをレビューしてください。\n\nRefs #${ISSUE_INDEX}" \
    --source-branch "${BRANCH_NAME}" \
    --target-branch "main")

tea issue comment "${ISSUE_INDEX}" "エージェントの処理が完了し、ドラフトPRを起票しました: ${PR_URL}"

```

fi

# 5. ステータスを review-required へ遷移

tea issue edit "${ISSUE_INDEX}" --remove-labels "status:processing" --add-labels "status:review-required"

echo "=== Issue #${ISSUE_INDEX} processing completed successfully. ==="
EOF
chmod +x scripts/tea_issue_worker.sh

# 14. README.md の本格改訂（SOP・完全運用仕様の記述）

cat << 'EOF' > README.md

# specs-repo: 概要設計・ICONIX分析 運用マニュアル (SOP)

本リポジトリは、旧仕様書から新アーキテクチャ（C++モジュラーモノリス）へ移行するための概要設計成果物、および要件トレーサビリティを管理します。

---

## 1. 運用原則 (Core Policies)

1. **Single Source of Truth (SSoT)**:
* 正本データはすべて `.schemas/` に準拠した **YAML** および **JSON Lines** です。
* MarkdownおよびPlantUMLは `scripts/render_docs.py` により機械生成される閲覧用成果物であり、直接編集は禁止です。


2. **完全トレーサビリティ保証**:
* 旧仕様書の全記述は `00_traceability/atoms/*.jsonl` にアトム単位で登録されます。
* すべてのアトムは、「ユースケースの根拠として採用される」か「`00_traceability/deprecated_features.yaml` に廃止理由を明記する」かのいずれかでなければならず、カバレッジ100%をCIで検証します。


3. **ICONIX粒度ポリシー**:
* **システムユースケース**: 1アクターが1回の対話セッションで達成する目的。基本コース2〜5ステップ、代替コース2〜5個程度を目安とする。
* **能動態記述**: 「アクターは〜を入力する」「システムは〜を検証する」という主客を明確にした記述を徹底する。
* **UI非依存**: ボタンの色や配置は記述せず、論理的なデータ送受信と業務ルールに集中する。



---

## 2. 状態遷移とラベル運用 (Gitea Issue駆動)

エージェントと人間の協働作業は、Gitea Issueのラベル状態遷移によって制御されます。

| ラベル名 | 状態 | 担当 | アクション |
| --- | --- | --- | --- |
| `status:ready-for-agent` | 処理待ち | 人間 | TSV機能IDと旧Wordファイルを指定してIssueに付与。 |
| `status:processing` | 処理中 | エージェント | `tea` 経由で検知し、ブランチ作成とドラフト生成を実行。 |
| `status:review-required` | レビュー待ち | 人間 | エージェントがPRを起票後に付与。人間がYAMLをレビュー。 |
| `status:agent-error` | 要エスカレーション | 人間 | 構文エラー修復上限（3回）超過時。人間が介入して修正。 |
| `status:done` | 完了 | - | PRがmainブランチへマージされた状態。 |

---

## 3. 人間とエージェントの作業手順

### ステップ1: 旧仕様書と新機能のインプット登録

1. `inputs/features.tsv` に大中小の機能一覧を配置する。
2. `inputs/raw_docs/` に解析対象の旧仕様書Wordファイルを配置する。
3. Issueを作成し、`status:ready-for-agent` ラベルを付与する。

### ステップ2: エージェントによるドラフト生成

1. エージェントがWordをアトム化し、`00_traceability/atoms/*.jsonl` に保存。
2. 対象モジュールの用語集（`01_architecture/domain_vocabulary.yaml`）を参照し、`UC_*.yaml` を生成。
3. PlantUML Serverによる構文検証、スキーマ検証、ドキュメントレンダリングを実行。
4. PRを自動起票し、ラベルを `status:review-required` に更新。

### ステップ3: 人間によるレビューと修正

1. PR上のMarkdownおよびPlantUMLプレビューを確認。
2. 修正が必要な場合は、VSCodeの `yaml_editor` 拡張を用いて対象の `UC_*.yaml` または `domain_vocabulary.yaml` を直接編集してコミット。
3. 不要となった旧仕様記述は `00_traceability/deprecated_features.yaml` に理由を記載して追加。
4. `python scripts/check_coverage.py` を実行し、カバレッジが100%であることを確認してマージ。

---

## 4. ディレクトリ構成

* `inputs/`: 新機能TSVおよび旧Word仕様書
* `.schemas/`: 各種YAML/JSONLが準拠すべきJSON Schema
* `templates/`: Jinja2変換テンプレート
* `00_traceability/`: 要件アトム、廃止台帳、カバレッジレポート
* `01_architecture/`: モジュール境界定義、ゲートウェイ共通電文、共通用語集
* `02_domains/`: Geode Regionおよびドメインモデル定義
* `03_usecases/`: ユースケース別YAML定義および自動生成Markdown
* `assets/inspections/`: 未抽出オートシェイプや要目視確認用データの退避先
* `scripts/`: 検証・生成・CI用スクリプト
EOF

# 15. Gitea Actions ワークフロー定義の更新

cat << 'EOF' > .gitea/workflows/render_and_validate.yaml
name: Validate Schemas, Check Coverage, and Render Markdown

on:
push:
paths:
- '**.yaml'
- '**.jsonl'
- 'templates/**'
pull_request:
paths:
- '**.yaml'
- '.jsonl'

jobs:
build:
runs-on: ubuntu-latest
steps:
- name: Checkout Code
uses: actions/checkout@v3

```
  - name: Set up Python
    uses: actions/setup-python@v4
    with:
      python-version: '3.11'

  - name: Install Dependencies
    run: |
      pip install pyyaml jinja2 jsonschema

  - name: Validate Schemas
    run: |
      python scripts/validate_schemas.py

  - name: Check Traceability Coverage
    run: |
      python scripts/check_coverage.py

  - name: Render Markdown Documents
    run: |
      python scripts/render_docs.py

  - name: Check for Uncommitted Markdown Changes
    run: |
      if [ -n "$(git status --porcelain '*.md')" ]; then
        echo "ERROR: Markdown files are out of sync with YAML/JSONL sources. Run scripts/render_docs.py and commit."
        git diff
        exit 1
      fi

```

EOF

# 16. レンダリングとカバレッジ確認の実行（Python環境が利用可能な場合）

if command -v python3 >/dev/null 2>&1 && python3 -c "import jinja2, yaml, jsonschema" >/dev/null 2>&1; then
echo "Running validation, rendering, and coverage check..."
python3 scripts/validate_schemas.py
python3 scripts/render_docs.py
python3 scripts/check_coverage.py
else
echo "Python3 or required packages not found. Skipping initial execution."
fi

# 17. Git コミット

git add .
git commit -m "feat(infra): expand traceability, vocabulary schema, coverage checker, and tea worker"

echo "=== specs-repo への機能追加とコミットが完了しました ==="

